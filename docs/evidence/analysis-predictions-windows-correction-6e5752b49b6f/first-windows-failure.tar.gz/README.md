# CaptureSuite PR84: first hosted Windows gate

The exact hosted Python job failed at the existing 300-second subprocess limit. This packet preserves that failure; it does not accept Windows behavior or report a passing MainWindow test.

- PR head: 1f0d19c17e760d4dd5c1146ce46075cc3f3ce45d.
- Actual checkout: c185ea19d48d38e3fdbd2c7e6c53df3c5910f0f8 (head merged into 11cc78297d8d214407aea693548af4de855d61da).
- Workflow run 37816542567; Python job 113446512304; Windows 2022, Python 3.12.10, PySide6 6.12.0.
- The raw completed job log shows 522 completed progress symbols including six skips, then timeout. Quiet progress has no test names and cannot identify the stalled node.
- The emitted test receipt reports process_exit=null, no JUnit, accepted=false, a clean 1,088-file source snapshot, and unchanged source during execution. observed-test-receipt.json is the JSON reconstructed from timestamp-prefixed log lines, not an independently downloaded artifact member.

The original Actions artifact is 1,598,256 bytes, GitHub ID 11567407913, reported ZIP SHA-256 704b3e642a0e02af9658e77d3406dd2d135392b221fbaf23ebdcc1ca04286eb1. The connector returned its exact file reference. Direct download returned HTTP 403 / Cloudflare 1010; the supported Library materializer accepted that reference, but the unchanged bundled transfer helper also returned HTTP 403. No archive bytes, listing, or member data were observed. This packet does not verify the reported ZIP digest. No access-control bypass or timeout increase was attempted.

expected-ci.json records the previously independently admitted actual checkout inventory and critical source hashes. receive-ci.py is a prepared successful-gate receiver, syntax checked only; it has not run on this failed archive and requires complete JUnit. It must be adapted for any changed successor source before final execution.

The exact hosted test and shared QApplication fixture are included for focused diagnosis. A source review observes that _real_choose's five-second missing-dialog branch records a failure without unwinding the blocking dialog call. That is a diagnostic hypothesis, not an established cause of this hosted timeout. The author owns the focused test diagnostic and correction. No production source was modified by this receiver.

The first local all-in-one evidence write was refused by the process launcher (argument list too long) before starting Python. The same retained strings were then written in bounded chunks and reread for hashes. The full raw job log preserves CRLF bytes as returned by the GitHub connector. No failed native execution was rerun here.
