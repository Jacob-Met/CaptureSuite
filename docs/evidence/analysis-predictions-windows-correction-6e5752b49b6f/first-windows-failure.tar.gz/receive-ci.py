"""Independent hosted Windows CI receipt reader for CaptureSuite PR84.
Read the actual retained ZIP and decoded job log; never execute project tests.
"""
import hashlib, io, json, re, zipfile
import xml.etree.ElementTree as ET
from pathlib import PurePosixPath

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def receive_ci(archive, job_log, expected):
    problems = []
    observations = {}
    def check(condition, message):
        if not condition:
            problems.append(message)
    with zipfile.ZipFile(io.BytesIO(archive)) as z:
        members = z.infolist()
        names = [m.filename for m in members]
        check(len(names) == len(set(names)), "ZIP has duplicate member names")
        check(all(not PurePosixPath(n).is_absolute() and ".." not in PurePosixPath(n).parts
                  for n in names), "ZIP contains escaping paths")
        payloads = {}
        for filename in ("pytest.xml", "pytest.log", "receipt.json", "source-manifest.json"):
            found = [m for m in members if not m.is_dir() and PurePosixPath(m.filename).name == filename]
            if len(found) != 1:
                raise ValueError("Expected exactly one retained " + filename)
            if found[0].file_size > 8 * 1024 * 1024:
                raise ValueError("Unsupported evidence size: " + filename)
            payloads[filename] = z.read(found[0])
        observations["zip_members"] = names
    receipt = json.loads(payloads["receipt.json"])
    source = json.loads(payloads["source-manifest.json"])
    check(receipt["junit_sha256"] == digest(payloads["pytest.xml"]), "JUnit hash disagrees with receipt")
    check(receipt["log_sha256"] == digest(payloads["pytest.log"]), "Pytest log hash disagrees with receipt")
    source_files = source["files"]
    canonical = json.dumps(source_files, sort_keys=True, separators=(",", ":")).encode()
    check(source["tree_sha256"] == digest(canonical), "Source-map digest is inconsistent")
    check(receipt["source_tree_sha256"] == source["tree_sha256"], "Receipt source map differs")
    check(source["commit"] == receipt["source_commit"] == expected["checkout"], "Wrong actual checkout")
    check(source["worktree_dirty"] is False and receipt["source_worktree_dirty"] is False,
          "Recorded checkout was dirty before testing")
    check(receipt["source_unchanged_during_test"] is True, "Project source changed during testing")
    check(receipt["source_file_count"] == len(source_files) == len(expected["git_paths"]),
          "Source count differs from the actual Git inventory")
    check(set(source_files) == set(expected["git_paths"]), "Source path inventory differs from Git checkout")
    source_mismatches = []
    for path, pin in expected["critical_sources"].items():
        if source_files.get(path) != pin["sha256"]:
            source_mismatches.append({"path": path, "expected": pin["sha256"], "actual": source_files.get(path)})
    check(not source_mismatches, "Critical source bytes differ from the admitted Git content")
    github = receipt["github"]
    wanted_context = {
        "GITHUB_ACTIONS": "true", "GITHUB_EVENT_NAME": "pull_request",
        "GITHUB_SHA": expected["checkout"], "GITHUB_REF": "refs/pull/84/merge",
        "GITHUB_HEAD_REF": "contribution/external-predictions-ui-current-6e5752b49b6f",
        "GITHUB_BASE_REF": "main", "GITHUB_RUN_ID": str(expected["run_id"]),
    }
    for key, value in wanted_context.items():
        check(github.get(key) == value, "Actions context differs: " + key)
    xml = payloads["pytest.xml"]
    if b"<!DOCTYPE" in xml.upper() or b"<!ENTITY" in xml.upper():
        raise ValueError("Unsupported XML declarations")
    root = ET.fromstring(xml)
    cases = root.findall(".//testcase") if root.tag != "testcase" else [root]
    def disposition(case):
        return "failure" if case.find("failure") is not None else (
            "error" if case.find("error") is not None else (
                "skipped" if case.find("skipped") is not None else "passed"))
    counts = {key: 0 for key in ("tests", "passed", "failures", "errors", "skipped")}
    ui_cases = []
    for case in cases:
        status = disposition(case)
        counts["tests"] += 1
        counts[{"failure": "failures", "error": "errors"}.get(status, status)] += 1
        if case.get("classname") == expected["case_class"]:
            ui_cases.append({"name": case.get("name"), "status": status, "seconds": case.get("time"),
                             "detail": "".join(case.itertext()).strip()})
    selected = [c for c in cases if c.get("name") == expected["case_name"]
                and c.get("classname") == expected["case_class"]]
    check(len(selected) == 1, "Expected one named real MainWindow test case")
    main_case = None
    if len(selected) == 1:
        c = selected[0]
        main_case = {"class": c.get("classname"), "name": c.get("name"),
                     "status": disposition(c), "seconds": c.get("time"),
                     "detail": "".join(c.itertext()).strip()}
        check(main_case["status"] == "passed", "Real MainWindow case was skipped, failed or errored")
    check(counts == receipt["counts"], "Retained counts disagree with actual JUnit case evidence")
    check(receipt["process_exit"] == 0 and type(receipt["process_exit"]) is int,
          "Pytest did not exit normally with zero")
    check(receipt["accepted"] is True and receipt["problems"] == [], "Runner did not accept full suite")
    check(counts["tests"] > 0 and counts["passed"] > 0
          and counts["failures"] == 0 and counts["errors"] == 0, "Suite did not pass")
    text = job_log.decode("utf-8-sig")
    check(expected["checkout"] in text, "Actual checkout SHA absent from hosted job log")
    merge_label = "Merge " + expected["head"] + " into " + expected["base"]
    check(merge_label in text, "Actual merge ancestry absent from hosted job log")
    check(re.search(r"(?i)Windows", text) is not None, "No actual Windows runtime evidence in job log")
    check(re.search(r"(?i)(?:python|cpython).{0,100}3\.12", text) is not None,
          "No actual Python 3.12 evidence in job log")
    trace = [line for line in text.splitlines()
             if expected["checkout"] in line or merge_label in line
             or re.search(r"Windows Server|windows-2022|Successfully set up CPython|pythonLocation:", line)]
    return {
        "accepted": not problems, "problems": problems,
        "scope": "Hosted Windows actual MainWindow plus exact process/JUnit/source receipt; no native test replay",
        "repository": expected["repository"], "pr": expected["pr"],
        "head": expected["head"], "base": expected["base"], "checkout": expected["checkout"],
        "git_tree": expected["git_tree"], "run_id": expected["run_id"], "job_id": expected["job_id"],
        "archive_sha256": digest(archive), "archive_bytes": len(archive),
        "decoded_job_log_sha256": digest(job_log), "decoded_job_log_bytes": len(job_log),
        "job_log_scope": "UTF-8 bytes of the connector-provided decoded hosted job log",
        "members": {name: {"bytes": len(raw), "sha256": digest(raw)} for name, raw in payloads.items()},
        "main_window": main_case, "ui_cases": ui_cases, "suite_counts": counts,
        "process_exit": receipt["process_exit"], "source_file_count": len(source_files),
        "critical_source_count": len(expected["critical_sources"]), "source_mismatches": source_mismatches,
        "source_tree_sha256": source["tree_sha256"],
        "source_unchanged_during_test": receipt["source_unchanged_during_test"],
        "github_context": github, "actual_checkout_runtime_lines": trace,
        "zip_members": observations["zip_members"],
    }
