# SPDX-License-Identifier: GPL-3.0-only
"""Independent offline consumer receiver, frozen before candidate exposure.

Original mode proves the missing command and receives independently authored null
JSON through the actual unchanged evaluator. Candidate mode changes only the
prepare-command source root; the evaluator stays bound to sealed original source.
All mutations are beneath this receiver's new run directory.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback

import pyarrow as pa
import pyarrow.parquet as pq

EXPECTATION_SHA = "b955878b51286b0b53a6c0ccc32ed1c2210e5d79de47154224dd332fb500e1db"
SEAL_SHA = "a9efc28e89e5eaec6fa9d31b1c8b36677dacd202436e8f02404d259ceec3f27a"
PINNED = {
    "libs/python/capture_analysis/capture_analysis/eval/predictions.py": "decff22c1e2e661a3ce21679db68b667ea44fa5b18df8501204d7d23161cc906",
    "libs/python/capture_analysis/capture_analysis/ml_bundle/job.py": "ed67d94ded834d63599797bbd8efb7b26f125bd216f52bcb7f01febb928922ce",
    "libs/python/capture_analysis/capture_analysis/jobs.py": "fa7686685f1a680eb2982191fbd03b3986487e638e95088b56de32d4c183d568",
    "tools/run_analysis.py": "f450b1e17185bb2b19e45747698dd1f75f487c7898304484357abec5bee9f555",
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(path, obj):
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=True, allow_nan=False) + "\n", encoding="utf-8")


def inventory(root):
    result = {}
    for p in sorted(root.rglob("*")):
        if p.is_symlink():
            result[p.relative_to(root).as_posix()] = {"symlink": os.readlink(p)}
        elif p.is_file():
            data = p.read_bytes()
            result[p.relative_to(root).as_posix()] = {"bytes": len(data), "sha256": sha(data)}
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--owner-root", type=Path, required=True)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--phase", choices=("original", "candidate"), required=True)
    args = parser.parse_args()
    owner, source, run = args.owner_root.resolve(), args.source_root.resolve(), args.run_dir
    original = owner / "baseline-source"
    assert not os.path.lexists(run), f"run already exists: {run}"
    assert shutil.disk_usage(run.parent).free > 300_000_000, "bounded receiving capacity guard"
    run.mkdir(mode=0o700)
    logs = run / "calls"
    logs.mkdir()
    for folder in ("tmp", "mpl", "cache"):
        (run / folder).mkdir()
    env = os.environ.copy()
    env.update(PYTHONDONTWRITEBYTECODE="1", MPLBACKEND="Agg", MPLCONFIGDIR=str(run / "mpl"),
               TMPDIR=str(run / "tmp"), XDG_CACHE_HOME=str(run / "cache"))
    env.pop("PYTHONPATH", None)
    expectation_bytes = (owner / "contract/root-independent-expectations.json").read_bytes()
    assert sha(expectation_bytes) == EXPECTATION_SHA
    spec = json.loads(expectation_bytes)["independent_fixture"]
    seal_bytes = (owner / "baseline-source-seal.json").read_bytes()
    assert sha(seal_bytes) == SEAL_SHA
    seal = json.loads(seal_bytes)
    for item in seal["files"]:
        data = (original / item["path"]).read_bytes()
        assert sha(data) == item["sha256"], item["path"]
        assert hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest() == item["git_blob"]
    for rel, digest in PINNED.items():
        assert sha((source / rel).read_bytes()) == digest, f"changed inherited consumer: {rel}"
    before = {"original": inventory(original), "selected_source": inventory(source)}
    save(run / "source-before.json", before)
    cases = []
    calls = []

    def case(name, fn):
        started = time.monotonic()
        try:
            detail = fn()
            item = {"name": name, "passed": True, "detail": detail}
        except Exception as exc:
            item = {"name": name, "passed": False, "error": repr(exc), "traceback": traceback.format_exc()}
        item["seconds"] = time.monotonic() - started
        cases.append(item)
        save(run / "cases-progress.json", cases)
        print(json.dumps({"case": name, "passed": item["passed"]}), flush=True)

    def call(name, command):
        started = time.monotonic()
        try:
            result = subprocess.run(command, cwd=run, env=env, capture_output=True, timeout=90)
            code, stdout, stderr, timed_out = result.returncode, result.stdout, result.stderr, False
        except subprocess.TimeoutExpired as exc:
            code, stdout, stderr, timed_out = None, exc.stdout or b"", exc.stderr or b"", True
        (logs / (name + ".stdout")).write_bytes(stdout)
        (logs / (name + ".stderr")).write_bytes(stderr)
        item = {"name": name, "command": command, "returncode": code, "timed_out": timed_out,
                "seconds": time.monotonic() - started, "stdout_sha256": sha(stdout), "stderr_sha256": sha(stderr)}
        calls.append(item)
        save(logs / (name + ".json"), item)
        assert not timed_out, f"native CLI timeout: {name}"
        return code, stdout, stderr

    def new_package(name, session):
        package = run / name
        shutil.copytree(original / "tests/fixtures/mini_session", package, symlinks=True)
        assert not any(p.is_symlink() for p in package.rglob("*")), "fixture may not import external symlinks"
        manifest = json.loads((package / "manifest.json").read_bytes())
        manifest["sessionId"] = session
        save(package / "manifest.json", manifest)
        return package

    def bundle(package):
        return package / "processing/jobs/bundle/ml_bundle"

    def make_extreme(name, *, boolean_teacher=False, wrong_session=False):
        package = new_package(name, spec["selected_session_id"])
        b = bundle(package)
        b.mkdir(parents=True)
        rows, targets = spec["ordered_windows"], spec["target_columns"]
        arrays = {"window_id": pa.array([r["window_id"] for r in rows], type=pa.string()),
                  "session_time_ns": pa.array([int(r["session_time_ns"]) for r in rows], type=pa.int64()),
                  "valid_mask": pa.array([r["valid_mask"] for r in rows], type=pa.bool_())}
        for i, target in enumerate(targets):
            arrays[target] = pa.array([True, False, True], type=pa.bool_()) if boolean_teacher and i == 1 else pa.array([r["teacher_values"][i] for r in rows], type=pa.float64())
        pq.write_table(pa.table(arrays), b / "windows.parquet")
        save(b / "manifest.json", {"schemaId": "capture.ml_bundle/1", "sessionIds": ["wrong-session" if wrong_session else spec["selected_session_id"]],
                                   "targetColumns": targets, "sha256": {"windows.parquet": sha((b / "windows.parquet").read_bytes()), "manifest.json": "a" * 64}})
        return package

    def expected_doc(package):
        b = bundle(package)
        manifest = json.loads((b / "manifest.json").read_bytes())
        rows = pq.read_table(b / "windows.parquet").to_pylist()
        return {"schemaId": "capture.eval_predictions/1", "modelId": spec["model_id"],
                "windowsSha256": sha((b / "windows.parquet").read_bytes()),
                "manifestSha256": sha((b / "manifest.json").read_bytes()),
                "predictions": [{"window_id": r["window_id"], "session_time_ns": r["session_time_ns"],
                                 "values": {c: None for c in manifest["targetColumns"]}} for r in rows]}

    def prepare(name, package, output):
        return call(name, [sys.executable, str(source / "tools/prepare_predictions.py"), str(package),
                           "--bundle-job", "bundle", "--model-id", spec["model_id"], "--output", str(output)])

    def check_template(package, path):
        raw = path.read_bytes()
        doc = json.loads(raw)
        assert doc == expected_doc(package), "template differs from independently computed identity/null/digest contract"
        assert all(type(row["session_time_ns"]) is int for row in doc["predictions"])
        manifest = json.loads((bundle(package) / "manifest.json").read_bytes())
        assert doc["manifestSha256"] != manifest["sha256"].get("manifest.json"), "copied preimage digest"
        return {"bytes": len(raw), "sha256": sha(raw), "rows": doc["predictions"],
                "manifestSha256": doc["manifestSha256"], "windowsSha256": doc["windowsSha256"]}

    def evaluate(name, package, path, *, accept=True, extreme=False):
        inputs = inventory(package)
        pred_bytes = path.read_bytes()
        code, _, _ = call(name, [sys.executable, str(original / "tools/run_analysis.py"), "eval", str(package),
                                "--ml-bundle-job", "bundle", "--predictions", str(path), "--overwrite-job-id", name])
        after = inventory(package)
        assert all(after.get(p) == v for p, v in inputs.items()), "evaluator changed an existing package input"
        assert path.read_bytes() == pred_bytes
        job = package / "processing/jobs" / name
        if not accept:
            assert code == 1, f"invalid input CLI exit {code}"
            assert not (job / "eval").exists(), "refused input left evaluation outputs"
            return {"returncode": code, "evaluation_outputs_absent": True}
        assert code == 0, f"actual evaluator CLI exit {code}"
        report = json.loads((job / "eval/eval_report.json").read_bytes())
        assert report["evaluationMode"] == "external_predictions" and report["baseline"] is None
        assert report["heldOutValidation"] == "not_established" and report["provisional"] is True
        assert report["modelId"] == spec["model_id"]
        src = pq.read_table(bundle(package) / "windows.parquet").to_pylist()
        for target, metric in report["metrics"].items():
            assert metric["n"] == 0 and metric["mae"] is None and metric["rmse"] is None and metric["pearsonR"] is None
            assert metric["pearsonReason"] == "insufficient_pairs"
            if extreme:
                assert metric["excluded"] == {"invalidWindow": 1, "nonfiniteTeacher": 0, "missingPrediction": 2}
        result_table = pq.read_table(job / "eval/predictions.parquet")
        assert result_table.schema.field("session_time_ns").type == pa.int64()
        got = result_table.to_pylist()
        assert [(r["window_id"], r["session_time_ns"]) for r in got] == [(r["window_id"], r["session_time_ns"]) for r in src]
        assert (job / "eval/prediction_input.json").read_bytes() == pred_bytes
        assert (job / "eval/source_bundle_manifest.json").read_bytes() == (bundle(package) / "manifest.json").read_bytes()
        for key, expected in (("predictionsSha256", sha(pred_bytes)), ("windowsSha256", sha((bundle(package) / "windows.parquet").read_bytes())), ("manifestSha256", sha((bundle(package) / "manifest.json").read_bytes()))):
            assert report["inputProvenance"][key] == expected
        manifest = json.loads((job / "job_manifest.json").read_bytes())
        outputs = manifest["outputs"]
        for item in outputs:
            data = (job / item["relativePath"]).read_bytes()
            assert len(data) == item["bytes"] and sha(data) == item["sha256"]
        return {"report": report, "output_inventory_verified": len(outputs), "output_map": inventory(job), "input_files_preserved": len(inputs)}

    extreme = make_extreme("extreme-session")
    native = new_package("native-session", "template-native-fixture")
    bundle(native).mkdir(parents=True)
    for name, digest in (("windows.parquet", "e7a5157cc6a524411ab56b737c8a6ed36cbb3d36b123836ac8530b1e54bb520f"),
                         ("manifest.json", "11f82d4fd269a688d0316c0415ec57492265f9e1b55e221b2169a282b7d2c6ab")):
        data = (owner / "original-native/package/processing/jobs/bundle/ml_bundle" / name).read_bytes()
        assert sha(data) == digest
        (bundle(native) / name).write_bytes(data)
    original_inputs = {"extreme": inventory(extreme), "native": inventory(native)}
    save(run / "fixture-inputs.json", original_inputs)
    outputs = {"extreme": run / "extreme-template.json", "native": run / "native-template.json"}

    def capability():
        code, _, stderr = prepare("prepare-extreme", extreme, outputs["extreme"])
        if args.phase == "original":
            assert not (source / "tools/prepare_predictions.py").exists()
            assert code == 2 and b"prepare_predictions.py" in stderr and not outputs["extreme"].exists()
            return {"missing_command_exit": code, "capability_absent": True}
        assert code == 0
        return check_template(extreme, outputs["extreme"])
    case("actual_template_command", capability)

    if args.phase == "original":
        for key, package in (("extreme", extreme), ("native", native)):
            save(outputs[key], expected_doc(package))
    else:
        def native_template():
            code, _, _ = prepare("prepare-native", native, outputs["native"])
            assert code == 0
            return check_template(native, outputs["native"])
        case("actual_native_producer_template", native_template)
    case("unchanged_cli_extreme_null_consumer", lambda: evaluate("peer-eval-extreme", extreme, outputs["extreme"], extreme=True))
    case("unchanged_cli_actual_producer_consumer", lambda: evaluate("peer-eval-native", native, outputs["native"]))

    if args.phase == "candidate":
        def deterministic():
            destination = run / "same-source-new-name.json"
            assert prepare("prepare-identical", extreme, destination)[0] == 0
            assert destination.read_bytes() == outputs["extreme"].read_bytes()
            return {"sha256": sha(destination.read_bytes())}
        case("deterministic_single_json", deterministic)

        def destinations():
            sentinel = run / "existing.json"
            sentinel.write_bytes(b"peer-owned sentinel\x00\xff\n")
            directory = run / "existing-directory"
            directory.mkdir()
            live = run / "existing-link.json"
            live.symlink_to(sentinel)
            dangling = run / "dangling-link.json"
            dangling.symlink_to(run / "does-not-exist.json")
            table = bundle(extreme) / "windows.parquet"
            manifest = bundle(extreme) / "manifest.json"
            prior = {"sentinel": sentinel.read_bytes(), "live": os.readlink(live), "dangling": os.readlink(dangling), "table": table.read_bytes(), "manifest": manifest.read_bytes()}
            codes = []
            for i, path in enumerate((sentinel, directory, live, dangling, table, manifest)):
                code, _, _ = prepare(f"refuse-destination-{i}", extreme, path)
                assert code != 0
                codes.append(code)
            assert sentinel.read_bytes() == prior["sentinel"] and os.readlink(live) == prior["live"] and os.readlink(dangling) == prior["dangling"]
            assert directory.is_dir() and not list(directory.iterdir())
            assert table.read_bytes() == prior["table"] and manifest.read_bytes() == prior["manifest"]
            return {"six_refusal_exits": codes, "all_existing_identities_preserved": True}
        case("six_existing_destinations", destinations)

        def refusal(name, **kwargs):
            package = make_extreme(name, **kwargs)
            prior = inventory(package)
            directory = run / (name + "-destination")
            directory.mkdir()
            output = directory / "never.json"
            code, _, _ = prepare(name, package, output)
            assert code != 0 and not os.path.lexists(output)
            assert inventory(package) == prior and not list(directory.iterdir())
            return {"returncode": code, "inputs_exact": True, "no_final_or_temporary_output": True}
        case("late_boolean_teacher_refused", lambda: refusal("boolean-teacher", boolean_teacher=True))
        case("selected_session_mismatch_refused", lambda: refusal("wrong-session", wrong_session=True))

        def exact_manifest():
            package = make_extreme("whitespace-session")
            old = run / "before-whitespace.json"
            assert prepare("prepare-before-whitespace", package, old)[0] == 0
            manifest = bundle(package) / "manifest.json"
            manifest.write_bytes(manifest.read_bytes() + b" \n\t")
            new = run / "after-whitespace.json"
            assert prepare("prepare-after-whitespace", package, new)[0] == 0
            detail = check_template(package, new)
            before_doc, after_doc = json.loads(old.read_bytes()), json.loads(new.read_bytes())
            assert before_doc["manifestSha256"] != after_doc["manifestSha256"]
            before_doc.pop("manifestSha256"); after_doc.pop("manifestSha256")
            assert before_doc == after_doc
            detail["stale_refusal"] = evaluate("peer-stale-digest", package, old, accept=False)
            return detail
        case("exact_final_manifest_bytes", exact_manifest)

    after = {"original": inventory(original), "selected_source": inventory(source)}
    save(run / "source-after.json", after)
    case("source_and_original_inputs_preserved", lambda: preservation(before, after, original_inputs, extreme, native))
    receipt = {"schema": "prediction_template_peer_receiving/1", "phase": args.phase,
               "receiver_sha256": sha(Path(__file__).read_bytes()), "expectations_sha256": EXPECTATION_SHA,
               "baseline_seal_sha256": SEAL_SHA, "source": str(source), "actual_evaluator_source": str(original),
               "python": sys.version, "cases": cases, "calls": calls,
               "passed": sum(c["passed"] for c in cases), "failed": sum(not c["passed"] for c in cases),
               "limits": ["No model or inference executed; these are unavailable editable placeholders.",
                          "Extreme timestamps use independently authored Arrow data; native bundle control uses exact producer bytes inside a valid copied fixture envelope.",
                          "No publication-race injection, resource-limit stress, browser, install, or whole-project test replay.",
                          "Actual original evaluator CLI, not merely its private admission helper, consumes both accepted files.",
                          "Partial original source snapshot; inherited runtime and schemas pinned, no full checkout qualification."]}
    save(run / "receipt.json", receipt)
    print(json.dumps({"receipt": str(run / "receipt.json"), "sha256": sha((run / "receipt.json").read_bytes()), "passed": receipt["passed"], "failed": receipt["failed"]}), flush=True)
    return bool(receipt["failed"])


def preservation(before, after, inputs, extreme, native):
    assert before == after
    for key, package in (("extreme", extreme), ("native", native)):
        current = inventory(package)
        assert all(current.get(p) == v for p, v in inputs[key].items())
    return {"source_trees_unchanged": True, "original_fixture_inputs_unchanged": True}


if __name__ == "__main__":
    raise SystemExit(main())
