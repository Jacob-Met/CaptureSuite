"""Seal retained offline peer receiving; never execute product code."""
from pathlib import Path
import gzip, hashlib, io, json, os, tarfile, shutil
import xml.etree.ElementTree as ET
P=Path('/Users/me/Developer/capturesuite-prediction-template-peer-20261008-713adaab')
O=Path('/Users/me/Developer/capturesuite-prediction-template-20261008-713adaab')
OUT=P/'sealed-peer'
assert not OUT.exists()
assert shutil.disk_usage(P).free>100_000_000
OUT.mkdir(mode=0o700)
payload={}; links=[]
def sha(b): return hashlib.sha256(b).hexdigest()
def enc(x): return (json.dumps(x,indent=2,ensure_ascii=True,allow_nan=False)+'\n').encode()
def add(name,path,h=None):
 assert not path.is_symlink()
 b=path.read_bytes()
 if h is not None: assert sha(b)==h,path
 assert name not in payload
 payload[name]=b
for name in ['receive_prediction_template.py','blind-freeze.json','root-independent-expectations.json','baseline-source-seal.json','original-receiving-custody.json','original-selector-source-review.json','candidate-r1-source-review.json','audit_author_readback.py.txt','seal_prediction_peer.py']:
 add('peer/'+name,P/name)
assert sha(payload['peer/receive_prediction_template.py'])=='c03601928e05f357f73fd9bf7366ea4f45ce923031133f09b2893aff3bd98061'
phases={}
for phase,h,count in [('original-r1','659dc43d9442520a11376baecd95c5913b306360b90b70e6214a72280a4ae64f',4),('candidate-r1','1bd6eb8ca35d9006faab815ad1aa88feab0d08dc58345cc6616d20729894b94e',10)]:
 r=P/phase;b=(r/'receipt.json').read_bytes();assert sha(b)==h
 receipt=json.loads(b);assert receipt['passed']==count and receipt['failed']==0
 assert (r/'source-before.json').read_bytes()==(r/'source-after.json').read_bytes()
 for call in receipt['calls']:
  for stream in ['stdout','stderr']: assert sha((r/'calls'/(call['name']+'.'+stream)).read_bytes())==call[stream+'_sha256']
 for path in sorted(r.rglob('*')):
  rel=path.relative_to(r)
  if rel.parts[0] in {'tmp','mpl','cache'}:continue
  name='peer/'+phase+'/'+rel.as_posix()
  if path.is_symlink():links.append({'path':name,'target':os.readlink(path),'preserved_as':'metadata only; not followed or archived as a link'})
  elif path.is_file():add(name,path)
 phases[phase]={'receipt_sha256':h,'passed_groups':count,'failed_groups':0,'raw_calls_verified':len(receipt['calls'])}
seal=json.loads((O/'baseline-source-seal.json').read_bytes())
for item in seal['files']:add('source-original/'+item['path'],O/'baseline-source'/item['path'],item['sha256'])
owned=json.loads((O/'candidate-r1-source.json').read_bytes())['owned']
for rel,h in owned.items():
 if not rel.startswith('tests/'):add('source-additions/'+rel,O/'candidate'/rel,h)
for rel in ['candidate-r1-source.json','context-supplement.json','receiving-r1/receipt.json','receiving-r1/pytest.stdout','receiving-r1/pytest.stderr','receiving-r1/pytest.xml','receiving-r2/receipt.json','receiving-r2/pytest.stdout','receiving-r2/pytest.stderr','receiving-r2/pytest.xml']:
 add('author-readback/'+rel,O/rel)
author=json.loads(payload['author-readback/receiving-r2/receipt.json'])
assert author['counts']=={'tests':78,'failures':0,'errors':0,'skipped':0,'passed':78}
assert author['exit_code']==0 and author['source_before']==author['source_after']
tree=ET.fromstring(payload['author-readback/receiving-r2/pytest.xml'])
assert len(tree.findall('.//testcase'))==78
assert not any(tree.findall('.//'+k) for k in ['failure','error','skipped'])
for rel,h in author['source_after'].items():assert sha((O/'candidate'/rel).read_bytes())==h
summary={
 'schema':'prediction_template_independent_acceptance/1','actor':'chatgpt:/root/mac_execution',
 'decision':'Accept pinned candidate for the received native consumer scope; no source blocker found.',
 'receiver_sha256':sha(payload['peer/receive_prediction_template.py']),
 'root_expectations_sha256':sha(payload['peer/root-independent-expectations.json']),
 'blind_boundary':'Receiver frozen before candidate source or author tests; unchanged between original and candidate. Author stdout read only during later recovery, after the receiver and original controls were frozen.',
 'source':{'canonical_commit':seal['ref'],'partial_original_leaves':len(seal['files']),'candidate_owned':owned},
 'peer_receiving':phases,
 'author_receiving_separate':{'receipt_sha256':sha(payload['author-readback/receiving-r2/receipt.json']),'counts':author['counts'],'seconds':author['elapsed_seconds'],'source_files_verified':len(author['source_after']),'r1_disposition':'Collection error due to omitted unchanged test_pose_job.py fixture helper; zero product tests. Original failure and exact context supplement retained. No owner driver replay by peer.'},
 'claims':[
 'Actual prepare CLI preserves three-row order, exact signed-int64 2^53+1/-1/maximum, target identity and all-null values.',
 'Both actual generated extreme and original-native-producer templates reach the unchanged original user-facing evaluator CLI; output identity, final provenance and every job inventory digest are verified.',
 'Extreme fixture metrics are n=0, null MAE/RMSE/Pearson, insufficient_pairs, exclusions invalidWindow=1/nonfiniteTeacher=0/missingPrediction=2 for each target.',
 'Six existing regular/directory/link/source destinations survive refusal exactly. Late Boolean teacher and wrong-session admission leave no final or staging file.',
 'Manifest whitespace changes the bound final digest; unchanged evaluator rejects stale input. Identical source and exact label produce deterministic bytes.',
 'All original fixture inputs and source trees unchanged; no source/test edits, dependency installation, model inference, browser run or hosted write.'],
 'limits':[
 'Partial canonical source snapshot; no whole-repository or Windows execution qualification.',
 'Peer does not inject publication race or 64MiB resource stress. Author tests remain separately attributed.',
 'Extreme data is independently authored Arrow; native producer control retains exact prior producer bytes in a valid copied package envelope.',
 'Structural all-null acceptance implies no model execution, accuracy or held-out validation.',
 'No hostile-filesystem, concurrent parent replacement, package transaction or power-loss guarantee.',
 'Root authorized owner recovery readback during a model-capacity interruption; owner identity and source ownership remain unchanged.',
 'Actions and hosted integration remain held.'],
 'sealer_preparation':'Local scratch ENOSPC left only a zero-byte draft; native sealer was then written directly. No native product run or owner mutation during sealing.'
}
payload['acceptance.json']=enc(summary)
payload['link-metadata.json']=enc(links)
payload['README.md']=b"""# Independent prediction-template consumer receiving

This packet retains the blind receiver, original missing-command witness,
original actual consumer controls and one unchanged candidate receiver run.
See acceptance.json for exact attribution and limits. Author 78-case readback
is separate: peer did not rerun its gate.

source-original is a 161-leaf exact partial canonical source snapshot, not a
complete Git checkout. source-additions contains reviewed helper, CLI and guide.
The author maintained tests remain in the owner's separate packet. Peer packages
are disposable synthetic fixtures; the actual installed interpreter and commands
are recorded in the raw receipts.

Own temporary/MPL/cache directories are omitted. Links are metadata only, never
followed or emitted as archive links. No account/session data or model artifacts
are included. Hosted Actions and integration remain held.
"""
manifest={'schema':'prediction_template_peer_payload_manifest/1','files':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(payload.items())]}
payload['manifest.json']=enc(manifest)
archive=OUT/'peer-receiving.tar.gz'
with archive.open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
   for name,data in sorted(payload.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;info.uid=info.gid=0
    tar.addfile(info,io.BytesIO(data))
assert archive.stat().st_size<8*1024*1024
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(payload) and all(m.isfile() for m in members)
 for member in members:assert tar.extractfile(member).read()==payload[member.name]
for name in ['acceptance.json','manifest.json','README.md']:(OUT/name).write_bytes(payload[name])
result={'schema':'prediction_template_peer_seal/1','archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members_reopened_exact':len(payload),'payload_bytes':sum(map(len,payload.values())),'manifest_sha256':sha(payload['manifest.json']),'acceptance_sha256':sha(payload['acceptance.json']),'links_metadata_only':len(links),'product_executions_during_sealing':0}
(OUT/'sealed.json').write_bytes(enc(result))
print(json.dumps(result),flush=True)
