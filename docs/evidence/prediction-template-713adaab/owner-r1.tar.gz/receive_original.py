from pathlib import Path
import json,sys,hashlib,importlib.util,datetime,traceback
from types import SimpleNamespace
import numpy as np,pandas as pd,pyarrow
ROOT=Path(__file__).resolve().parent
BASE=Path('/Users/me/Developer/capturesuite-ml-bundle-metadata-20261008-713adaab')
for name in ('capture_analysis','capture_session','capture_protocol','capture_worker'):
 sys.path.insert(0,str(BASE/'libs/python'/name))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(name,relative):
 path=ROOT/'source'/relative
 spec=importlib.util.spec_from_file_location(name,path)
 m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 return m
producer=load('original_producer','libs/python/capture_analysis/capture_analysis/ml_bundle/job.py')
evaluator=load('original_evaluator','libs/python/capture_analysis/capture_analysis/eval/predictions.py')
assert sha(Path(producer.__file__))=='ed67d94ded834d63599797bbd8efb7b26f125bd216f52bcb7f01febb928922ce'
assert evaluator.REGISTRY_PATH.read_bytes()==(ROOT/'source/schemas/kinematics/kinematics_columns.registry.json').read_bytes()
source_before={str(p.relative_to(ROOT/'source')):sha(p) for p in (ROOT/'source').rglob('*') if p.is_file()}
source_before['runner']=sha(Path(__file__))
case=ROOT/'original-native';case.mkdir(exist_ok=False)
pkg=case/'package'
kin=pkg/'processing/jobs/kin/kinematics/kinematics.parquet'
feat=pkg/'processing/jobs/feat/features/radar/stream/energy.parquet'
kin.parent.mkdir(parents=True);feat.parent.mkdir(parents=True)
times=[0,100_000_000,200_000_000,300_000_000,400_000_000]
teacher={'session_time_ns':times,'valid_elbow_L':[True]*5,'valid_elbow_R':[True]*5}
for i,c in enumerate(producer.DEFAULT_TARGET_COLUMNS,1):teacher[c]=[i*v for v in [10.,20.,30.,40.,50.]]
pd.DataFrame(teacher).to_parquet(kin,index=False)
pd.DataFrame({'session_time_ns':times,'energy':[10.,20.,30.,40.,50.]}).to_parquet(feat,index=False)
input_before={str(p.relative_to(case)):sha(p) for p in (kin,feat)}
out=pkg/'processing/jobs/bundle';outputs=[];warnings=[]
result=producer.run_ml_bundle_job(pkg,out,SimpleNamespace(session_id='template-native-fixture'),kinematics_job_id='kin',features_job_id='feat',window_sec=.2,hop_sec=.1,outputs=outputs,warnings=warnings)
man=out/'ml_bundle/manifest.json';win=out/'ml_bundle/windows.parquet'
manifest=json.loads(man.read_bytes());frame=pd.read_parquet(win)
pred={'schemaId':'capture.eval_predictions/1','modelId':'authored-prediction-placeholder','windowsSha256':sha(win),'manifestSha256':sha(man),'predictions':[{'window_id':row['window_id'],'session_time_ns':int(row['session_time_ns']),'values':{c:None for c in producer.DEFAULT_TARGET_COLUMNS}} for row in frame.to_dict('records')]}
records=[]
for name,digest in [('actual-final-file',sha(man)),('internal-preimage-value',manifest['sha256']['manifest.json'])]:
 doc=dict(pred,manifestSha256=digest)
 p=case/(name+'.json');p.write_text(json.dumps(doc,indent=2,allow_nan=False)+'\n')
 try:
  loaded=evaluator._load_inputs(pkg,'bundle',p,'template-native-fixture')
  record={'case':name,'accepted':True,'window_count':len(loaded[0]),'provenance':loaded[3]['provenance'],'all_predictions_missing':all(np.isnan(a).all() for a in loaded[2].values())}
 except Exception as exc:
  record={'case':name,'accepted':False,'exception_type':type(exc).__name__,'message':str(exc)}
 record['input_sha256']=sha(p);records.append(record)
assert records[0]['accepted'] and records[0]['window_count']==3 and records[0]['all_predictions_missing']
assert not records[1]['accepted'] and records[1]['exception_type']=='ValueError'
assert {str(p.relative_to(case)):sha(p) for p in (kin,feat)}==input_before
for item in outputs:
 p=out/item['relativePath'];assert sha(p)==item['sha256'] and p.stat().st_size==item['bytes']
source_after={str(p.relative_to(ROOT/'source')):sha(p) for p in (ROOT/'source').rglob('*') if p.is_file()};source_after['runner']=sha(Path(__file__))
assert source_before==source_after
imports={}
for name,m in list(sys.modules.items()):
 p=getattr(m,'__file__',None)
 if p and ('capture_analysis' in name or 'capture_session' in name):
  p=Path(p)
  if p.is_file():imports[name]={'path':str(p),'sha256':sha(p)}
doc={'schema':'capture.prediction-template.original-native/1','recorded_utc':datetime.datetime.now(datetime.UTC).isoformat(),'producer_ref':'3960c0c756cd4e9facbde0d76eaaa3c31ab7c167','scope':'Exact current producer and evaluator module bytes with pinned existing native dependency context. Direct producer and maintained evaluator input-boundary receiving; not a whole-current-tree CLI run or completed inference. Current source tree lacks a template command; this is a capability baseline, not an alleged documented-consumer regression.','python':sys.version,'executable':sys.executable,'pandas':pd.__version__,'pyarrow':pyarrow.__version__,'source_before':source_before,'source_after':source_after,'imported_context':imports,'inputs':input_before,'outputs':outputs,'result':result,'warnings':warnings,'actual_final_manifest_sha256':sha(man),'internal_preimage_value':manifest['sha256']['manifest.json'],'consumer_cases':records,'artifact_map':{str(p.relative_to(case)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in case.rglob('*') if p.is_file()}}
p=ROOT/'original-native-receipt.json';p.write_text(json.dumps(doc,indent=2,allow_nan=False)+'\n')
print(json.dumps({'receipt':str(p),'sha256':sha(p),'cases':records,'warnings':warnings,'inputs_unchanged':True,'sources_unchanged':True}))
