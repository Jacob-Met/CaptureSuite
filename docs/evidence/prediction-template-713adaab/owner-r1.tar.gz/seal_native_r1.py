from pathlib import Path
import os,json,hashlib,tarfile,stat,datetime,xml.etree.ElementTree as ET
root=Path('/Users/me/Developer/capturesuite-prediction-template-20261008-713adaab')
custody=root/'custody';custody.mkdir(exist_ok=False)
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
pinned=json.loads((root/'candidate-r1-source.json').read_bytes())
for p,h in pinned['owned'].items():assert sha(root/'candidate'/p)==h,p
r2=json.loads((root/'receiving-r2/receipt.json').read_bytes())
assert r2['counts']=={'tests':78,'failures':0,'errors':0,'skipped':0,'passed':78}
for p,h in r2['source_after'].items():assert sha(root/'candidate'/p)==h,p
selected=[]
exclude={'custody','peer-review','lint-proposal','.git','__pycache__','.pytest_cache','.ruff_cache','matplotlib-cache'}
for folder,dirs,files in os.walk(root,followlinks=False):
 dirs[:]=sorted(d for d in dirs if d not in exclude)
 for name in sorted(files):
  p=Path(folder)/name;rel=p.relative_to(root).as_posix()
  st=p.lstat()
  if stat.S_ISLNK(st.st_mode):
   selected.append({'path':rel,'kind':'symlink_metadata_only','target':os.readlink(p)})
  elif stat.S_ISREG(st.st_mode):
   selected.append({'path':rel,'kind':'regular','bytes':st.st_size,'sha256':sha(p)})
  else:raise RuntimeError('Unexpected nonregular artifact '+rel)
archive=custody/'native-r1-receiving.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tf:
 for item in selected:
  if item['kind']=='regular':tf.add(root/item['path'],arcname=item['path'],recursive=False)
verified=0
with tarfile.open(archive,'r:gz') as tf:
 members=tf.getmembers();expected=[x for x in selected if x['kind']=='regular']
 assert len(members)==len(expected)
 for member,item in zip(members,expected,strict=True):
  assert member.name==item['path'] and member.isfile()
  f=tf.extractfile(member)
  assert hashlib.file_digest(f,'sha256').hexdigest()==item['sha256']
  assert sha(root/item['path'])==item['sha256']
  verified+=1
peer=root/'peer-review'
peer_pins={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in peer.iterdir() if p.is_file()}
report={'schema':'capture.prediction-template.native-custody/1','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_ref':'3960c0c756cd4e9facbde0d76eaaa3c31ab7c167','candidate_owned':pinned['owned'],'qualification':{'owner_receipt_sha256':sha(root/'receiving-r2/receipt.json'),'counts':r2['counts'],'source_carrier_files':len(r2['source_after']),'original_collection_failure_sha256':sha(root/'receiving-r1/receipt.json'),'context_supplement_sha256':sha(root/'context-supplement.json'),'lint_receipt_sha256':sha(root/'lint-readonly/receipt.json')},'archive':{'name':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'regular_members_verified':verified},'peer_adopted_separately':peer_pins,'files':selected,'limits':'No product replay during sealing. Exact r1 lint failure remains unresolved here; no Windows/full-repo/hosted/installed qualification. Synthetic links are metadata-only; shared dependencies and generated cache excluded.'}
manifest=custody/'manifest.json';manifest.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'manifest':str(manifest),'manifest_sha256':sha(manifest),'archive':report['archive'],'total_file_entries':len(selected),'links_metadata_only':sum(x['kind']!='regular' for x in selected),'owned':pinned['owned'],'peer':peer_pins}))
