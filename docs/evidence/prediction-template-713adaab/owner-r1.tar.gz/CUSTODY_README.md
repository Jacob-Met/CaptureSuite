# CaptureSuite prediction-template native candidate r1

Native claim5149 owns only the additive prediction-template helper/CLI, dedicated maintained test and contract. Current original source is3960c0c756cd4e9facbde0d76eaaa3c31ab7c167/tree d1af33caaf7154e83def1dab035920907d417e8d. The existing producer, evaluator, schema and job CLI remain unchanged.

This frozen r1 behavior passed78 maintained/inherited cases (46new,32inherited), zero failures/errors/skips, in18.7946 seconds. The separately frozen peer receiver passed10candidate groups and4original groups, including actual new-command output and unchanged real evaluation. All-null templates retain exact signed-int64 row identity and yield zero scored pairs, never a claimed inference.

The initial r1 owner attempt did not execute product tests: collection stopped because the partial source carrier omitted unchanged tests/analysis/test_pose_job.py. Its raw stdout/stderr/JUnit and receipt4620467b are retained. The exact canonical helper is an immutable context supplement (afe50f7a receipt), after which r2 executed unchanged candidate/test bytes successfully. The original161-leaf source seal is retained; corrected carrier has166 files.

Owner capsule contains exact source copies, authored/peer expectation packets, original native witness, full raw receiving fixtures/logs/JUnit, drivers and read-only lint/gate records. Regular-file members are hashed and reopened. Synthetic link identities are recorded only in the member manifest; links are not installed as archive links, and their ordinary owned targets are preserved separately. Shared Python dependencies and disposable Matplotlib cache are excluded. This capsule is a partial exact source carrier and evidence package, not a full repository checkout.

Peer archive is copied byte-exact separately under peer-review, with its acceptance and member manifest. Its evidence is independently authored; owner receiving is not counted as independent replay. The original manifest preimage mismatch is retained as a compatibility observation, not a documented evaluator regression.

Ruff found7 owned-file findings after native behavior qualification:3import-order blocks,2long lines and2broad exception assertions in maintained tests. This frozen source has not been edited to hide that remaining gate. A separate minimal correction can be reviewed; r1 behavioral evidence must remain bound to r1 bytes.

No hosted write, PR, Actions trigger, installed change or Windows qualification is included. Current CI triggers all pull requests and main/master pushes; camera and release triggers are retained in workflow-inventory. Branch-only storage may be nontriggering under the inspected configurations, subject to fresh root review. Main integration, full required equivalent gates and installed adoption remain pending.
