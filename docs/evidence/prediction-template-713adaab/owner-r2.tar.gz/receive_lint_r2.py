from pathlib import Path
import sys,os,subprocess,json,hashlib,datetime,time,xml.etree.ElementTree as ET
root=Path('/Users/me/Developer/capturesuite-prediction-template-20261008-713adaab')
source=root/'candidate-r2';out=root/'receiving-lint-r2';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths={str(p.relative_to(source)):sha(p) for p in source.rglob('*') if p.is_file()}
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=os.pathsep.join([str(source),*[str(source/'libs/python'/n) for n in ('capture_analysis','capture_session','capture_protocol')]]),MPLBACKEND='Agg',MPLCONFIGDIR=str(out/'matplotlib-cache'))
py='/Users/me/Developer/capturesuite-analysis-provenance-20261008/.venv-analysis/bin/python'
command=[py,'-B','-m','pytest','tests/analysis/test_prediction_template.py','-vv','-ra','-p','no:cacheprovider','--basetemp',str(out/'fixtures'),'--junitxml',str(out/'pytest.xml')]
ruff_command=[py,'-B','-m','ruff','check','--no-cache','libs/python/capture_analysis/capture_analysis/eval/template.py','tools/prepare_predictions.py','tests/analysis/test_prediction_template.py']
with (out/'ruff.stdout').open('xb') as stdout,(out/'ruff.stderr').open('xb') as stderr:
 ruff_result=subprocess.run(ruff_command,cwd=source,env=env,stdout=stdout,stderr=stderr,timeout=60)
start=time.monotonic();timed_out=False
with (out/'pytest.stdout').open('xb') as stdout,(out/'pytest.stderr').open('xb') as stderr:
 try:
  result=subprocess.run(command,cwd=source,env=env,stdout=stdout,stderr=stderr,timeout=180)
  status=result.returncode
 except subprocess.TimeoutExpired:
  timed_out=True;status=None
elapsed=time.monotonic()-start
counts=None
if not timed_out and (out/'pytest.xml').is_file():
 cases=list(ET.parse(out/'pytest.xml').getroot().iter('testcase'))
 counts={'tests':len(cases),'failures':sum(c.find('failure') is not None for c in cases),'errors':sum(c.find('error') is not None for c in cases),'skipped':sum(c.find('skipped') is not None for c in cases)}
 counts['passed']=counts['tests']-counts['failures']-counts['errors']-counts['skipped']
after={str(p.relative_to(source)):sha(p) for p in source.rglob('*') if p.is_file()}
d={'recorded_utc':datetime.datetime.now(datetime.UTC).isoformat(),'scope':'Approved lint-only r2; two assertion narrowings were post-exposure. Exactly owned focused cases, no inherited broad-suite replay.','ruff_command':ruff_command,'ruff_exit_code':ruff_result.returncode,'command':command,'exit_code':status,'timeout_seconds':180,'timed_out':timed_out,'elapsed_seconds':elapsed,'counts':counts,'source_before':paths,'source_after':after,'source_unchanged':paths==after,'artifacts':{p.name:sha(p) for p in out.iterdir() if p.is_file()},'driver_sha256':sha(Path(__file__))}
p=out/'receipt.json';p.write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({'receipt':str(p),'sha256':sha(p),'counts':counts,'exit_code':status,'timed_out':timed_out,'seconds':elapsed,'source_unchanged':paths==after}))
