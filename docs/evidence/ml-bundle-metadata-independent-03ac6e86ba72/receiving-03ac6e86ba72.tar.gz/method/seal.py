# SPDX-License-Identifier: GPL-3.0-only
"""Read back the receiving archive against the original evidence files."""
import hashlib
import json
import tarfile
from pathlib import Path

root = Path(__file__).resolve().parent
archive = root / "receiving-03ac6e86ba72.tar.gz"
files = {}
with tarfile.open(archive, "r:gz") as tar:
    for member in tar.getmembers():
        if member.isdir():
            continue
        if not member.isfile():
            raise RuntimeError(f"unexpected archive member type: {member.name}")
        name = member.name.removeprefix("./")
        parts = Path(name).parts
        if not parts or name.startswith("/") or ".." in parts or name in files:
            raise RuntimeError(f"invalid or duplicate archive path: {name}")
        data = tar.extractfile(member).read()
        original = root / "evidence" / name
        if data != original.read_bytes():
            raise RuntimeError(f"archive differs from original evidence: {name}")
        files[name] = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(), "mode": oct(member.mode)}
record = {
    "schema": "capture.ml_bundle.independent_receiving_packet/1",
    "archive": archive.name,
    "archive_bytes": archive.stat().st_size,
    "archive_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
    "member_count": len(files),
    "expanded_bytes": sum(x["bytes"] for x in files.values()),
    "receipt_sha256": files["receipt.json"]["sha256"],
    "files": dict(sorted(files.items())),
}
(root / "manifest.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print(json.dumps({k: v for k, v in record.items() if k != "files"}))
