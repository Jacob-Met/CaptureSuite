# SPDX-License-Identifier: GPL-3.0-only
"""Package explicit evidence files without host-generated AppleDouble records."""
import hashlib
import json
import tarfile
from pathlib import Path

root = Path(__file__).resolve().parent
archive = root / "receiving-03ac6e86ba72.tar.gz"
initial = root / "receiving-initial-macos-metadata.tar.gz"
archive.rename(initial)
with tarfile.open(initial, "r:gz") as tar:
    extra = [m.name for m in tar.getmembers() if any(p.startswith("._") for p in Path(m.name).parts)]
record = {
    "stage": "archive readback before publication",
    "outcome": "failed",
    "reason": "macOS tar added AppleDouble members absent from the source evidence directory",
    "exception": "FileNotFoundError for evidence/._.",
    "initial_archive": str(initial),
    "initial_archive_bytes": initial.stat().st_size,
    "initial_archive_sha256": hashlib.sha256(initial.read_bytes()).hexdigest(),
    "unexpected_members": extra,
    "correction": "Package explicit regular evidence files with Python standard-library tarfile; no product, input, output or assertion changed; no CLI replay",
}
(root / "evidence/packaging-preparation.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
with tarfile.open(archive, "w:gz", format=tarfile.PAX_FORMAT) as tar:
    for path in sorted((root / "evidence").rglob("*")):
        if path.is_file() and "matplotlib-cache" not in path.parts:
            tar.add(path, arcname=str(path.relative_to(root / "evidence")), recursive=False)
print(json.dumps({"archive": str(archive), "bytes": archive.stat().st_size, "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}))
