# SPDX-License-Identifier: GPL-3.0-only
"""Independent frozen-source, real-CLI ML bundle and consumer receiving."""
from __future__ import annotations

import datetime
import hashlib
import json
import math
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

import jsonschema
import numpy
import pandas as pd
import pyarrow

HERE = Path(__file__).resolve().parent
EVIDENCE = HERE / "evidence"
PHASES = {
    "baseline": "70f34e3b982523b544a9370d2316a1b69d79bd70",
    "candidate": "f151a1d85a9c9e09c7708701c4a1faadfe0ad777",
}
TARGETS = ["theta_elbow_flex_L", "theta_elbow_flex_R", "omega_elbow_flex_L", "omega_elbow_flex_R"]
# Expected values were selected independently before running either producer.
CASES = [
    {
        "name": "irregular_medians_nearest_ties",
        "t": [i * 100_000_000 for i in range(11)],
        "y": [5, 90, 17, 80, 25, 70, 31, 60, 43, 50, 59],
        "omega": [-3, 2, 5, -8, 13, 21, -34, 55, 89, -144, 233],
        "invalid": [6],
        "feature_t": [0, 400_000_000, 600_000_000, 800_000_000, 1_000_000_000],
        "energy": [200, 500, 900, 1300, 1700],
        "window": 0.4000000019, "hop": 0.2500000009, "rate": 99.0,
        "half_ns": 200_000_000, "hop_ns": 250_000_000,
        "policy": "regular_hop",
        "centers": [200_000_000, 450_000_000, 700_000_000],
        "expected_energy": [500.0, 500.0, 1300.0],
        "expected_y": [25.0, 50.5, 50.0],
        "expected_omega": [2.0, 2.5, 21.0],
        "expected_valid": [True, False, False],
    },
    {
        "name": "one_fitting_window_numeric_mean",
        "t": [0, 100_000_000, 300_000_000, 400_000_000],
        "y": [1, 9, 3, 7], "omega": [-7, 3, 5, 11], "invalid": [],
        "feature_t": [100_000_000, 300_000_000],
        "mean_columns": {"amplitude": [4.0, 100.0], "variance": [16.0, 300.0]},
        "window": 0.4000000019, "hop": 0.1250000009, "rate": 3.0,
        "half_ns": 200_000_000, "hop_ns": 125_000_000,
        "policy": "regular_hop", "centers": [200_000_000],
        "expected_energy": [200.0], "expected_y": [5.0],
        "expected_omega": [4.0], "expected_valid": [True],
    },
    {
        "name": "short_even_median_fallback",
        "t": [0, 30_000_000, 60_000_000, 100_000_000],
        "y": [10, 100, 30, 50], "omega": [2, -8, 6, 20], "invalid": [1],
        "feature_t": [30_000_000, 60_000_000], "energy": [42, 84],
        "window": 0.5, "hop": 0.0700000009, "rate": 17.0,
        "half_ns": 250_000_000, "hop_ns": 70_000_000,
        "policy": "median_fallback", "centers": [45_000_000],
        "expected_energy": [84.0], "expected_y": [40.0],
        "expected_omega": [4.0], "expected_valid": [False],
    },
]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as handle:
        handle.write(json.dumps(value, indent=2, allow_nan=False) + "\n")


def inventory(root: Path) -> dict:
    return {str(p.relative_to(root)): {"bytes": p.stat().st_size, "sha256": sha(p)}
            for p in sorted(root.rglob("*")) if p.is_file() and ".git" not in p.parts}


def source_inventory(root: Path) -> dict:
    names = subprocess.check_output(
        ["git", "-C", str(root), "ls-files", "-z", "libs/python", "schemas", "tools"]
    ).decode().split("\0")
    return {name: sha(root / name) for name in names if name and (root / name).is_file()}


def capacity() -> int:
    available = shutil.disk_usage(HERE).free
    if available < 48 * 1024 * 1024:
        raise RuntimeError(f"receiving capacity floor reached: {available} bytes available")
    return available


def seed(case: dict, path: Path) -> None:
    path.mkdir()
    write_json(path / "manifest.json", {
        "session_schema_version": "1.0.0", "sessionId": "independent-" + case["name"],
        "state": "finalized", "t0WallUtc": "2026-10-08T00:00:00Z",
        "finalizedUtc": "2026-10-08T00:00:01Z", "sourceIds": [],
    })
    write_json(path / "integrity.json", {"schemaVersion": "1", "files": [], "durationNs": 1_000_000_000})
    kin = path / "processing/jobs/teacher/kinematics"
    feat = path / "processing/jobs/features/features/radar/independent.radar"
    kin.mkdir(parents=True)
    feat.mkdir(parents=True)
    count = len(case["t"])
    frame = {
        "session_time_ns": case["t"], TARGETS[0]: case["y"],
        TARGETS[1]: [value + 100 for value in case["y"]], TARGETS[2]: case["omega"],
        TARGETS[3]: [value * 2 for value in case["omega"]],
        "valid_elbow_L": [i not in case["invalid"] for i in range(count)],
        "valid_elbow_R": [True] * count,
    }
    pd.DataFrame(frame).to_parquet(kin / "kinematics.parquet", index=False)
    features = {"t_ns": case["feature_t"]}
    if "energy" in case:
        features["energy"] = case["energy"]
    else:
        features.update(case["mean_columns"])
    pd.DataFrame(features).to_parquet(feat / "features.parquet", index=False)
    for job, command in (("teacher", "kinematics"), ("features", "features")):
        write_json(path / f"processing/jobs/{job}/job_manifest.json", {
            "schemaId": "capture.analysis_job/1", "jobId": job,
            "status": "completed", "command": command,
        })


def main() -> None:
    capacity_before = capacity()
    initial = {}
    for phase, commit in PHASES.items():
        root = HERE / phase
        observed = subprocess.check_output(["git", "-C", str(root), "rev-parse", "HEAD"]).decode().strip()
        if observed != commit:
            raise RuntimeError(f"wrong source for {phase}: {observed}")
        initial[phase] = source_inventory(root)
    differences = sorted(name for name in initial["baseline"]
                         if initial["baseline"][name] != initial["candidate"].get(name))
    if differences != ["libs/python/capture_analysis/capture_analysis/ml_bundle/job.py"]:
        raise RuntimeError(f"unexpected runtime differences: {differences}")
    write_json(EVIDENCE / "source-before.json", {"commits": PHASES, "files": initial})
    write_json(EVIDENCE / "cases.json", CASES)
    seeds = EVIDENCE / "inputs"
    seeds.mkdir()
    for case in CASES:
        seed(case, seeds / case["name"])
    inputs = inventory(seeds)
    write_json(EVIDENCE / "input-manifest.json", inputs)
    cache = EVIDENCE / "matplotlib-cache"
    cache.mkdir()
    cached_font = Path("/Users/me/Developer/capturesuite-analysis-provenance-20261008/out/analysis-provenance-evidence/matplotlib-cache/fontlist-v3.11.0.json")
    shutil.copyfile(cached_font, cache / cached_font.name)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", MPLBACKEND="Agg", MPLCONFIGDIR=str(cache))
    env.pop("PYTHONPATH", None)
    records = []
    checks = []
    def check(phase: str, case: str, name: str, condition: bool, actual=None, expected=None):
        checks.append({"phase": phase, "case": case, "name": name, "pass": bool(condition),
                       "actual": actual, "expected": expected})
    for phase in PHASES:
        root = HERE / phase
        phase_root = EVIDENCE / phase
        phase_root.mkdir()
        for case in CASES:
            capacity()
            label = case["name"]
            package = phase_root / (label + ".mmsession")
            shutil.copytree(seeds / label, package)
            before_input = inventory(package)
            arguments = ["ml_bundle", str(package), "--kinematics-job", "teacher",
                         "--features-job", "features", "--window-sec", str(case["window"]),
                         "--hop-sec", str(case["hop"]), "--grid-rate-hz", str(case["rate"]),
                         "--overwrite-job-id", "bundle"]
            for command, args in (("bundle", arguments),
                                  ("eval", ["eval", str(package), "--ml-bundle-job", "bundle",
                                            "--overwrite-job-id", "evaluation"])):
                trace = phase_root / f"{label}-{command}-modules.json"
                cmd = [sys.executable, "-B", str(HERE / "cli_trace.py"), str(root), str(trace), *args]
                result = subprocess.run(cmd, cwd=HERE, env=env, capture_output=True, timeout=40)
                log = phase_root / f"{label}-{command}.log"
                log.write_bytes(result.stdout + result.stderr)
                records.append({"phase": phase, "case": label, "command": cmd,
                                "exit_code": result.returncode, "log_sha256": sha(log),
                                "modules_sha256": sha(trace) if trace.exists() else None})
                check(phase, label, command + " CLI exits 0", result.returncode == 0, result.returncode, 0)
                if result.returncode != 0:
                    write_json(EVIDENCE / "partial-receipt.json", {"records": records, "checks": checks})
                    raise RuntimeError(f"{phase}/{label}/{command} failed; original output retained")
            bundle = package / "processing/jobs/bundle"
            manifest = json.loads((bundle / "ml_bundle/manifest.json").read_text())
            windows_path = bundle / "ml_bundle/windows.parquet"
            windows = pd.read_parquet(windows_path)
            grid = manifest["analysisGrids"][0]
            params = grid["params"]
            schema = json.loads((root / "schemas/ml_bundle/ml_bundle.manifest.schema.json").read_text())
            jsonschema.validate(manifest, schema)
            check(phase, label, "existing bundle schema accepts final file", True)
            for column, expected in (
                ("session_time_ns", case["centers"]), ("motion_energy", case["expected_energy"]),
                (TARGETS[0], case["expected_y"]),
                (TARGETS[1], [x + 100 for x in case["expected_y"]]),
                (TARGETS[2], case["expected_omega"]),
                (TARGETS[3], [x * 2 for x in case["expected_omega"]]),
                ("valid_mask", case["expected_valid"]),
            ):
                actual = windows[column].tolist()
                check(phase, label, "numeric " + column, actual == expected, actual, expected)
            check(phase, label, "raw-value normalization", manifest["normalization"] == {"input": "none", "target": "none"}, manifest["normalization"], {"input": "none", "target": "none"})
            check(phase, label, "truthful alignment method", grid["method"] == "nearest_feature_window_median_targets", grid["method"], "nearest_feature_window_median_targets")
            expected_rate = 1e9 / case["hop_ns"]
            check(phase, label, "configured hop rate", math.isclose(grid["rateHz"], expected_rate, rel_tol=1e-14), grid["rateHz"], expected_rate)
            expected_params = {
                "hopNs": case["hop_ns"], "halfWindowNs": case["half_ns"],
                "windowBounds": "inclusive", "rateBasis": "configured_integer_hop",
                "centerPolicy": case["policy"], "requestedWindowSec": case["window"],
                "requestedHopSec": case["hop"], "requestedRateHz": case["rate"],
                "windowSec": 2 * case["half_ns"] / 1e9, "windowHopSec": case["hop_ns"] / 1e9,
            }
            check(phase, label, "complete requested and effective timing", all(params.get(k) == v for k, v in expected_params.items()), params, expected_params)
            expected_window = {"windowSec": 2 * case["half_ns"] / 1e9, "hopSec": case["hop_ns"] / 1e9, "targetTime": "center"}
            check(phase, label, "effective public window", manifest["window"] == expected_window, manifest["window"], expected_window)
            saved_params = json.loads((bundle / "params.json").read_text())["extra"]
            expected_requests = {"window_sec": case["window"], "hop_sec": case["hop"], "grid_rate_hz": case["rate"]}
            check(phase, label, "CLI preserves requested parameters", all(saved_params.get(k) == v for k, v in expected_requests.items()), saved_params, expected_requests)
            check(phase, label, "bundle window hash", manifest["sha256"]["windows.parquet"] == sha(windows_path))
            job_manifest = json.loads((bundle / "job_manifest.json").read_text())
            bad_outputs = []
            for item in job_manifest["outputs"]:
                path = bundle / item["relativePath"]
                if path.stat().st_size != item["bytes"] or sha(path) != item["sha256"]:
                    bad_outputs.append(item["relativePath"])
            check(phase, label, "final job inventory matches physical bytes", not bad_outputs, bad_outputs, [])
            eval_dir = package / "processing/jobs/evaluation/eval"
            eval_doc = json.loads((eval_dir / "eval_report.json").read_text())
            predictions = pd.read_parquet(eval_dir / "predictions.parquet")
            expected_eval = (eval_doc["windowCount"] == len(case["centers"])
                             and eval_doc["validWindowCount"] == sum(case["expected_valid"])
                             and list(eval_doc["metrics"]) == sorted(TARGETS))
            check(phase, label, "real identity evaluator consumes all targets and validity", expected_eval)
            check(phase, label, "evaluator preserves raw targets", all(predictions["y_teacher_" + target].tolist() == windows[target].tolist() for target in TARGETS))
            changed_inputs = [name for name, info in before_input.items() if sha(package / name) != info["sha256"]]
            check(phase, label, "producer and consumer preserve seeded inputs", not changed_inputs, changed_inputs, [])
            write_json(phase_root / f"{label}-observed.json", {
                "windows": windows.to_dict(orient="list"), "bundle": manifest,
                "job_status": job_manifest["status"], "warnings": job_manifest.get("warnings", []),
                "evaluation": eval_doc,
            })
            print(json.dumps({"phase": phase, "case": label, "windows": len(windows),
                              "checks": sum(x["phase"] == phase and x["case"] == label for x in checks),
                              "failed": [x["name"] for x in checks if x["phase"] == phase and x["case"] == label and not x["pass"]]}), flush=True)
    for case in CASES:
        for relative in ("bundle/ml_bundle/windows.parquet", "evaluation/eval/predictions.parquet"):
            paths = [EVIDENCE / phase / (case["name"] + ".mmsession") / "processing/jobs" / relative for phase in PHASES]
            check("paired", case["name"], "byte-identical " + relative, sha(paths[0]) == sha(paths[1]), [sha(p) for p in paths])
    final = {phase: source_inventory(HERE / phase) for phase in PHASES}
    check("paired", "all", "all frozen runtime and schema sources unchanged", initial == final)
    check("paired", "all", "all independently seeded input files unchanged", inputs == inventory(seeds))
    write_json(EVIDENCE / "source-after.json", final)
    receipt = {
        "schema": "capture.ml_bundle.independent_receiving/1",
        "recorded_at": datetime.datetime.now(datetime.UTC).isoformat(),
        "owner": "estate-03ac6e86ba72/mac_production", "source_commits": PHASES,
        "runtime": {"python": sys.version, "platform": platform.platform(), "numpy": numpy.__version__,
                    "pandas": pd.__version__, "pyarrow": pyarrow.__version__},
        "receiver_sha256": sha(Path(__file__)), "cli_trace_sha256": sha(HERE / "cli_trace.py"),
        "capacity_before": capacity_before, "capacity_after": shutil.disk_usage(HERE).free,
        "commands": records, "checks": checks,
        "counts": {phase: {"passed": sum(x["phase"] == phase and x["pass"] for x in checks),
                            "failed": sum(x["phase"] == phase and not x["pass"] for x in checks)}
                   for phase in [*PHASES, "paired"]},
    }
    write_json(EVIDENCE / "receipt.json", receipt)
    print(json.dumps({"counts": receipt["counts"], "receipt_sha256": sha(EVIDENCE / "receipt.json")}), flush=True)
    if any(not x["pass"] for x in checks if x["phase"] != "baseline"):
        raise RuntimeError("independent candidate or preservation expectation failed")


if __name__ == "__main__":
    main()
