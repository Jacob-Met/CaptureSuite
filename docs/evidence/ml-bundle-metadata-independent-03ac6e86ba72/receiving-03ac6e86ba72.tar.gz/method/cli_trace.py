# SPDX-License-Identifier: GPL-3.0-only
"""Execute the unchanged public CLI and record source modules actually imported."""
import hashlib
import json
import runpy
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
trace = Path(sys.argv[2])
sys.argv = [str(root / "tools/run_analysis.py"), *sys.argv[3:]]
try:
    runpy.run_path(sys.argv[0], run_name="__main__")
finally:
    modules = {}
    for name, module in sorted(sys.modules.items()):
        file = getattr(module, "__file__", None)
        if not file:
            continue
        path = Path(file).resolve()
        if path.is_relative_to(root) and path.is_file():
            modules[name] = {
                "path": str(path.relative_to(root)),
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            }
    trace.write_text(json.dumps(modules, indent=2) + "\n", encoding="utf-8")
