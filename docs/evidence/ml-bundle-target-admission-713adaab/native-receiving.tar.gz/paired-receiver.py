import pathlib,hashlib,json,subprocess,os,sys,time,xml.etree.ElementTree as ET
root=pathlib.Path('/srv/hamon-estate/chatgpt-capturesuite-target-admission-713adaab')
source=root/'source'
label=sys.argv[1]
out=root/'evidence'/label
out.mkdir(exist_ok=False)
test=source/'tests/analysis/test_ml_bundle_target_admission.py'
(out/'receiver.py').write_bytes(test.read_bytes())
producer=source/'libs/python/capture_analysis/capture_analysis/ml_bundle/job.py'
selected=[p for d in ('libs/python','schemas','tests/fixtures/mini_session') for p in (source/d).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
selected += [test,source/'tests/conftest.py',source/'pyproject.toml']
def hashes():return {p.relative_to(source).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in selected if p.exists()}
before=hashes()
env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';env['PYTHONPATH']=os.pathsep.join(str(p) for p in (source/'libs/python').iterdir() if p.is_dir())
py='/srv/hamon-estate/chatgpt-capturesuite-nearest-features-713adaab/environment/venv/bin/python'
cmd=[py,'-B','-m','pytest','tests/analysis/test_ml_bundle_target_admission.py','-vv','-ra','-p','no:cacheprovider','--basetemp='+str(out/'fixtures'),'--junitxml='+str(out/'junit.xml')]
start=time.monotonic()
with (out/'pytest.log').open('wb') as log:
 try:p=subprocess.run(cmd,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180);code=p.returncode;timeout=False
 except subprocess.TimeoutExpired:code=None;timeout=True
record={'command':cmd,'cwd':str(source),'python':py,'seconds':time.monotonic()-start,'exit_code':code,'timeout':timeout,'producer_sha256':hashlib.sha256(producer.read_bytes()).hexdigest(),'test_sha256':hashlib.sha256(test.read_bytes()).hexdigest(),'input_before':before,'input_after':hashes()}
record['source_unchanged']=record['input_before']==record['input_after']
if (out/'junit.xml').is_file():
 suite=ET.parse(out/'junit.xml').getroot()
 record['junit']=[dict(x.attrib) for x in suite.iter('testsuite')]
 record['cases']=[{'name':x.attrib.get('name'),'failure':len(x.findall('failure')),'error':len(x.findall('error')),'skipped':len(x.findall('skipped'))} for x in suite.iter('testcase')]
for name in ('junit.xml','pytest.log'):
 p=out/name
 if p.is_file():record[name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(out/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ('input_before','input_after','cases')}))
