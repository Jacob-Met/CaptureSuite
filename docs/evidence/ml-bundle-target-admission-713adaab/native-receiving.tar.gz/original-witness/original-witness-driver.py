import sys,json,pathlib,hashlib,importlib.util,copy
source=pathlib.Path('/srv/hamon-estate/chatgpt-capturesuite-nearest-features-713adaab/source')
for p in source.glob('libs/python/*'):sys.path.insert(0,str(p))
spec=importlib.util.spec_from_file_location('receiver',source/'tests/analysis/test_ml_bundle_feature_order.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
from capture_analysis.ml_bundle.job import run_ml_bundle_job,DEFAULT_TARGET_COLUMNS
import pandas as pd
from types import SimpleNamespace
root=pathlib.Path('/dev/shm/chatgpt-capturesuite-target-admission-713adaab')
root.mkdir(exist_ok=False)
package=root/'package'
inputs=[mod._seed_teacher(package),mod._seed_features(package,{'t_ns':[0,500000000,1000000000],'energy':[10.,20.,30.]})]
before={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
rows=[]
for label,targets in [('default',None),('timestamp',['session_time_ns']),('duplicate',[DEFAULT_TARGET_COLUMNS[0],DEFAULT_TARGET_COLUMNS[0]])]:
 work=root/label;outputs=[];warnings=[]
 try:
  result=run_ml_bundle_job(package,work,SimpleNamespace(session_id='target-admission-fixture'),kinematics_job_id='kin',features_job_id='feat',window_sec=.2,hop_sec=.2,target_columns=targets,outputs=outputs,warnings=warnings)
  df=pd.read_parquet(work/'ml_bundle/windows.parquet')
  rows.append({'case':label,'result':'success','targets':targets,'times':df.session_time_ns.tolist(),'time_dtype':str(df.session_time_ns.dtype),'columns':list(df.columns),'manifest_targets':json.loads((work/'ml_bundle/manifest.json').read_bytes())['targetColumns'],'warnings':warnings,'result_metadata':result})
 except Exception as e:rows.append({'case':label,'result':'exception','type':type(e).__name__,'error':str(e)})
after={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
record={'source_sha256':hashlib.sha256((source/'libs/python/capture_analysis/capture_analysis/ml_bundle/job.py').read_bytes()).hexdigest(),'rows':rows,'input_before':before,'input_after':after,'unchanged':before==after,'qualification':'existing native Python3.12.10; exact current producer and preserved sources; authored disposable fixtures only'}
(root/'original-witness.json').write_text(json.dumps(record,indent=2)+'\n')
(root/'original-witness-driver.py').write_text("")
print(json.dumps(record))