import pathlib,json,hashlib
root=pathlib.Path('/srv/hamon-estate/chatgpt-capturesuite-target-admission-713adaab');e=root/'evidence'
baseline=e/'baseline-final'/'fixtures';candidate=e/'candidate'/'fixtures'
inputs=[];controls=[]
for p in sorted(baseline.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(baseline)
 s=rel.as_posix()
 is_input=('/package/' in s or '/recording.mmsession/' in s) and '/processing/jobs/invalid-targets/' not in s
 if is_input:
  other=candidate/rel
  assert other.is_file(),str(rel)
  b=p.read_bytes();c=other.read_bytes();assert b==c,str(rel)
  inputs.append({'path':s,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'paired_equal':True})
 if s.endswith('/result/ml_bundle/windows.parquet') and (candidate/rel).is_file():
  b=p.read_bytes();c=(candidate/rel).read_bytes();assert b==c,str(rel)
  controls.append({'path':s,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'paired_equal':True})
assert len(controls)==3,len(controls)
source=root/'source/libs/python/capture_analysis/capture_analysis/ml_bundle/job.py'
guard="    if any(not isinstance(col, str) or not col for col in y_cols):\n        raise ValueError(\"target_columns must contain nonempty string names\")\n    if len(set(y_cols)) != len(y_cols):\n        raise ValueError(\"target_columns must contain distinct names\")\n    reserved_columns = {\n        \"window_id\", \"session_time_ns\", \"valid_mask\", \"motion_energy\", \"feature_stream_id\",\n    }\n    conflicts = [col for col in y_cols if col in reserved_columns]\n    if conflicts:\n        raise ValueError(\n            \"target_columns conflict with required bundle columns: \" + \", \".join(conflicts)\n        )\n"
raw=source.read_bytes();text=raw.decode();assert text.count(guard)==1
restored=text.replace(guard,'',1).encode()
assert hashlib.sha256(restored).hexdigest()=='ed67d94ded834d63599797bbd8efb7b26f125bd216f52bcb7f01febb928922ce'
receivers=[(e/x/'receiver.py').read_bytes() for x in ('baseline-final','candidate')]
assert receivers[0]==receivers[1]
record={'inputs':inputs,'valid_windows':controls,'input_pair_count':len(inputs),'valid_windows_byte_identical_count':len(controls),'source_sha256':hashlib.sha256(raw).hexdigest(),'restored_original_sha256':hashlib.sha256(restored).hexdigest(),'all_other_producer_bytes_identical':True,'paired_receiver_sha256':hashlib.sha256(receivers[0]).hexdigest(),'receipts':{x:hashlib.sha256((e/x/'receipt.json').read_bytes()).hexdigest() for x in ('baseline','baseline-final','candidate')}}
(e/'paired-artifacts.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ('inputs','valid_windows')}))
