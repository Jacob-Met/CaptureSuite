#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Receive the exact current finalizer without changing earlier qualified trees."""
from pathlib import Path
import hashlib,importlib.util,json,os,platform,shutil,subprocess,sys,time
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parent
packet=json.loads((root/'current-finalizer-payload.json').read_text())
previous=json.loads((root/'candidate-qualification.json').read_text())
original=root/'candidate'
target=root/'current-finalizer'
assert not target.exists()
def sha(data):return hashlib.sha256(data).hexdigest()
def blob(data):return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def inventory(where):
 return {p.relative_to(where).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'git_blob':blob(p.read_bytes())}
         for p in sorted(where.rglob('*')) if p.is_file()}
for rel,info in previous['source_after']['candidate'].items():
 data=(original/rel).read_bytes()
 assert len(data)==info['bytes'] and sha(data)==info['sha256'],rel
for item in packet['current_sources']:assert blob(item['content'].encode())==item['git_blob'],item['path']
assert shutil.disk_usage(root).free>64*1024*1024
target.mkdir()
parent={item['path']:item for item in packet['current_tree']}
overrides={item['path']:item['content'].encode() for item in packet['current_sources']}
for name in ['baseline','candidate']:
 where=target/name;where.mkdir()
 for rel in previous['source_after']['candidate']:
  dest=where/rel;dest.parent.mkdir(parents=True,exist_ok=True)
  dest.write_bytes(overrides.get(rel,(original/rel).read_bytes()))
 for rel,data in overrides.items():
  dest=where/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 if name=='candidate':
  (where/'libs/python/capture_analysis/capture_analysis/jobs.py').write_bytes(packet['candidate_jobs'].encode())
 for rel,item in inventory(where).items():
  if rel in ['docs/design/research/ANALYSIS_SCOPE_SEMANTICS.md','tests/analysis/test_sync_anchor_request.py']:continue
  if name=='candidate' and rel=='libs/python/capture_analysis/capture_analysis/jobs.py':continue
  assert rel in parent and item['git_blob']==parent[rel]['sha'],rel
 assert blob((where/'tests/analysis/test_sync_anchor_request.py').read_bytes())==packet['unchanged_accepted_new_test']
before={name:inventory(target/name) for name in ['baseline','candidate']}
(target/'system-temp').mkdir()
env=os.environ.copy()
env.update({'PYTHONDONTWRITEBYTECODE':'1','PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1','TMPDIR':str(target/'system-temp'),
            'MPLBACKEND':'Agg','MPLCONFIGDIR':str(target/'matplotlib-config')})
commands=[]
def execute(name,args,cwd):
 began=time.monotonic()
 out,err=target/(name+'.stdout'),target/(name+'.stderr')
 with out.open('wb') as stdout,err.open('wb') as stderr:
  proc=subprocess.run(args,cwd=cwd,env=env,stdout=stdout,stderr=stderr,timeout=180,check=False)
 record={'name':name,'args':args,'cwd':str(cwd),'exit':proc.returncode,'seconds':time.monotonic()-began,
         'stdout_sha256':sha(out.read_bytes()),'stderr_sha256':sha(err.read_bytes())}
 commands.append(record);print(json.dumps(record),flush=True)
 return proc.returncode
new_test='tests/analysis/test_sync_anchor_request.py'
runtime='/Users/me/.pyenv/versions/3.13.7/bin/python3'
base=[runtime,'-B','-m','pytest','-q','-rA','-p','no:cacheprovider']
original_code=execute('current-baseline',base+['--basetemp',str(target/'baseline-temp'),'--junitxml',str(target/'baseline.xml'),new_test],target/'baseline')
cases=[new_test,'tests/analysis/test_phase_a_qc.py','tests/analysis/test_job_destinations.py',
       'tests/analysis/test_job_replacement.py','tests/analysis/test_job_failure_cli.py',
       'tests/analysis/test_job_output_provenance.py']
candidate_code=execute('current-candidate',base+['--basetemp',str(target/'candidate-temp'),'--junitxml',str(target/'candidate.xml')]+cases,target/'candidate')
style_code=execute('current-ruff',['/Users/me/Developer/capturesuite-framing-integration-72ac1419-venv/bin/python','-B','-m','ruff','check','--no-cache',
 '--config',str(target/'candidate/pyproject.toml'),str(target/'candidate/libs/python/capture_analysis/capture_analysis/jobs.py'),str(target/'candidate'/new_test)],target/'candidate')
def junit(path):
 cases=[]
 for node in ET.parse(path).getroot().iter('testcase'):
  status='passed';detail=''
  for kind in ['failure','error','skipped']:
   child=node.find(kind)
   if child is not None:status=kind;detail=child.get('message','');break
  cases.append({'name':node.get('name'),'class':node.get('classname'),'status':status,'detail':detail})
 return {'counts':{key:sum(c['status']==key for c in cases) for key in ['passed','failure','error','skipped']},'cases':cases}
a,b=junit(target/'baseline.xml'),junit(target/'candidate.xml')
after={name:inventory(target/name) for name in before}
qualified=original_code==1 and candidate_code==style_code==0 and a['counts']=={'passed':6,'failure':11,'error':0,'skipped':0} and b['counts']=={'passed':66,'failure':0,'error':0,'skipped':1} and before==after
receipt={'classification':'advisory native Python3.13 current-finalizer composition','source_parent':packet['parent'],'source_tree':packet['tree'],'python':sys.version,'platform':platform.platform(),
 'driver_sha256':sha(Path(__file__).read_bytes()),'source_before':before,'source_after':after,'source_unchanged':before==after,'commands':commands,'baseline':a,'candidate':b,
 'qualified':qualified,'not_executed_native':{'tests/analysis/test_numeric_cli_receiving.py':'Existing Python3.13 runtime lacks mcap; no installation or stand-in. All7 real numeric CLI cases remain in the required hosted supported-runtime gate.'},
 'limits':'The package requires Python >=3.12,<3.13. These actual QC/admission/inventory/replacement process controls are advisory native source receiving; supported Python3.12/Windows CI remains required. No alignment, MCAP decoding, desktop or hardware adoption is claimed.'}
out=target/'qualification.json';out.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps({'qualified':qualified,'counts':b['counts'],'source_unchanged':before==after,'source_files':len(before['candidate']),'receipt_sha256':sha(out.read_bytes())}),flush=True)
raise SystemExit(0 if qualified else 1)
