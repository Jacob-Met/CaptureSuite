#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
from pathlib import Path
import base64,gzip,hashlib,io,json,tarfile
root=Path(__file__).resolve().parent
target=root/'current-finalizer'
receipt=json.loads((target/'qualification.json').read_text())
assert receipt['qualified'] and receipt['source_unchanged']
members={}
for p in sorted(target.rglob('*')):
 assert not p.is_symlink(),str(p)
 if p.is_file():members['current-finalizer/'+str(p.relative_to(target))]=p.read_bytes()
members['qualify_current_finalizer.py']=(root/'qualify_current_finalizer.py').read_bytes()
members['current-finalizer-payload.json']=(root/'current-finalizer-payload.json').read_bytes()
records=[{'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(members.items())]
manifest={'source_parent':receipt['source_parent'],'source_tree':receipt['source_tree'],'members':records,'scope':'Original and composed finalizer sources, actual paired native QC/admission/inventory/replacement artifacts, JUnit/logs, explicit unsupported-runtime and missing-MCAP limits.'}
members['MANIFEST.json']=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
plain=io.BytesIO()
with tarfile.open(fileobj=plain,mode='w',format=tarfile.PAX_FORMAT) as tf:
 for name,data in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
  tf.addfile(info,io.BytesIO(data))
compressed=gzip.compress(plain.getvalue(),mtime=0)
out=root/'current-finalizer-evidence.tar.gz'
assert not out.exists()
out.write_bytes(compressed)
(root/'current-finalizer-evidence.base64.txt').write_text(base64.b64encode(compressed).decode()+'\n')
with tarfile.open(fileobj=io.BytesIO(compressed),mode='r:gz') as tf:
 extracted={item.name:tf.extractfile(item).read() for item in tf.getmembers()}
 assert extracted==members
def blob(data):return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
jobs=(target/'candidate/libs/python/capture_analysis/capture_analysis/jobs.py').read_bytes()
summary={'source_parent':receipt['source_parent'],'archive_bytes':len(compressed),'archive_sha256':hashlib.sha256(compressed).hexdigest(),'archive_git_blob':blob(compressed),'regular_members':len(members),'manifest_entries':len(records),'manifest_sha256':hashlib.sha256(members['MANIFEST.json']).hexdigest(),'jobs_bytes':len(jobs),'jobs_sha256':hashlib.sha256(jobs).hexdigest(),'jobs_git_blob':blob(jobs),'qualification_sha256':hashlib.sha256((target/'qualification.json').read_bytes()).hexdigest(),'source_files_per_variant':len(receipt['source_before']['candidate']),'baseline_counts':receipt['baseline']['counts'],'candidate_counts':receipt['candidate']['counts'],'scope':manifest['scope']}
(root/'current-finalizer-package.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary))
