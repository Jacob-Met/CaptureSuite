#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
from pathlib import Path
import base64,gzip,hashlib,io,json,os,tarfile
root=Path(__file__).resolve().parent
target=root/'current-finalizer'
receipt=json.loads((target/'qualification.json').read_text())
assert receipt['qualified'] and receipt['source_unchanged']
members={}; links=[]; directories=[]
for walk_root,dirnames,filenames in os.walk(target,followlinks=False):
 parent=Path(walk_root)
 directories.append('current-finalizer/'+str(parent.relative_to(target)))
 for name in list(dirnames):
  p=parent/name
  if p.is_symlink():
   links.append({'path':'current-finalizer/'+str(p.relative_to(target)),'target':os.readlink(p)})
   dirnames.remove(name)
 for name in filenames:
  p=parent/name
  key='current-finalizer/'+str(p.relative_to(target))
  if p.is_symlink():links.append({'path':key,'target':os.readlink(p)})
  else:
   assert p.is_file(),str(p)
   members[key]=p.read_bytes()
for name in ['qualify_current_finalizer.py','current-finalizer-payload.json','package_current_finalizer.py','package_current_finalizer_v2.py']:
 members[name]=(root/name).read_bytes()
def jdata(obj):return (json.dumps(obj,indent=2,sort_keys=True)+'\n').encode()
members['LINKS.json']=jdata({'policy':'Targets are recorded as inert metadata only. No target was dereferenced and no archive member is a symlink.','links':sorted(links,key=lambda x:x['path'])})
members['DIRECTORIES.json']=jdata({'policy':'Directory names including empty test outputs are retained as inert metadata; archive payloads are regular files only.','directories':sorted(directories)})
members['PACKAGING_HISTORY.json']=jdata({'first_recipe':'package_current_finalizer.py','first_result':'Stopped before archive creation when its no-symlink assertion encountered baseline-temp/capture-app-statecurrent.','correction':'Second recipe retains links as metadata and never dereferences them. Source, test outputs, logs and qualification are unchanged.'})
records=[{'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(members.items())]
manifest={'source_parent':receipt['source_parent'],'source_tree':receipt['source_tree'],'members':records,'scope':'Original and composed finalizer sources, actual paired native QC/admission/inventory/replacement artifacts, JUnit/logs, explicit unsupported-runtime and missing-MCAP limits.'}
members['MANIFEST.json']=jdata(manifest)
plain=io.BytesIO()
with tarfile.open(fileobj=plain,mode='w',format=tarfile.PAX_FORMAT) as tf:
 for name,data in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
  tf.addfile(info,io.BytesIO(data))
compressed=gzip.compress(plain.getvalue(),mtime=0)
out=root/'current-finalizer-evidence.tar.gz'
assert not out.exists()
out.write_bytes(compressed)
(root/'current-finalizer-evidence.base64.txt').write_text(base64.b64encode(compressed).decode()+'\n')
with tarfile.open(fileobj=io.BytesIO(compressed),mode='r:gz') as tf:
 assert all(item.isfile() for item in tf.getmembers())
 extracted={item.name:tf.extractfile(item).read() for item in tf.getmembers()}
 assert extracted==members
def blob(data):return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
jobs=(target/'candidate/libs/python/capture_analysis/capture_analysis/jobs.py').read_bytes()
summary={'source_parent':receipt['source_parent'],'source_tree':receipt['source_tree'],'archive_bytes':len(compressed),'archive_sha256':hashlib.sha256(compressed).hexdigest(),'archive_git_blob':blob(compressed),'regular_members':len(members),'manifest_entries':len(records),'manifest_sha256':hashlib.sha256(members['MANIFEST.json']).hexdigest(),'symlink_metadata_entries':len(links),'directory_metadata_entries':len(directories),'jobs_bytes':len(jobs),'jobs_sha256':hashlib.sha256(jobs).hexdigest(),'jobs_git_blob':blob(jobs),'qualification_sha256':hashlib.sha256((target/'qualification.json').read_bytes()).hexdigest(),'source_files_per_variant':len(receipt['source_before']['candidate']),'baseline_counts':receipt['baseline']['counts'],'candidate_counts':receipt['candidate']['counts'],'scope':manifest['scope']}
(root/'current-finalizer-package.json').write_bytes(jdata(summary))
print(json.dumps(summary))
