#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Bounded real-job receiving for the additive external-prediction composition."""
from pathlib import Path
import hashlib, importlib.util, json, os, platform, shutil, subprocess, sys, time
import xml.etree.ElementTree as ET
ROOT = Path(__file__).resolve().parent
def sha(data): return hashlib.sha256(data).hexdigest()
def blob(data): return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
def inventory(root):
    return {p.relative_to(root).as_posix(): {"bytes": len(p.read_bytes()), "sha256": sha(p.read_bytes()), "git_blob": blob(p.read_bytes())}
            for p in sorted(root.rglob("*")) if p.is_file() and not p.is_symlink()}
def eval_receive(source, output):
    sys.path[:0] = [str(source / "libs/python" / p) for p in ("capture_analysis", "capture_session", "capture_protocol")]
    import pandas as pd
    from capture_analysis.jobs import JobParams, run
    from capture_session.package_reader import load_review_summary
    output.mkdir()
    package = output / "synthetic.mmsession"
    shutil.copytree(source / "tests/fixtures/mini_session", package)
    folder = package / "processing/jobs/authored-bundle/ml_bundle"
    folder.mkdir(parents=True)
    angle, velocity = "theta_elbow_flex_L", "omega_elbow_flex_L"
    windows, manifest = folder / "windows.parquet", folder / "manifest.json"
    frame = pd.DataFrame({"window_id": ["w0", "w1", "w2"], "session_time_ns": [1000000000, 1100000000, 1200000000],
                          "valid_mask": [True, True, True], angle: [0.0, 3.0, 6.0], velocity: [2.0, 4.0, 6.0]})
    frame.to_parquet(windows, index=False)
    manifest.write_text(json.dumps({"schemaId": "capture.ml_bundle/1", "sessionIds": [load_review_summary(package).session_id],
                                   "targetColumns": [angle, velocity], "sha256": {"windows.parquet": sha(windows.read_bytes())}}, indent=2) + "\n")
    predictions = output / "authored-predictions.json"
    predictions.write_text(json.dumps({"schemaId": "capture.eval_predictions/1", "modelId": "synthetic-composition-offset",
         "windowsSha256": sha(windows.read_bytes()), "manifestSha256": sha(manifest.read_bytes()),
         "predictions": [{"window_id": "w" + str(i), "session_time_ns": 1000000000 + i * 100000000,
                          "values": {angle: float(i * 3 + 2), velocity: float(i * 2 + 2)}}
                         for i in reversed(range(3))]}, indent=2) + "\n")
    input_paths = [windows, manifest, predictions]
    input_before = {str(p): sha(p.read_bytes()) for p in input_paths}
    raw_before = {p: v for p, v in inventory(package).items() if not p.startswith("processing/")}
    results = []
    for label, extra in [("identity", {"ml_bundle_job_id": "authored-bundle"}),
                          ("external", {"ml_bundle_job_id": "authored-bundle", "prediction_path": str(predictions)})]:
        result = run(package, JobParams(command="eval", overwrite_job_id=label, extra=extra))
        report = json.loads((result.job_dir / "eval/eval_report.json").read_text())
        saved = json.loads((result.job_dir / "job_manifest.json").read_text())
        assert saved["syncAnchorsApplied"] == {"applied": False, "anchors": []}
        assert not any(item["relativePath"] == "job_manifest.json" for item in saved["outputs"])
        for item in saved["outputs"]:
            data = (result.job_dir / item["relativePath"]).read_bytes()
            assert len(data) == item["bytes"] and sha(data) == item["sha256"], item["relativePath"]
        if label == "identity":
            assert report["baseline"] == "identity_teacher_sim" and report["metrics"][angle]["mae"] == 0.0
        else:
            assert report["evaluationMode"] == "external_predictions" and report["baseline"] is None
            assert report["metrics"][angle]["n"] == 3 and report["metrics"][angle]["mae"] == 2.0
            assert report["metrics"][angle]["rmse"] == 2.0 and report["metrics"][velocity]["mae"] == 0.0
            assert (result.job_dir / "eval/prediction_input.json").read_bytes() == predictions.read_bytes()
        results.append({"group": label, "passed": True, "report_sha256": sha((result.job_dir / "eval/eval_report.json").read_bytes()),
                        "manifest_sha256": sha((result.job_dir / "job_manifest.json").read_bytes()), "outputs_verified": len(saved["outputs"])})
    before = inventory(package)
    progress = []
    try:
        run(package, JobParams(command="eval", apply_sync_anchors=True, overwrite_job_id="external",
                               extra={"ml_bundle_job_id": "authored-bundle", "prediction_path": str(output / "does-not-exist.json")}),
            progress=lambda *args: progress.append(args))
        raise AssertionError("unsupported alignment unexpectedly ran")
    except NotImplementedError as exc:
        assert "sync-anchor alignment is not implemented" in str(exc)
    assert inventory(package) == before and progress == []
    assert input_before == {str(p): sha(p.read_bytes()) for p in input_paths}
    assert raw_before == {p: v for p, v in inventory(package).items() if not p.startswith("processing/")}
    results.append({"group": "refusal-before-external-input-and-replacement", "passed": True, "progress": progress})
    receipt = {"classification": "Synthetic authored Parquet bundle through the actual eval job API; no MCAP decoding or model-training claim.",
               "groups": results, "passed": 3, "failed": 0, "inputs_unchanged": True, "raw_package_unchanged": True,
               "source": str(source), "python": sys.version}
    (output / "receipt.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    print(json.dumps(receipt))
    return
if len(sys.argv) > 1 and sys.argv[1] == "--eval":
    eval_receive(Path(sys.argv[2]), Path(sys.argv[3]))
    raise SystemExit(0)
packet = json.loads((ROOT / "current-predictions-payload.json").read_text())
previous = json.loads((ROOT / "current-finalizer/qualification.json").read_text())
original = ROOT / "current-finalizer/candidate"
target = ROOT / "current-predictions"
assert not target.exists()
assert shutil.disk_usage(ROOT).free > 64 * 1024 * 1024
target.mkdir()
candidate = target / "candidate"
candidate.mkdir()
for rel, info in previous["source_after"]["candidate"].items():
    data = (original / rel).read_bytes()
    assert sha(data) == info["sha256"] and blob(data) == info["git_blob"], rel
    dest = candidate / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
for item in packet["current_sources"]:
    data = item["content"].encode()
    assert blob(data) == item["git_blob"], item["path"]
    dest = candidate / item["path"]
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
runner = candidate / "libs/python/capture_analysis/capture_analysis/jobs.py"
current_base = runner.read_bytes()
runner.write_bytes(packet["candidate_jobs"].encode())
assert runner.read_text().replace(packet["guard"], "").replace('"applied": False,', '"applied": params.apply_sync_anchors,').encode() == current_base
parent = {x["path"]: x for x in packet["current_tree"]}
before = inventory(candidate)
for rel, info in before.items():
    if rel in ["libs/python/capture_analysis/capture_analysis/jobs.py", "docs/design/research/ANALYSIS_SCOPE_SEMANTICS.md",
               "tests/analysis/test_sync_anchor_request.py"]:
        continue
    assert parent[rel]["sha"] == info["git_blob"], rel
(target / "system-temp").mkdir()
env = os.environ.copy()
env.update({"PYTHONDONTWRITEBYTECODE": "1", "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1", "TMPDIR": str(target / "system-temp"),
            "MPLBACKEND": "Agg", "MPLCONFIGDIR": str(target / "matplotlib-config")})
runtime = "/Users/me/.pyenv/versions/3.13.7/bin/python3"
commands = []
def execute(name, args):
    started = time.monotonic()
    out, err = target / (name + ".stdout"), target / (name + ".stderr")
    with out.open("wb") as stdout, err.open("wb") as stderr:
        proc = subprocess.run(args, cwd=candidate, env=env, stdout=stdout, stderr=stderr, timeout=180, check=False)
    result = {"name": name, "args": args, "exit": proc.returncode, "seconds": time.monotonic() - started,
              "stdout_sha256": sha(out.read_bytes()), "stderr_sha256": sha(err.read_bytes())}
    commands.append(result)
    print(json.dumps(result), flush=True)
    return proc.returncode
admission = execute("admission", [runtime, "-B", "-m", "pytest", "-q", "-rA", "-p", "no:cacheprovider",
        "--basetemp", str(target / "test-temp"), "--junitxml", str(target / "admission.xml"), "tests/analysis/test_sync_anchor_request.py"])
evaluation = execute("evaluation", [runtime, "-B", str(Path(__file__)), "--eval", str(candidate), str(target / "eval-receiving")])
style = execute("ruff", ["/Users/me/Developer/capturesuite-framing-integration-72ac1419-venv/bin/python", "-B", "-m", "ruff", "check",
        "--no-cache", "--config", str(candidate / "pyproject.toml"), str(runner), str(candidate / "tests/analysis/test_sync_anchor_request.py")])
cases = [{"name": n.get("name"), "passed": not any(n.find(k) is not None for k in ["failure", "error", "skipped"])}
         for n in ET.parse(target / "admission.xml").getroot().iter("testcase")]
after = inventory(candidate)
receipt = {"classification": "Advisory native Python3.13 current-prediction composition", "parent": packet["parent"],
           "parent_tree": packet["parent_tree"], "prior_accepted_head": packet["prior_head"], "python": sys.version, "platform": platform.platform(),
           "driver_sha256": sha(Path(__file__).read_bytes()), "source_before": before, "source_after": after, "source_unchanged": before == after,
           "two_hunk_reversal_returns_current_parent": True, "commands": commands, "admission": cases,
           "eval_receipt": json.loads((target / "eval-receiving/receipt.json").read_text()) if (target / "eval-receiving/receipt.json").exists() else None,
           "qualified": admission == evaluation == style == 0 and len(cases) == 17 and all(x["passed"] for x in cases) and before == after,
           "limits": "Python3.13 is outside declared >=3.12,<3.13. Original66/1 finalizer receiving is retained. Supported Python3.12/Windows full CI is required on this composition. The authored sealed-bundle receiver exercises actual eval API forwarding; it does not decode MCAP or execute the external owner's full sensor pipeline. No installation or shared source/runtime change."}
path = target / "qualification.json"
path.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
print(json.dumps({"qualified": receipt["qualified"], "tests": len(cases), "eval_groups": 3 if evaluation == 0 else 0,
                  "source_files": len(before), "source_unchanged": before == after, "receipt_sha256": sha(path.read_bytes())}), flush=True)
raise SystemExit(0 if receipt["qualified"] else 1)
