#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Seal the bounded current-prediction receiving without changing prior records."""
from pathlib import Path
import base64, gzip, hashlib, io, json, tarfile
ROOT = Path(__file__).resolve().parent
def sha(data): return hashlib.sha256(data).hexdigest()
def blob(data): return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
packet = json.loads((ROOT / "current-predictions-payload.json").read_text())
receipt = json.loads((ROOT / "current-predictions/qualification.json").read_text())
assert receipt["qualified"] and receipt["source_unchanged"] and len(receipt["source_after"]) == 115
assert len(receipt["admission"]) == 17 and all(x["passed"] for x in receipt["admission"])
assert receipt["eval_receipt"]["passed"] == 3 and receipt["eval_receipt"]["failed"] == 0
for rel, item in receipt["source_after"].items():
    data = (ROOT / "current-predictions/candidate" / rel).read_bytes()
    assert sha(data) == item["sha256"] and blob(data) == item["git_blob"], rel
selected = [ROOT / p for p in ["current-predictions-payload.json", "qualify_current_predictions.py",
                               "current-predictions.stdout", "current-predictions.stderr", "package_current_predictions.py"]]
selected += list((ROOT / "current-predictions").rglob("*"))
links = [{"path": p.relative_to(ROOT).as_posix(), "target": str(p.readlink())} for p in selected if p.is_symlink()]
data = {p.relative_to(ROOT).as_posix(): p.read_bytes() for p in selected if p.is_file() and not p.is_symlink()}
data["symlinks-inert.json"] = (json.dumps({"classification": "Metadata only; links are not archived or dereferenced.", "links": links}, indent=2) + "\n").encode()
manifest = {"schema": "capturesuite.receiving-files.v1", "source_parent": packet["parent"],
            "files": [{"path": name, "bytes": len(b), "sha256": sha(b), "git_blob": blob(b)} for name, b in sorted(data.items())]}
manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
data["MANIFEST.json"] = manifest_bytes
archive = ROOT / "current-predictions-evidence.tar.gz"
assert not archive.exists()
with archive.open("wb") as file:
    with gzip.GzipFile(filename="", mode="wb", fileobj=file, mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode="w") as tar:
            for name, payload in sorted(data.items()):
                item = tarfile.TarInfo(name); item.size = len(payload); item.mode = 0o644; item.mtime = 0
                tar.addfile(item, io.BytesIO(payload))
raw = archive.read_bytes()
with tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz") as tar:
    assert all(item.isfile() for item in tar.getmembers())
    assert {item.name: tar.extractfile(item).read() for item in tar.getmembers()} == data
package = {"source_parent": packet["parent"], "source_parent_tree": packet["parent_tree"],
           "previous_accepted_head": packet["prior_head"], "archive": archive.name, "bytes": len(raw), "sha256": sha(raw), "git_blob": blob(raw),
           "regular_members": len(data), "manifest_entries": len(manifest["files"]), "manifest_sha256": sha(manifest_bytes),
           "source_files": len(receipt["source_after"]), "source_unchanged": True,
           "qualification_sha256": sha((ROOT / "current-predictions/qualification.json").read_bytes()),
           "driver_sha256": sha((ROOT / "qualify_current_predictions.py").read_bytes()),
           "tests": 17, "eval_groups": 3, "ruff_passed": True, "inert_links": len(links),
           "boundary": receipt["limits"]}
(ROOT / "current-predictions-package.json").write_text(json.dumps(package, indent=2, sort_keys=True) + "\n")
(ROOT / "current-predictions-evidence.base64.txt").write_bytes(base64.encodebytes(raw))
print(json.dumps(package), flush=True)
