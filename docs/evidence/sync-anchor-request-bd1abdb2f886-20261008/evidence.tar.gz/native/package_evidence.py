#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Pack exact owned source, original failures and receiving artifacts deterministically."""
import base64
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
def sha(data):
    return hashlib.sha256(data).hexdigest()
def blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
qualification = json.loads((ROOT/"candidate-qualification.json").read_text())
if not qualification["qualified_advisory_comparison"]:
    raise ValueError("Advisory comparison did not pass")
for name, files in qualification["source_after"].items():
    actual = {}
    for p in sorted((ROOT/name).rglob("*")):
        if p.is_file():
            data = p.read_bytes()
            actual[p.relative_to(ROOT/name).as_posix()] = {"bytes":len(data),"sha256":sha(data)}
    if actual != files:
        raise ValueError("Qualified source changed: " + name)
members = {}
def add(path, name):
    if path.is_symlink() or not path.is_file():
        raise ValueError("Not a regular owned artifact: " + str(path))
    if name in members:
        raise ValueError("Duplicate artifact: " + name)
    members[name] = path.read_bytes()
root_files = [
    "source-bundle.json","candidate-payload.json","prepared-source.json",
    "baseline-qc-receipt.json","candidate-qualification.json",
    "observe_qc_baseline.py","prepare_candidate.py","qualify_candidate.py",
    "preparation-notes.json","baseline-qc.stdout","baseline-qc.stderr",
    "candidate-ruff.stdout","candidate-ruff.stderr",
    "baseline-tests.stdout","baseline-tests.stderr","baseline-tests.xml",
    "candidate-tests.stdout","candidate-tests.stderr","candidate-tests.xml",
    "qualification.stdout","qualification.stderr","package_evidence.py",
]
for name in root_files:
    add(ROOT/name, "native/"+name)
for rel in [
    "libs/python/capture_analysis/capture_analysis/jobs.py",
    "tests/analysis/test_sync_anchor_request.py",
    "docs/design/research/ANALYSIS_SCOPE_SEMANTICS.md",
]:
    add(ROOT/"candidate"/rel, "candidate/"+rel)
for p in sorted((ROOT/"baseline-qc").rglob("*")):
    if p.is_file() and not p.is_symlink():
        add(p, "original-qc/"+p.relative_to(ROOT/"baseline-qc").as_posix())
prefixes = ("test_native_timestamp_qc_", "test_requested_alignment_", "test_rejected_alignment_",
            "test_unsupported_request_", "test_existing_unknown_")
for kind in ("baseline-test-temp","candidate-test-temp"):
    for directory in sorted((ROOT/kind).iterdir()):
        if directory.is_symlink() or not directory.is_dir() or not directory.name.startswith(prefixes):
            continue
        for p in sorted(directory.rglob("*")):
            if p.is_file() and not p.is_symlink():
                add(p, "job-controls/"+kind+"/"+p.relative_to(ROOT/kind).as_posix())
manifest = {"schema":"hamon.receiving-archive/1","source_parent":qualification["source_parent"],
            "classification":"advisory_native_python313_source_comparison",
            "members":[{"path":p,"bytes":len(data),"sha256":sha(data),"git_blob":blob(data)}
                       for p,data in sorted(members.items())]}
manifest_bytes = (json.dumps(manifest,indent=2,sort_keys=True)+"\n").encode()
members["MANIFEST.json"] = manifest_bytes
def pack():
    out = io.BytesIO()
    with tarfile.open(fileobj=out,mode="w",format=tarfile.PAX_FORMAT) as tar:
        for name,data in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.size=len(data)
            info.mode=0o644
            info.uid=info.gid=info.mtime=0
            info.uname=info.gname=""
            tar.addfile(info,io.BytesIO(data))
    return gzip.compress(out.getvalue(),mtime=0)
data = pack()
if data != pack():
    raise ValueError("Archive is not deterministic")
archive = ROOT/"evidence.tar.gz"
if archive.exists():
    raise FileExistsError("Archive already exists")
archive.write_bytes(data)
encoded = base64.b64encode(data).decode()
(ROOT/"evidence.base64.txt").write_text("\n".join(encoded[i:i+76] for i in range(0,len(encoded),76))+"\n")
(ROOT/"evidence-manifest.json").write_bytes(manifest_bytes)
result = {"archive_bytes":len(data),"archive_sha256":sha(data),"archive_git_blob":blob(data),
          "regular_members":len(members),"manifest_entries":len(manifest["members"]),
          "manifest_sha256":sha(manifest_bytes),"deterministic_repack":True,
          "source_unchanged":True,"packer_sha256":sha(Path(__file__).read_bytes())}
(ROOT/"evidence-package.json").write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
print(json.dumps(result))
