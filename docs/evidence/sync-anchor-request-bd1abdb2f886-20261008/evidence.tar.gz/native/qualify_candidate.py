#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Qualify the paired real-job sources; preserve both original failures and final outputs."""
from __future__ import annotations
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

CAPTURE_ROOT = Path(__file__).resolve().parent
RUNTIME = "/Users/me/.pyenv/versions/3.13.7/bin/python3"
RUFF_RUNTIME = "/Users/me/Developer/capturesuite-framing-integration-72ac1419-venv/bin/python"
def sha(data):
    return hashlib.sha256(data).hexdigest()
def inventory(root):
    return {p.relative_to(root).as_posix(): {"bytes":p.stat().st_size,"sha256":sha(p.read_bytes())}
            for p in sorted(root.rglob("*")) if p.is_file()}
def junit(path):
    cases = []
    for element in ET.parse(path).getroot().iter("testcase"):
        state = "passed"
        detail = ""
        for kind in ("error", "failure", "skipped"):
            child = element.find(kind)
            if child is not None:
                state, detail = kind, child.attrib.get("message", "")
                break
        cases.append({"name":element.attrib["name"],"class":element.attrib.get("classname",""),
                      "status":state,"detail":detail})
    return {"counts":{s:sum(c["status"] == s for c in cases) for s in ("passed","failure","error","skipped")},
            "total":len(cases),"cases":cases}

prepared = json.loads((CAPTURE_ROOT / "prepared-source.json").read_text())
before = {name:inventory(CAPTURE_ROOT / name) for name in ("baseline", "baseline-suite", "candidate")}
if before["baseline-suite"] != prepared["baseline_source"] or before["candidate"] != prepared["candidate_source"]:
    raise ValueError("Prepared source changed before qualification")
if shutil.disk_usage(CAPTURE_ROOT).free < 24 * 1024 * 1024:
    raise OSError("Insufficient space for bounded native qualification")
for name in ("baseline-test-temp", "candidate-test-temp", "test-system-temp"):
    if (CAPTURE_ROOT / name).exists():
        raise FileExistsError("Qualification destination exists: " + name)
(CAPTURE_ROOT / "test-system-temp").mkdir()
env = os.environ.copy()
env.update({"PYTHONDONTWRITEBYTECODE":"1","PYTEST_DISABLE_PLUGIN_AUTOLOAD":"1",
            "TMPDIR":str(CAPTURE_ROOT / "test-system-temp"),"MPLBACKEND":"Agg",
            "MPLCONFIGDIR":str(CAPTURE_ROOT / "matplotlib-config")})
records = []
def execute(name, command, cwd, timeout=240):
    stdout_path, stderr_path = CAPTURE_ROOT / (name+".stdout"), CAPTURE_ROOT / (name+".stderr")
    if stdout_path.exists() or stderr_path.exists():
        raise FileExistsError("Command evidence already exists: " + name)
    began = time.monotonic()
    with stdout_path.open("wb") as out, stderr_path.open("wb") as err:
        try:
            proc = subprocess.run(command, cwd=cwd, env=env, stdout=out, stderr=err, timeout=timeout, check=False)
            rc, timed_out = proc.returncode, False
        except subprocess.TimeoutExpired:
            rc, timed_out = None, True
    record = {"name":name,"command":command,"cwd":str(cwd),"exit_code":rc,"timed_out":timed_out,
              "seconds":time.monotonic()-began,"stdout_sha256":sha(stdout_path.read_bytes()),
              "stderr_sha256":sha(stderr_path.read_bytes())}
    records.append(record)
    print(json.dumps(record), flush=True)
    return record

candidate = CAPTURE_ROOT / "candidate"
style = execute("candidate-ruff", [RUFF_RUNTIME,"-B","-m","ruff","check","--no-cache",
    "--config",str(candidate/"pyproject.toml"),
    str(candidate/"libs/python/capture_analysis/capture_analysis/jobs.py"),
    str(candidate/"tests/analysis/test_sync_anchor_request.py")], candidate)
if style["exit_code"] != 0:
    raise RuntimeError("Candidate style gate failed; original style evidence retained")
new_test = "tests/analysis/test_sync_anchor_request.py"
base_command = [RUNTIME,"-B","-m","pytest","-q","-rA","-p","no:cacheprovider"]
original = execute("baseline-tests", base_command + [
    "--basetemp",str(CAPTURE_ROOT/"baseline-test-temp"),
    "--junitxml",str(CAPTURE_ROOT/"baseline-tests.xml"),new_test], CAPTURE_ROOT/"baseline-suite")
final = execute("candidate-tests", base_command + [
    "--basetemp",str(CAPTURE_ROOT/"candidate-test-temp"),
    "--junitxml",str(CAPTURE_ROOT/"candidate-tests.xml"),new_test,
    "tests/analysis/test_phase_a_qc.py","tests/analysis/test_job_destinations.py",
    "tests/analysis/test_job_replacement.py","tests/analysis/test_job_failure_cli.py"], candidate)
original_junit, final_junit = junit(CAPTURE_ROOT/"baseline-tests.xml"), junit(CAPTURE_ROOT/"candidate-tests.xml")
new_final = [c for c in final_junit["cases"] if c["class"].endswith("test_sync_anchor_request")]
after = {name:inventory(CAPTURE_ROOT/name) for name in before}
qualified = (
    original["exit_code"] == 1 and original_junit["total"] == 17
    and original_junit["counts"] == {"passed":6,"failure":11,"error":0,"skipped":0}
    and final["exit_code"] == 0
    and final_junit["counts"]["failure"] == final_junit["counts"]["error"] == 0
    and len(new_final) == 17 and all(c["status"] == "passed" for c in new_final)
    and before == after
)
versions = {}
for name in ("numpy","pandas","scipy","matplotlib","pyarrow","PyYAML","jsonschema","pytest"):
    try:
        versions[name] = importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        versions[name] = None
receipt = {"classification":"advisory_native_python313_source_comparison",
           "source_parent":prepared["source_head"],"source_tree":prepared["source_tree"],
           "python":sys.version,"platform":platform.platform(),"dependencies":versions,
           "driver_sha256":sha(Path(__file__).read_bytes()),"commands":records,
           "source_before":before,"source_after":after,"source_unchanged":before == after,
           "baseline":original_junit,"candidate":final_junit,"new_candidate_cases":len(new_final),
           "qualified_advisory_comparison":qualified,
           "limits":"The package declares Python >=3.12,<3.13. This source comparison executes actual jobs under existing Python 3.13.7 dependencies and does not claim supported-package acceptance. Exact-source hosted Python 3.12/Windows gates remain required. No feature alignment, MCAP decoding, UI, hardware or installed-runtime adoption is claimed."}
path = CAPTURE_ROOT/"candidate-qualification.json"
path.write_text(json.dumps(receipt,indent=2,sort_keys=True)+"\n")
print(json.dumps({"qualified_advisory_comparison":qualified,
                  "baseline":original_junit["counts"],"candidate":final_junit["counts"],
                  "new_candidate_cases":len(new_final),"source_unchanged":before == after,
                  "receipt_sha256":sha(path.read_bytes())}),flush=True)
raise SystemExit(0 if qualified else 1)
