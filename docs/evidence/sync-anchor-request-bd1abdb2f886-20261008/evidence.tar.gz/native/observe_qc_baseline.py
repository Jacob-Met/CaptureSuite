#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Observe actual QC provenance on a copied synthetic package; no source patch."""
from __future__ import annotations
import base64
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import sys
import traceback

ROOT = Path(__file__).resolve().parent
BUNDLE = ROOT / "source-bundle.json"
SOURCE = ROOT / "baseline"
OUT = ROOT / "baseline-qc"
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
os.environ["MPLBACKEND"] = "Agg"
os.environ["MPLCONFIGDIR"] = str(ROOT / "matplotlib-config")
sys.dont_write_bytecode = True

def digest(data):
    return hashlib.sha256(data).hexdigest()

def git_blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()

def inventory(root, exclude_processing=False):
    result = {}
    for p in sorted(root.rglob("*")):
        if p.is_file():
            rel = p.relative_to(root).as_posix()
            if exclude_processing and (rel == "processing" or rel.startswith("processing/")):
                continue
            data = p.read_bytes()
            result[rel] = {"bytes": len(data), "sha256": digest(data)}
    return result

bundle = json.loads(BUNDLE.read_text(encoding="utf-8"))
if SOURCE.exists() or OUT.exists():
    raise FileExistsError("The owned baseline source/output already exists")
if shutil.disk_usage(ROOT).free < 16 * 1024 * 1024:
    raise OSError("Insufficient free space for the bounded baseline")
validated = []
for row in bundle["files"]:
    rel = Path(row["path"])
    if rel.is_absolute() or ".." in rel.parts:
        raise ValueError("Unsafe source path")
    data = base64.b64decode(row["content"]) if row["encoding"] == "base64" else row["content"].encode("utf-8")
    if len(data) != row["size"] or git_blob(data) != row["sha"]:
        raise ValueError("Exact source byte mismatch: " + row["path"])
    validated.append((row, data))
SOURCE.mkdir()
for row, data in validated:
    p = SOURCE / row["path"]
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data)
source_before = inventory(SOURCE)
OUT.mkdir()
sys.path[:0] = [
    str(SOURCE / "libs/python/capture_analysis"),
    str(SOURCE / "libs/python/capture_session"),
    str(SOURCE / "libs/python/capture_protocol"),
]
from capture_analysis.jobs import JobParams, run
from capture_session.package_reader import load_review_summary

anchor = {
    "syncAnchorId": "synthetic-tap-250ms",
    "timestampNs": "250000000",
    "modalitiesTargeted": ["emg", "imu"],
    "mechanism": "manual",
    "metadata": {"classification": "synthetic_fixture"},
    "createdVia": "isolated-qc-receiver",
}
fixture = SOURCE / "tests/fixtures/mini_session"
cases = []
for requested in (False, True):
    case_dir = OUT / ("requested" if requested else "default")
    case_dir.mkdir()
    package = case_dir / "synthetic.mmsession"
    shutil.copytree(fixture, package)
    anchor_path = package / "events/sync_anchors.json"
    anchor_path.write_text(json.dumps([anchor], indent=2) + "\n", encoding="utf-8")
    before = inventory(package, exclude_processing=True)
    loaded = load_review_summary(package)
    row = {
        "apply_sync_anchors_requested": requested,
        "loaded_anchors": loaded.sync_anchors,
        "input_before": before,
    }
    try:
        result = run(package, JobParams(command="qc", apply_sync_anchors=requested, overwrite_job_id="anchor-provenance"))
        saved_manifest = json.loads((result.job_dir / "job_manifest.json").read_text(encoding="utf-8"))
        row.update({
            "status": result.status,
            "job_dir": str(result.job_dir),
            "returned_sync": result.manifest["syncAnchorsApplied"],
            "saved_sync": saved_manifest["syncAnchorsApplied"],
            "saved_params": json.loads((result.job_dir / "params.json").read_text(encoding="utf-8")),
            "qc_sync_anchor_count": result.qc["syncAnchorCount"],
            "outputs": inventory(result.job_dir),
            "manifest": saved_manifest,
        })
    except Exception as exc:
        row.update({"exception_type": type(exc).__name__, "exception": str(exc), "traceback": traceback.format_exc()})
    row["input_after"] = inventory(package, exclude_processing=True)
    row["inputs_unchanged"] = row["input_before"] == row["input_after"]
    cases.append(row)
source_after = inventory(SOURCE)
observed = (
    all(c.get("status") in ("completed", "completed_with_warnings") for c in cases)
    and all(c["loaded_anchors"] == [anchor] and c.get("qc_sync_anchor_count") == 1 for c in cases)
    and cases[0].get("saved_sync") == {"applied": False, "anchors": []}
    and cases[1].get("saved_sync") == {"applied": True, "anchors": []}
    and all(c["inputs_unchanged"] for c in cases)
    and source_before == source_after
)
receipt = {
    "classification": "synthetic_saved_session_actual_qc_api",
    "repository": bundle["repository"],
    "source_head": bundle["source_head"],
    "source_tree": bundle["source_tree"],
    "python": sys.version,
    "platform": platform.platform(),
    "driver_sha256": digest(Path(__file__).read_bytes()),
    "bundle_sha256": digest(BUNDLE.read_bytes()),
    "source_before": source_before,
    "source_after": source_after,
    "source_unchanged": source_before == source_after,
    "cases": cases,
    "reproduced_requested_flag_becomes_unsubstantiated_applied_flag": observed,
    "limits": "QC API and persisted manifest only. No MCAP decoding, feature timestamp comparison, inferred offset, hardware or participant data. The anchor has a nonzero native timestamp, not an asserted measured offset.",
}
receipt_path = ROOT / "baseline-qc-receipt.json"
receipt_path.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps({
    "source_head": bundle["source_head"],
    "source_files": len(source_before),
    "source_unchanged": receipt["source_unchanged"],
    "reproduced": observed,
    "cases": [{k: c.get(k) for k in ("apply_sync_anchors_requested", "status", "saved_sync", "qc_sync_anchor_count", "inputs_unchanged", "exception_type", "exception")} for c in cases],
    "receipt": str(receipt_path),
    "receipt_sha256": digest(receipt_path.read_bytes()),
}, indent=2))
raise SystemExit(0 if observed else 1)
