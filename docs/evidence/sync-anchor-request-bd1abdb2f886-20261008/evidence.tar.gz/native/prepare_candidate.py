#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Materialize only the owned candidate and paired source comparator."""
import base64
import hashlib
import json
from pathlib import Path
import shutil

root = Path(__file__).resolve().parent
baseline = root / "baseline"
payload = json.loads((root / "candidate-payload.json").read_text())
receipt = json.loads((root / "baseline-qc-receipt.json").read_text())
def sha(data):
    return hashlib.sha256(data).hexdigest()
def blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
def inventory(path):
    return {p.relative_to(path).as_posix(): {"bytes":p.stat().st_size,"sha256":sha(p.read_bytes())}
            for p in sorted(path.rglob("*")) if p.is_file()}
if inventory(baseline) != receipt["source_after"]:
    raise ValueError("Original source changed")
if any((root / name).exists() for name in ("baseline-suite", "candidate")):
    raise FileExistsError("Prepared tree already exists")
if shutil.disk_usage(root).free < 20 * 1024 * 1024:
    raise OSError("Insufficient space for bounded source qualification")
validated = []
for row in payload["validation_files"]:
    rel = Path(row["path"])
    if rel.is_absolute() or ".." in rel.parts:
        raise ValueError("Unsafe source path")
    data = base64.b64decode(row["content"]) if row["encoding"] == "base64" else row["content"].encode()
    if len(data) != row["size"] or blob(data) != row["sha"]:
        raise ValueError("Validation source mismatch: " + row["path"])
    validated.append((row["path"], data))
test = next(x for x in payload["candidate_files"] if x["path"].startswith("tests/"))
for name in ("baseline-suite", "candidate"):
    dest = root / name
    shutil.copytree(baseline, dest)
    for rel, data in validated:
        p = dest / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)
    p = dest / test["path"]
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(test["content"].encode())
for row in payload["candidate_files"]:
    p = root / "candidate" / row["path"]
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(row["content"].encode())
base = inventory(root / "baseline-suite")
candidate = inventory(root / "candidate")
changed = sorted(p for p in base.keys() | candidate.keys() if base.get(p) != candidate.get(p))
expected = ["docs/design/research/ANALYSIS_SCOPE_SEMANTICS.md", "libs/python/capture_analysis/capture_analysis/jobs.py"]
if changed != expected:
    raise ValueError("Unexpected paired source differences: " + repr(changed))
result = {"source_head": payload["source_head"], "source_tree": payload["source_tree"],
          "baseline_source": base, "candidate_source": candidate,
          "paired_changed_paths": changed, "original_source_unchanged": inventory(baseline) == receipt["source_after"],
          "preparer_sha256": sha(Path(__file__).read_bytes())}
p = root / "prepared-source.json"
p.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
print(json.dumps({"baseline_files":len(base),"candidate_files":len(candidate),"changed":changed,
                  "receipt_sha256":sha(p.read_bytes()),"original_source_unchanged":result["original_source_unchanged"]}))
