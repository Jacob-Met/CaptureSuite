# SPDX-License-Identifier: GPL-3.0-only
"""Compare retained original and candidate data without replaying either job."""
from pathlib import Path
import hashlib
import json
import pandas as pd

root = Path(__file__).resolve().parent
baseline = root / "baseline-final"
candidate = root / "candidate"
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
before = json.loads((baseline / "receipt.json").read_text())
after = json.loads((candidate / "receipt.json").read_text())
assert before["test_sha256"] == after["test_sha256"] == "7a5e226afb9c0f49eadf6d4c25b8bc22575f1fdd04afdac854cf8aa4adee58be"
assert before["source_unchanged"] and after["source_unchanged"]
assert before["counts"] == {"tests":17,"passed":6,"failed":11,"errors":0,"skipped":0}
assert after["counts"] == {"tests":17,"passed":17,"failed":0,"errors":0,"skipped":0}
left = baseline / "pytest-temp"
right = candidate / "pytest-temp"
rows = []
inputs = []
for file in sorted(left.rglob("*")):
    if not file.is_file():
        continue
    relative = file.relative_to(left)
    other = right / relative
    assert other.is_file(), relative
    if str(relative).endswith("ml_bundle/windows.parquet"):
        a, b = pd.read_parquet(file), pd.read_parquet(other)
        pd.testing.assert_frame_equal(a.drop(columns=["motion_energy"]), b.drop(columns=["motion_energy"]), check_exact=True)
        rows.append({
            "path":str(relative),"baseline_sha256":sha(file),"candidate_sha256":sha(other),
            "bytes_equal":file.read_bytes()==other.read_bytes(),
            "centers":a["session_time_ns"].tolist(),
            "baseline_energy":a["motion_energy"].tolist(),
            "candidate_energy":b["motion_energy"].tolist(),
            "all_other_columns_equal":True,
        })
    elif ("/processing/jobs/kin/" in str(relative)
          or "/processing/jobs/feat/" in str(relative)
          or file.name == "embedded-session-order.mcap"
          or "/sources/" in str(relative)):
        assert file.read_bytes() == other.read_bytes(), relative
        inputs.append({"path":str(relative),"bytes":file.stat().st_size,"sha256":sha(file)})
assert len(rows)==17,len(rows)
assert sum(row["bytes_equal"] for row in rows)==6,rows
source_before=json.loads((baseline/"source-before.json").read_text())
source_after=json.loads((candidate/"source-before.json").read_text())
changed=[name for name in source_before.keys()|source_after.keys()
         if source_before.get(name)!=source_after.get(name)]
code_changed=[name for name in changed if not name.startswith(".ruff_cache/")]
assert code_changed==["libs/python/capture_analysis/capture_analysis/ml_bundle/job.py"],code_changed
receipt={
    "schema":"capturesuite.ml_feature_order_paired_artifacts/1",
    "baseline_receipt_sha256":sha(baseline/"receipt.json"),
    "candidate_receipt_sha256":sha(candidate/"receipt.json"),
    "test_sha256":before["test_sha256"],
    "same_source_except":code_changed,
    "ignored_lint_cache_changes":[x for x in changed if x.startswith(".ruff_cache/")],
    "window_count":len(rows),"byte_identical_ordered_controls":6,
    "corrected_unordered_outputs":11,"all_other_columns_equal":True,
    "identical_original_inputs":inputs,"windows":rows,
    "limits":"Readback of actual retained files only; no runtime replay. Original schema-invalid 2ns receiver run remains separate.",
}
out=root/"paired-artifacts.json"
out.write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps({"path":str(out),"sha256":sha(out),"windows":len(rows),"byte_identical_controls":6,
"changed_unordered":11,"input_files_identical":len(inputs),"all_other_columns_equal":True}))
