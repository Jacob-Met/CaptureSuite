# SPDX-License-Identifier: GPL-3.0-only
"""Receive one frozen source tree and retain process, source and Parquet custody."""

from __future__ import annotations

import hashlib
import importlib.metadata
import json
import os
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from datetime import UTC, datetime
from pathlib import Path


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory(root: Path) -> dict[str, dict]:
    rows = {}
    for path in sorted(root.rglob("*")):
        if not path.is_file() or ".git" in path.relative_to(root).parts:
            continue
        rows[path.relative_to(root).as_posix()] = {
            "bytes": path.stat().st_size, "sha256": sha(path),
        }
    return rows


source, evidence = (Path(value).resolve() for value in sys.argv[1:3])
assert source.is_dir()
assert not evidence.exists(), evidence
evidence.mkdir(parents=True)
before = inventory(source)
(evidence / "source-before.json").write_text(json.dumps(before, indent=2) + "\n")
env = os.environ.copy()
env.update({
    "PYTHONDONTWRITEBYTECODE": "1", "PYTHONNOUSERSITE": "1",
    "PYTHONPATH": "", "MPLBACKEND": "Agg", "MPLCONFIGDIR": str(evidence / "mplconfig"),
})
command = [
    sys.executable, "-B", "-m", "pytest",
    "tests/analysis/test_ml_bundle_feature_order.py",
    "-q", "-p", "no:cacheprovider", "--basetemp=" + str(evidence / "pytest-temp"),
    "--junitxml=" + str(evidence / "pytest.xml"),
]
started = datetime.now(tz=UTC).isoformat()
clock = time.monotonic()
with (evidence / "pytest.log").open("wb") as output:
    process = subprocess.run(
        command, cwd=source, env=env, stdin=subprocess.DEVNULL,
        stdout=output, stderr=subprocess.STDOUT, timeout=180,
    )
# Save the process result before optional XML or artifact inspection.
process_record = {
    "started_at": started, "seconds": time.monotonic() - clock,
    "returncode": process.returncode, "command": command, "cwd": str(source),
}
(evidence / "process.json").write_text(json.dumps(process_record, indent=2) + "\n")
after = inventory(source)
(evidence / "source-after.json").write_text(json.dumps(after, indent=2) + "\n")
doc = ET.parse(evidence / "pytest.xml")
cases = list(doc.iter("testcase"))
failed = [case for case in cases if case.find("failure") is not None]
errored = [case for case in cases if case.find("error") is not None]
skipped = [case for case in cases if case.find("skipped") is not None]
counts = {
    "tests": len(cases), "passed": len(cases) - len(failed) - len(errored) - len(skipped),
    "failed": len(failed), "errors": len(errored), "skipped": len(skipped),
}
receipt = {
    "schema": "capturesuite.ml_feature_order_receiving/1",
    "process": process_record, "python": sys.version, "executable": sys.executable,
    "libraries": {
        package: importlib.metadata.version(package)
        for package in ("numpy", "pandas", "pyarrow", "mcap", "protobuf", "pytest")
    },
    "producer_sha256": sha(
        source / "libs/python/capture_analysis/capture_analysis/ml_bundle/job.py"
    ),
    "test_sha256": sha(source / "tests/analysis/test_ml_bundle_feature_order.py"),
    "runner_sha256": sha(Path(__file__)),
    "source_count": len(before), "source_unchanged": before == after,
    "counts": counts,
    "failures": [
        {"classname": case.get("classname"), "name": case.get("name"),
         "message": case.find("failure").get("message")}
        for case in failed
    ],
    "errors": [
        {"classname": case.get("classname"), "name": case.get("name"),
         "message": case.find("error").get("message")}
        for case in errored
    ],
    "junit_sha256": sha(evidence / "pytest.xml"),
    "log_sha256": sha(evidence / "pytest.log"),
    "source_before_sha256": sha(evidence / "source-before.json"),
    "source_after_sha256": sha(evidence / "source-after.json"),
    "retained_artifacts": inventory(evidence / "pytest-temp"),
    "limits": "Actual isolated Linux Python3.12 receiving; no Windows or hardware execution.",
}
(evidence / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({
    "receipt": str(evidence / "receipt.json"),
    "receipt_sha256": sha(evidence / "receipt.json"),
    "process_exit": process.returncode, "counts": counts,
    "source_unchanged": before == after,
    "producer_sha256": receipt["producer_sha256"], "test_sha256": receipt["test_sha256"],
    "junit_sha256": receipt["junit_sha256"], "log_sha256": receipt["log_sha256"],
    "retained_file_count": len(receipt["retained_artifacts"]),
}), flush=True)
if before != after:
    raise SystemExit("Source bytes changed during receiving")
raise SystemExit(process.returncode)
