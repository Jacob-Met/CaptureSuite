"""Bounded static 70f -> 581 extension; no CaptureSuite execution."""
from pathlib import Path
import ast, hashlib, json, subprocess
ROOT = Path(__file__).resolve().parent
OUT = ROOT / "extension581"
OUT.mkdir(exist_ok=True)
def require(value, message):
    if not value: raise RuntimeError(message)
def git_hash(kind, data):
    return hashlib.sha1(kind.encode()+b" "+str(len(data)).encode()+b"\0"+data).hexdigest()
def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes((json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False)+"\n").encode())
def leaf_map(tree):
    return {r["path"]:{k:r[k] for k in ("mode","type","sha")} for r in tree["tree"] if r["type"]!="tree"}
def tree_digest(leaves):
    directories={"":{}}
    for path,row in leaves.items():
        parts=path.split("/")
        parent=""
        for part in parts[:-1]:
            child=(parent+"/"+part).lstrip("/")
            directories.setdefault(parent,{})[part]={"mode":"040000","type":"tree","path":child}
            directories.setdefault(child,{})
            parent=child
        directories[parent][parts[-1]]=dict(row)
    hashes={}
    for parent in sorted(directories,key=lambda x:x.count("/")+bool(x),reverse=True):
        entries=directories[parent]
        ordered=sorted(entries,key=lambda name:name.encode()+(b"/" if entries[name]["type"]=="tree" else b""))
        payload=b""
        for name in ordered:
            row=entries[name]
            digest=hashes[row["path"]] if row["type"]=="tree" else row["sha"]
            payload+=row["mode"].lstrip("0").encode()+b" "+name.encode()+b"\0"+bytes.fromhex(digest)
        hashes[parent]=git_hash("tree",payload)
    return hashes[""],hashes
old_api=json.loads((ROOT/"intake/github-api.json").read_bytes())
current=json.loads((ROOT/"intake/current581-extension.json").read_bytes())
tree=current["tree"]
require(tree["truncated"] is False,"Current tree truncated")
require(tree["sha"]==current["commit"]["tree"]["sha"]=="51c711928a28dc02e100fcdea44cd34512318113","Current identity mismatch")
main70=leaf_map(old_api["trees"]["main"])
main581=leaf_map(tree)
feature=leaf_map(old_api["trees"]["feature"])
old=leaf_map(old_api["trees"]["old"])
digest,directories=tree_digest(main581)
require(digest==tree["sha"],"Current root tree reconstruction failed")
for row in tree["tree"]:
    if row["type"]=="tree": require(directories[row["path"]]==row["sha"],"Current subtree reconstruction failed")
require(len(main581)==922,"Current leaf count differs")
changed=sorted(p for p in set(main70)|set(main581) if main70.get(p)!=main581.get(p))
require(changed==sorted(f["filename"] for f in current["compare"]["files"]),"Compare delta incomplete")
require(len(changed)==8,"Unexpected parent changed paths")
source={}
source_manifest=[]
for label,rows,expected in (("current",current["sources"],main581),("tested-parent",current["oldSources"],main70)):
    for row in rows:
        data=row["content"].encode("utf-8")
        blob=git_hash("blob",data)
        require(blob==row["sha"]==expected[row["path"]]["sha"],"Source byte mismatch "+row["path"])
        target=OUT/"sources"/label/row["path"]
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(data)
        source[(label,row["path"])]=data
        source_manifest.append({"label":label,"path":row["path"],"git_blob":blob,"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest()})
jobs_path="libs/python/capture_analysis/capture_analysis/jobs.py"
before_jobs=(ROOT/"sources/main"/jobs_path).read_bytes()
new_jobs=source[("current",jobs_path)]
argument=b'                prediction_path=params.extra.get("prediction_path"),\n'
require(new_jobs.count(argument)==1 and new_jobs.replace(argument,b"",1)==before_jobs,"jobs.py change is not one argument")
eval_path="libs/python/capture_analysis/capture_analysis/eval/job.py"
before_eval=source[("tested-parent",eval_path)]
new_eval=source[("current",eval_path)]
legacy_start=b"    import numpy as np\n"
require(before_eval.count(legacy_start)==1 and new_eval.count(legacy_start)==1,"Legacy seam ambiguous")
require(before_eval.split(legacy_start,1)[1]==new_eval.split(legacy_start,1)[1],"Legacy evaluation tail changed")
old_fn=next(n for n in ast.parse(before_eval).body if isinstance(n,ast.FunctionDef) and n.name=="run_eval_job")
new_fn=next(n for n in ast.parse(new_eval).body if isinstance(n,ast.FunctionDef) and n.name=="run_eval_job")
require(ast.dump(ast.Module(body=old_fn.body[1:],type_ignores=[]))==ast.dump(ast.Module(body=new_fn.body[2:],type_ignores=[])),"Default evaluation body AST changed")
guard=new_fn.body[1]
require(isinstance(guard,ast.If),"Missing optional input guard")
require(ast.dump(guard.test)==ast.dump(ast.parse("prediction_path is not None",mode="eval").body),"External import not None-guarded")
require(any(isinstance(n,ast.ImportFrom) and n.module=="capture_analysis.eval.predictions" for n in guard.body),"External import escaped expected guard")
cli_path="tools/run_analysis.py"
before_cli=source[("tested-parent",cli_path)]
new_cli=source[("current",cli_path)]
arg_block=b'    p_eval.add_argument(\n        "--predictions", type=Path,\n        help="capture.eval_predictions/1 JSON bound to this ML bundle (default: identity sim)",\n    )\n'
extra_block=b'        if args.predictions is not None:\n            extra["prediction_path"] = str(args.predictions.resolve())\n'
require(new_cli.count(arg_block)==1 and new_cli.count(extra_block)==1,"CLI additions ambiguous")
require(new_cli.replace(arg_block,b"",1).replace(extra_block,b"",1)==before_cli,"CLI has additional changes")
doc_results=[]
composed_blobs={}
for path in ["docs/design/ANALYSIS.md","docs/design/research/PROGRESS.md"]:
    ours=ROOT/"sources/feature"/path
    base=ROOT/"sources/old"/path
    theirs=OUT/"sources/current"/path
    command=["git","merge-file","-p",str(ours),str(base),str(theirs)]
    proc=subprocess.run(command,capture_output=True)
    require(proc.returncode==0,"Shared document merge has conflicts: "+path+" "+proc.stderr.decode(errors="replace"))
    merged=proc.stdout
    insertion=(ROOT/"proof"/(Path(path).name+".feature-insertion.bin")).read_bytes()
    require(merged.count(insertion)==1,"Feature doc insertion changed or duplicated")
    require(merged.replace(insertion,b"",1)==theirs.read_bytes(),"Removing exact feature addition does not reproduce581")
    target=OUT/"expected-docs"/path
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(merged)
    blob=git_hash("blob",merged)
    composed_blobs[path]=blob
    doc_results.append({"path":path,"method":"git merge-file -p feature old current581","exit":0,
        "feature_git_blob":git_hash("blob",ours.read_bytes()),"old_git_blob":git_hash("blob",base.read_bytes()),
        "current581_git_blob":git_hash("blob",theirs.read_bytes()),"expected_composed_git_blob":blob,
        "expected_composed_bytes":len(merged),"expected_composed_sha256":hashlib.sha256(merged).hexdigest(),
        "subtract_exact_feature_insertion_reproduces581":True,
        "nature":"local static composition; no new GitHub synthetic checkout was available in the observed PR response"})
scope=sorted(p for p in set(old)|set(feature) if old.get(p)!=feature.get(p))
expected=dict(main581)
for path in scope:
    require(path in feature,"Unexpected feature deletion")
    expected[path]=dict(feature[path])
    if path in composed_blobs:expected[path]["sha"]=composed_blobs[path]
expected_tree,_=tree_digest(expected)
unrelated=sorted(set(main581)-set(scope))
require(len(unrelated)==916 and all(expected[p]==main581[p] for p in unrelated),"Unrelated current files not preserved")
require(len(expected)==1007,"Expected final leaf count differs")
require(sum(expected[p]==feature[p] for p in scope)==89,"Feature retention differs")
write_json(OUT/"expected-composition.json",{
    "kind":"computed expected merge tree, not observed hosted checkout",
    "base_commit":current["commit"]["sha"],"base_tree":tree["sha"],
    "feature_commit":old_api["ids"]["feature"],"expected_tree":expected_tree,
    "feature_exact_leaves":89,"composed_feature_docs":2,"unrelated581_exact_leaves":916,
    "expected_total_leaves":len(expected),"leaves":[{"path":p,**r} for p,r in sorted(expected.items())]})
write_json(OUT/"source-manifest.json",source_manifest)
assessment={
    "decision":"Accept bounded source closure on581; preserve70f hosted execution identity",
    "baseline_tested_main":old_api["ids"]["main"],"current_main":current["commit"]["sha"],"current_tree":tree["sha"],
    "current_leaf_count":len(main581),"changed_paths":changed,
    "jobs_only_one_eval_argument_added":True,"default_eval_tail_byte_exact":True,"default_eval_body_ast_exact":True,
    "external_import_guard":"prediction_path is not None inside run_eval_job",
    "cli_only_eval_argument_and_optional_extra_added":True,
    "all_features_plots_dispatch_and_window_resolution_unchanged":True,
    "source_manifest":"source-manifest.json","documentation":doc_results,
    "expected_composed_tree":expected_tree,"expected_composed_leaves":len(expected),
    "ci":{"actual_checkout":"427766ed4beee603ea2e3eadcaceee9f7f76a538",
          "actual_first_parent":old_api["ids"]["main"],"current581_execution_claimed":False,
          "no_rerun":True},
    "observed_pr":{"head":current["pr"]["head"]["sha"],"base":current["pr"]["base"]["sha"],
                   "merge_commit":current["pr"]["merge_commit_sha"],"mergeable":current["pr"]["mergeable"]},
    "limits":["No external-prediction numerical/scientific requalification or native suite run.",
              "Expected581 composition is calculated locally; root must bind the eventual actual merge tree.",
              "No production source, PR head, or live app changed."]}
write_json(OUT/"assessment.json",assessment)
print(json.dumps({k:assessment[k] for k in ("decision","current_main","current_tree","expected_composed_tree","expected_composed_leaves","documentation")}))
