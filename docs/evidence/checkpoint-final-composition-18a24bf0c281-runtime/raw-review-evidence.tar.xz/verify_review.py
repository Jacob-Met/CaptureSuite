"""Static PR68 composition proof and custody of complete decoded hosted CI logs."""
from pathlib import Path
import difflib, hashlib, json, platform
ROOT = Path(__file__).resolve().parent
def dump(path, value):
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode("utf-8"))
def sha256(data):
    return hashlib.sha256(data).hexdigest()
def git_hash(kind, data):
    return hashlib.sha1(kind.encode() + b" " + str(len(data)).encode() + b"\0" + data).hexdigest()
def require(condition, message):
    if not condition:
        raise RuntimeError(message)
api = json.loads((ROOT / "intake/github-api.json").read_bytes())
intake = json.loads((ROOT / "intake/sources.json").read_bytes())
ids = api["ids"]
expected_trees = {
    "old": "fea0e03773742d330963b89e0ceb72a22c7ad495",
    "main": "1537621f793d5d5c9b331f3c4d37a79a4af824b7",
    "feature": "020ce927f40be01cb3dd4d27b03f864182e26cb5",
    "synthetic": "53a055761cd91359819445f392efc71da8e9099a",
}
leaves, tree_receipts = {}, {}
for label, response in api["trees"].items():
    require(response["truncated"] is False, label + " tree was truncated")
    require(response["sha"] == expected_trees[label], label + " root tree differs")
    entries = response["tree"]
    require(len(entries) == len({e["path"] for e in entries}), label + " duplicate tree path")
    directories = {"": response["sha"]}
    directories.update({e["path"]: e["sha"] for e in entries if e["type"] == "tree"})
    children = {p: [] for p in directories}
    for entry in entries:
        parent, _, name = entry["path"].rpartition("/")
        require(parent in children, label + " missing parent " + parent)
        children[parent].append((name, entry))
    for parent, expected in directories.items():
        ordered = sorted(children[parent], key=lambda x: x[0].encode("utf-8") + (b"/" if x[1]["type"] == "tree" else b""))
        payload = b"".join(
            entry["mode"].lstrip("0").encode() + b" " + name.encode("utf-8") + b"\0" + bytes.fromhex(entry["sha"])
            for name, entry in ordered
        )
        require(git_hash("tree", payload) == expected, label + " invalid Git tree " + parent)
    leaves[label] = {e["path"]: {"mode": e["mode"], "type": e["type"], "sha": e["sha"]} for e in entries if e["type"] != "tree"}
    tree_receipts[label] = {"commit": ids[label], "tree": response["sha"], "truncated": False,
                            "leaf_count": len(leaves[label]), "verified_tree_objects": len(directories)}
old, main, feature, synthetic = (leaves[k] for k in ("old", "main", "feature", "synthetic"))
scope = sorted(p for p in set(old) | set(feature) if old.get(p) != feature.get(p))
scope_rows = [{"path": p, "old": old.get(p), "feature": feature.get(p), "synthetic": synthetic.get(p),
               "exact_feature_retained": feature.get(p) == synthetic.get(p)} for p in scope]
composed = [r["path"] for r in scope_rows if not r["exact_feature_retained"]]
require(composed == ["docs/design/ANALYSIS.md", "docs/design/research/PROGRESS.md"], "Unexpected composed feature files")
require(len(scope) == 91, "Feature scope count drift")
unrelated = sorted(set(main) - set(scope))
unrelated_rows = [{"path": p, "main": main[p], "synthetic": synthetic.get(p),
                   "exact_main_retained": main[p] == synthetic.get(p)} for p in unrelated]
require(all(r["exact_main_retained"] for r in unrelated_rows), "Unrelated main entries changed")
require(len(unrelated) == 913, "Unrelated main count drift")
require(not (set(old) - set(feature)), "Feature deletes old files")
require(set(synthetic) == set(main) | set(feature), "Unexpected merged path set")
require(len(synthetic) == 1004, "Merged leaf count drift")
require(api["synthetic"]["sha"] == ids["synthetic"], "Synthetic commit mismatch")
require(api["synthetic"]["tree"]["sha"] == expected_trees["synthetic"], "Synthetic tree mismatch")
require([p["sha"] for p in api["synthetic"]["parents"]] == [ids["main"], ids["feature"]], "Synthetic parents mismatch")
retention = {"repository": api["repository"], "trees": tree_receipts,
             "feature_scope_count": len(scope), "feature_exact_retained_count": len(scope) - len(composed),
             "composed_docs": composed, "feature_scope": scope_rows,
             "unrelated_main_count": len(unrelated), "unrelated_main_exact_retained_count": len(unrelated),
             "unrelated_main": unrelated_rows, "no_deletions_or_unexpected_paths": True}
dump("proof/tree-retention.json", retention)
source_manifest, doc_bytes = [], {}
for row in intake["docs"] + intake["sources"]:
    data = row["content"].encode("utf-8")
    actual = git_hash("blob", data)
    require(actual == row["sha"], "Fetched source Git blob mismatch: " + row["label"] + ":" + row["path"])
    expected = leaves[row["label"]][row["path"]]["sha"]
    require(actual == expected, "Source does not belong to pinned tree: " + row["path"])
    location = "sources/" + row["label"] + "/" + row["path"]
    target = ROOT / location
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    source_manifest.append({"label": row["label"], "path": row["path"], "custody_path": location,
                            "commit": ids[row["label"]], "git_blob": actual, "bytes": len(data), "sha256": sha256(data)})
    if row in intake["docs"]:
        doc_bytes[(row["label"], row["path"])] = data
dump("proof/source-byte-manifest.json", source_manifest)
doc_proofs = []
for path in composed:
    before, after = (doc_bytes[(k, path)] for k in ("old", "feature"))
    before_lines, after_lines = before.splitlines(keepends=True), after.splitlines(keepends=True)
    changes = [x for x in difflib.SequenceMatcher(None, before_lines, after_lines, autojunk=False).get_opcodes() if x[0] != "equal"]
    require(len(changes) == 1 and changes[0][0] == "insert", "Feature doc was not one pure insertion: " + path)
    tag, i1, i2, j1, j2 = changes[0]
    inserted = b"".join(after_lines[j1:j2])
    merged, current = (doc_bytes[(k, path)] for k in ("synthetic", "main"))
    require(after.count(inserted) == 1 and merged.count(inserted) == 1, "Doc insertion not unique: " + path)
    require(after.replace(inserted, b"", 1) == before, "Feature removal does not reproduce old doc")
    require(merged.replace(inserted, b"", 1) == current, "Synthetic removal does not reproduce current main doc")
    snippet_path = "proof/" + Path(path).name + ".feature-insertion.bin"
    (ROOT / snippet_path).write_bytes(inserted)
    doc_proofs.append({"path": path, "inserted_lines": j2-j1, "inserted_bytes": len(inserted),
                       "insertion_sha256": sha256(inserted), "insertion_path": snippet_path,
                       "old_git_blob": git_hash("blob", before), "feature_git_blob": git_hash("blob", after),
                       "main_git_blob": git_hash("blob", current), "synthetic_git_blob": git_hash("blob", merged),
                       "feature_without_exact_insertion_equals_old": True,
                       "synthetic_without_exact_insertion_equals_main": True,
                       "feature_and_synthetic_insertion_occurrences": 1})
dump("proof/documentation-subtraction.json", doc_proofs)
jobs = {int(j["id"]): j for j in api["jobs"]["jobs"]}
require(set(jobs) == {113378503111, 113378503488}, "Unexpected job set")
ci_specs = {
    "python": {"job": 113378503488, "commands": ["python tools/run_ci_tests.py"],
               "summaries": ["477 passed, 6 skipped, 2 warnings in 288.89s (0:04:48)"]},
    "cmake": {"job": 113378503111, "commands": [
        "python tools/check_cpp_warning_boundary.py",
        "python tools/check_ci_contract.py --vcpkg-root vcpkg",
        "cmake --preset windows-release -DCAPTURE_WERROR=ON",
        "cmake --build build/windows-release --target capture_daemon capture_core_tests session_doctor -j 4",
        "ctest --test-dir build/windows-release --output-on-failure --no-tests=error --output-junit ctest-results.xml -C Release",
        "python tools/run_native_ci_tests.py"],
        "summaries": ["100% tests passed, 0 tests failed out of 30", "6 passed, 2 warnings in 4.01s"]},
}
ci = []
for label, spec in ci_specs.items():
    job = jobs[spec["job"]]
    require(job["run_id"] == 37796872973, "Run identity changed")
    require(job["status"] == "completed" and job["conclusion"] == "success", "Hosted job did not succeed")
    require(all(s["conclusion"] == "success" for s in job["steps"]), "A job step did not succeed")
    text = json.loads((ROOT / ("intake/" + label + "-log.json")).read_bytes())["content"]
    require(text.startswith("\ufeff"), "Decoded log BOM representation differs")
    data = text.encode("utf-8")
    path = "ci/job-" + str(spec["job"]) + ".decoded.log"
    (ROOT / path).write_bytes(data)
    for expected in spec["commands"] + spec["summaries"] + [ids["synthetic"]]:
        require(expected in text, "Required CI command/summary/checkout absent: " + expected)
    lines = text.splitlines()
    ci.append({"name": label, "job_id": spec["job"], "run_id": 37796872973,
               "status": job["status"], "conclusion": job["conclusion"],
               "url": "https://github.com/Jacob-Met/CaptureSuite/actions/runs/37796872973/job/" + str(spec["job"]),
               "path": path, "bytes": len(data), "sha256": sha256(data), "decoded_unicode_characters": len(text),
               "bom_preserved": True, "crlf_sequences": text.count("\r\n"),
               "commands": spec["commands"],
               "summary_lines": [line for line in lines if any(s in line for s in spec["summaries"])],
               "checkout_lines": [line for line in lines if ids["synthetic"] in line],
               "steps": job["steps"]})
ci_receipt = {"run_id": 37796872973, "actual_checkout": ids["synthetic"],
              "actual_checkout_tree": expected_trees["synthetic"], "actual_checkout_parents": [ids["main"], ids["feature"]],
              "jobs": ci,
              "scope": "Complete decoded job text supplied by GitHub connector, re-encoded as UTF-8 without newline normalization; not raw transport/ZIP artifact custody.",
              "no_rerun_requested": True, "no_native_test_execution": True,
              "pr_metadata_observation": {"head_sha": api["pr"]["head"]["sha"], "base_sha": api["pr"]["base"]["sha"],
                   "merge_commit_sha": api["pr"]["merge_commit_sha"], "mergeable": api["pr"]["mergeable"],
                   "mergeable_state": api["pr"]["mergeable_state"],
                   "note": "The observed PR base.sha remains d43; qualification uses the independently retrieved actual synthetic commit parents70f+cd1 and logged checkout427."}}
dump("proof/ci-receipt.json", ci_receipt)
dump("proof/native-custody.json", {"device_id": "0e3d582f-e25b-44b2-8418-9639fc4e4e33",
    "root": str(ROOT), "python": platform.python_version(), "platform": platform.platform(),
    "executed": "This static identity/document subtraction verifier only; hosted tests executed on the GitHub Windows runners."})
dump("proof/peer-delta.json", {"from": ids["old"], "to": ids["main"], "changed_leaves": len(api["compare"]["files"]),
    "commits": len(api["compare"]["commits"]), "files": api["compare"]["files"]})
print(json.dumps({"result": "PASS", "feature_exact": len(scope)-len(composed), "feature_composed_docs": len(composed),
    "unrelated_exact": len(unrelated), "final_leaves": len(synthetic),
    "documentation": [{"path": p["path"], "lines": p["inserted_lines"], "bytes": p["inserted_bytes"]} for p in doc_proofs],
    "ci": [{"job": j["job_id"], "bytes": j["bytes"], "sha256": j["sha256"], "summary": j["summary_lines"]} for j in ci]}))
