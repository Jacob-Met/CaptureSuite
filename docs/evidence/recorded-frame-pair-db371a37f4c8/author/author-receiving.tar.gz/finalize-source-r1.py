import ast,ctypes,hashlib,json,os,pathlib,shutil,time
R=pathlib.Path("D:/Hamon/worktrees/capture-frame-pair-db371a37f4c8");C=R/'candidate-r2';F=R/'candidate-final-r1'
assert shutil.disk_usage('D:/').free>=2**30
old=json.loads((R/'author-native-r2/source-after.json').read_text(encoding='utf-8'))
assert json.loads((R/'author-native-r2/receipt.json').read_text(encoding='utf-8'))['status']=='passed'
def pin(p,rel):
 b=p.read_bytes();return {'path':rel,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
for x in old:assert pin(C/x['path'],x['path'])==x,x['path']
F.mkdir(exist_ok=False)
for x in old:
 p=F/x['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((C/x['path']).read_bytes())
progress='docs/design/research/PROGRESS.md'
p=F/progress;p.write_bytes(p.read_bytes()+"\n\n### 2026-10-09 08:50 UTC — Author native qualification\n\nThe private Windows / Qt 6.12 candidate passed 19 maintained checks: native image\norientation/copy/budget cases and actual decoder, pair-retention, playback, lifecycle\nand shortcut journeys. All 140 selected source files were byte-identical before\nand after the gate; all four recorded native PIDs were absent at delayed closure.\nDark and light 720×620 comparison captures were read directly and show both images,\nliteral identities and separate frame/player clocks without clipping. These are\nauthor results; independent original-first receiving remains pending. Earlier\nobserver/transport negatives and the unchanged #103 bodies remain in custody.\n".encode('utf-8'))
rows=[pin(F/x['path'],x['path']) for x in old]
changed=[x['path'] for x,y in zip(rows,old,strict=True) if x!=y]
assert changed==[progress],changed
for x in rows:
 if x['path'].endswith('.py'):ast.parse((F/x['path']).read_text(encoding='utf-8'))
runtime=[x for x in rows if x['path'] not in ['tests/test_retained_video_frame_model.py','tests/ui/test_review_frame_comparison.py']]
contribution=[x for x in rows if x['path'] in ["desktop/capture_desktop/review_video_frames.py","desktop/capture_desktop/widgets_review_video_frames.py","tests/test_retained_video_frame_model.py","tests/ui/test_review_frame_comparison.py","docs/operator/RECORDED_FRAME_COMPARISON.md","desktop/capture_desktop/widgets_review_video.py","docs/operator/README.md","docs/design/research/REVIEW_AND_EXPORT_UX.md","docs/design/research/PROGRESS.md"]];assert len(contribution)==9
for name,data in [('FINAL-SOURCE-MANIFEST.json',rows),('RUNTIME-MANIFEST.json',runtime),('CONTRIBUTION-MANIFEST.json',contribution)]:
 (R/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
images=[pin(R/'author-native-r2/evidence'/n,n) for n in ['comparison-dark-720x620.png','comparison-light-720x620.png']]
report={'at':time.time(),'pid':os.getpid(),'status':'passed','source_root':str(F),'files':len(rows),'runtime_files':len(runtime),'source_bytes':sum(x['bytes'] for x in rows),'docs_only_after_pass':changed,'unchanged_tested_files':len(rows)-1,'prior_gate':pin(R/'author-native-r2/receipt.json','author-native-r2/receipt.json'),'source_manifest':pin(R/'FINAL-SOURCE-MANIFEST.json','FINAL-SOURCE-MANIFEST.json'),'runtime_manifest':pin(R/'RUNTIME-MANIFEST.json','RUNTIME-MANIFEST.json'),'contributions':contribution,'images':images,'pending':'Independent receiving pending; no ref/PR/main/tag/Actions.'}
(R/'FINAL-SOURCE-ADMISSION.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report))
