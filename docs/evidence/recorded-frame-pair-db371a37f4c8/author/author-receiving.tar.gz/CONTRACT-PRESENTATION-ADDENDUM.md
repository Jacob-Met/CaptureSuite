# Pre-implementation panel placement clarification

Pre-implementation presentation clarification for #112: the existing Review layout has no scrolling container, so adding two images inline would force its capture/review controls taller. **Compare two frames…** will open a nonmodal, viewer-owned comparison panel. The original video controls remain reachable in their current layout, and the operator can switch segments while the two retained images stay visible. Closing that panel hides it and retains A/B until explicit Clear or the existing package/viewer reset; destroying the viewer clears its owned panel and images. This does not create an independent package Review window or change #107/app ownership. All frame admission, identity, allocation and no-side-effect semantics in the issue body remain unchanged.

Public record: https://github.com/Jacob-Met/CaptureSuite/issues/112#issuecomment-6077128507
