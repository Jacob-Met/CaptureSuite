import hashlib,json,os,pathlib,sys,time,traceback
R=pathlib.Path("D:/Hamon/worktrees/capture-frame-pair-db371a37f4c8")
O=R/'original'; E=R/'original-native-r3'
E.mkdir(exist_ok=False)
for p in ['desktop','libs/python/capture_analysis','libs/python/capture_session','libs/python/capture_protocol']:
    sys.path.insert(0,str(O/p))
from PySide6.QtCore import QCoreApplication,QEvent,QEventLoop,QTimer,Qt,qVersion
from PySide6.QtGui import QImage,QColor,QTransform,QFontDatabase
from PySide6.QtMultimedia import QMediaPlayer,QVideoFrame
from PySide6.QtWidgets import QApplication,QPushButton
from capture_desktop.widgets_review_video import RecordedVideoReview
from capture_desktop import theme
report={'at':time.time(),'pid':os.getpid(),'groups':[],'status':'started','python':sys.version,'qt':qVersion()}
def sha(b):return hashlib.sha256(b).hexdigest()
def pixels(im):
    x=im.convertToFormat(QImage.Format.Format_ARGB32)
    return sha(bytes(x.constBits())),[x.pixelColor(x.width()//2,x.height()//2).red(),x.pixelColor(x.width()//2,x.height()//2).green(),x.pixelColor(x.width()//2,x.height()//2).blue()]
def pins():
    rows=json.loads((R/'ORIGINAL-MANIFEST.json').read_text(encoding='utf-8'))
    for x in rows:assert sha((O/x['path']).read_bytes())==x['sha256'],x['path']
    return len(rows)
def write():(E/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
def wait(pred,seconds=10):
    end=time.monotonic()+seconds
    while not pred():
        if time.monotonic()>end:raise AssertionError('bounded native predicate timed out')
        loop=QEventLoop();QTimer.singleShot(20,loop.quit);loop.exec()
app=QApplication([])
for font in ['C:/Windows/Fonts/segoeui.ttf','C:/Windows/Fonts/seguisb.ttf']:
    QFontDatabase.addApplicationFont(font)
w=None
try:
    report['source_before']=pins()
    w=RecordedVideoReview();w.resize(900,780);w.show();w._toggle.setChecked(True)
    assert not any('Keep frame' in b.text() for b in w.findChildren(QPushButton))
    report['groups'].append({'name':'original has no two-frame retention controls','pass':True})
    package=O/'tests/fixtures/review_video'
    w.load_package(str(package),state='finalized')
    frame_rows=[]; retained=[]
    for source,tail,channel in [('sim.left <literal>','0001.mkv',0),('sim.right <literal>','0001.mkv',2),('sim.left <literal>','0002.mkv',1)]:
        index=next(i+1 for i,s in enumerate(w._segments) if s.source_id==source and s.relative_path.endswith(tail))
        w._choice.setCurrentIndex(index)
        wait(lambda:w._player is not None and w._ready)
        player=w._player; generation=w._generation
        assert player.playbackState()!=QMediaPlayer.PlaybackState.PlayingState
        assert not w._interval.enabled and player.playbackRate()==1.0
        w._play.click()
        wait(lambda:w._current(player,generation) and w._video.videoSink().videoFrame().isValid() and player.position()>0)
        w._play.click()
        wait(lambda:player.playbackState()==QMediaPlayer.PlaybackState.PausedState)
        f=w._video.videoSink().videoFrame()
        im=f.toImage().convertToFormat(QImage.Format.Format_ARGB32).copy()
        assert not im.isNull()
        digest,rgb=pixels(im)
        assert w._current(player,generation)
        seg=w._segments[index-1]
        row={'source':seg.source_id,'stream':seg.stream_id,'path':seg.relative_path,'frame_us':f.startTime(),'frame_end_us':f.endTime(),'player_ms':player.position(),'width':im.width(),'height':im.height(),'pixel_sha256':digest,'center_rgb':rgb,'rotation':f.rotationAngle().value,'mirrored':f.mirrored()}
        frame_rows.append(row);retained.append((im,digest));report['decoded_frames']=frame_rows;write()
        assert im.save(str(E/('decoded-'+str(len(frame_rows))+'.png')))
        for kept,expected in retained:assert pixels(kept)[0]==expected
    assert len({x['pixel_sha256'] for x in frame_rows})==3
    report['groups'].append({'name':'real original decoder and detached images across three segment selections','pass':True,'frames':frame_rows})
    invalid=next(i+1 for i,s in enumerate(w._segments) if s.relative_path.endswith('invalid.mkv'))
    w._choice.setCurrentIndex(invalid)
    wait(lambda:w._player is None)
    assert not w._play.isEnabled()
    for kept,expected in retained:assert pixels(kept)[0]==expected
    w.reset()
    assert not w._segments and w._player is None and not w._play.isEnabled()
    report['groups'].append({'name':'original failure and reset retire current media; detached copies remain independent','pass':True})
    sample=QImage(2,3,QImage.Format.Format_ARGB32)
    for y in range(3):
        for x in range(2):sample.setPixelColor(x,y,QColor(1+x+2*y,0,0))
    native=QVideoFrame(sample);native.setRotationAngle(QVideoFrame.RotationAngle.Rotation90);native.setMirrored(True)
    raw=native.toImage()
    assert raw.size()==sample.size() and [[raw.pixelColor(x,y).red() for x in range(2)] for y in range(3)]==[[1,2],[3,4],[5,6]]
    transformed=raw.transformed(QTransform().rotate(90)).mirrored(True,False)
    values=[[transformed.pixelColor(x,y).red() for x in range(transformed.width())] for y in range(transformed.height())]
    assert values==[[1,3,5],[2,4,6]],values
    report['groups'].append({'name':'native QVideoFrame presentation metadata is separate from toImage; clockwise rotation then horizontal mirror','pass':True,'matrix':values})
    report['source_after']=pins()
    report.update(status='passed',closed=time.time())
except BaseException:
    report.update(status='failed',error=traceback.format_exc(),closed=time.time());raise
finally:
    if w is not None:
        w.reset();w.close();w.deleteLater()
        QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete)
        app.processEvents()
    write()
print(json.dumps(report,indent=2))
