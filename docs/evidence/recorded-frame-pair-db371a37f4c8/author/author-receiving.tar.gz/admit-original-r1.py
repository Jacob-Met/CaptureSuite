import hashlib,json,pathlib,shutil,sys,time,traceback,os
R=pathlib.Path("D:/Hamon/worktrees/capture-frame-pair-db371a37f4c8")
D=pathlib.Path('D:/Hamon/worktrees/capture-video-repeat-db371a37f4c8-production')
A=R/'original-admission-r1'
A.mkdir(exist_ok=False)
report={'at':time.time(),'pid':os.getpid(),'status':'started'}
def sha(b): return hashlib.sha256(b).hexdigest()
def git(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def write(): (A/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
write()
try:
    packet=json.loads((R/'ORIGINAL-PACKET.json').read_text(encoding='utf-8'))
    pins={x['path']:x for x in packet['leaves']}
    rm=D/'environment-final-r1/runtime-files.json'
    rb=rm.read_bytes()
    assert sha(rb)=='d57d68032c6949a7d28813e62392d211c111828c0e7207682161d231df9217bb'
    runtime=json.loads(rb)
    for row in runtime['files']:
        p=D/row['path']; b=p.read_bytes()
        assert len(b)==row['bytes'] and sha(b)==row['sha256'],str(p)
    assert not runtime['links']
    report['runtime']={'manifest':str(rm),'sha256':sha(rb),'files':len(runtime['files']),'bytes':sum(x['bytes'] for x in runtime['files']),'read_only':True}
    dm=D/'original-admission.json'; db=dm.read_bytes()
    assert sha(db)=='4cfcc62eaeab95bca7788522088f46edad1fa39f169d3af4155b799b69b19a02'
    donor=json.loads(db)
    selected={}
    for row in donor['source']+donor['fixture']:
        p=pathlib.Path(row['path']); b=p.read_bytes()
        rel=p.relative_to(D/'original').as_posix()
        assert sha(b)==row['sha256'] and git(b)==row['git'],rel
        selected[rel]=(p,b)
    for rel in ['desktop/capture_desktop/widgets_review_video.py','desktop/capture_desktop/review_video_interval.py','docs/operator/RECORDED_VIDEO_REVIEW.md']:
        p=D/'candidate-r1'/rel
        selected[rel]=(p,p.read_bytes())
    out=R/'original'
    out.mkdir(exist_ok=False)
    rows=[]
    for rel,(p,b) in sorted(selected.items()):
        assert rel in pins and git(b)==pins[rel]['git'],rel
        q=out/rel; q.parent.mkdir(parents=True,exist_ok=True); q.write_bytes(b)
        assert q.read_bytes()==b
        rows.append({'path':rel,'bytes':len(b),'sha256':sha(b),'git':git(b),'donor':str(p)})
    (R/'ORIGINAL-MANIFEST.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
    (R/'CONTRACT.md').write_text('# CaptureSuite #112 public author contract\n\n'+packet['contract'],encoding='utf-8')
    report.update(status='passed',source_files=len(rows),source_bytes=sum(x['bytes'] for x in rows),manifest_sha256=sha((R/'ORIGINAL-MANIFEST.json').read_bytes()),contract_sha256=sha((R/'CONTRACT.md').read_bytes()),base=packet['consumer_base'],tree=packet['tree'],closed=time.time())
except BaseException:
    report.update(status='failed',error=traceback.format_exc(),closed=time.time());write();raise
write()
print(json.dumps(report,indent=2))
