import hashlib,json,pathlib,os,shutil,time,zipfile
R=pathlib.Path("D:/Hamon/worktrees/capture-frame-pair-db371a37f4c8");C=R/'candidate-final-r1';P=R/'publication-source-r1';P.mkdir(exist_ok=False)
assert shutil.disk_usage('D:/').free>=2**30
base=json.loads((R/'PUBLICATION-BASE-r1.json').read_text(encoding='utf-8'));tree={x['path']:x for x in base['leaves']}
def git(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
rows=json.loads((R/'CONTRIBUTION-MANIFEST.json').read_text(encoding='utf-8'));objects=[]
for x in rows:
 b=(C/x['path']).read_bytes();assert git(b)==x['git'];objects.append(dict(x,content=b.decode('utf-8')))
widget='desktop/capture_desktop/widgets_review_video.py';b=(C/widget).read_text(encoding='utf-8')
for s in reversed(base['spans']):
 assert b.count(s['new'])==1,s['old'];b=b.replace(s['new'],s['old'],1)
assert git(b.encode())==tree[widget]['sha']
previous={widget:b.encode()}
for p in ['docs/operator/README.md','docs/design/research/REVIEW_AND_EXPORT_UX.md','docs/design/research/PROGRESS.md']:
 b=(C/p).read_bytes();n=tree[p]['size'];assert git(b[:n])==tree[p]['sha'];previous[p]=b[:n]
unchanged=[]
final=json.loads((R/'FINAL-SOURCE-MANIFEST.json').read_text(encoding='utf-8'));changes={x['path'] for x in rows}
for x in final:
 if x['path'] not in changes:
  assert x['git']==tree[x['path']]['sha'],x['path'];unchanged.append(x)
assert len(unchanged)==131
for x in rows:
 if x['path'].endswith('.py'):assert (C/x['path']).read_bytes().startswith(b'# SPDX-License-Identifier: GPL-3.0-only')
readme="""CaptureSuite #112 qualified author source overlay; independent receiving pending.
Base: 9befdad4b8a6a5c420001ec9d77378115973ee53.
The nine current/ files are exact candidate-final-r1 source. previous/ holds the
four replaced base files. Five other files are additive. Verify SOURCE-MAP.json
before a reviewed owner integration. Preserve unrelated current source and apply
the six additive widget spans and append-only docs where the target has advanced.
Do not overwrite a different owner's target wholesale. This archive performs no
installation, launch, writes to recordings, Git ref changes or hosted actions.
Recovery: restore the four previous files only when their reviewed destination
still matches these exact candidate hashes, and remove the five added files only
when byte-exact. Native dependencies remain the separately pinned read-only donor.
"""
mapping={'base_commit':base['base_commit'],'base_tree':base['base_tree'],'files':rows,'previous':[{'path':p,'bytes':len(b),'git':git(b),'sha256':hashlib.sha256(b).hexdigest()} for p,b in previous.items()]}
with zipfile.ZipFile(P/'source-overlay.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
 for x in rows:z.writestr('current/'+x['path'],(C/x['path']).read_bytes())
 for p,b in previous.items():z.writestr('previous/'+p,b)
 z.writestr('SOURCE-MAP.json',json.dumps(mapping,indent=2)+'\n');z.writestr('READ-ME.txt',readme)
with zipfile.ZipFile(P/'source-overlay.zip') as z:
 assert len(z.infolist())==15
 for x in rows:assert git(z.read('current/'+x['path']))==x['git']
 for p,b in previous.items():assert z.read('previous/'+p)==b
(P/'SOURCE-PUBLICATION-INPUTS.json').write_text(json.dumps(objects,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
a=(P/'source-overlay.zip').read_bytes()
report={'status':'passed','at':time.time(),'pid':os.getpid(),'contributions':len(rows),'unchanged_original_runtime':len(unchanged),'shared_widget_spans_invert':6,'previous_doc_prefixes_exact':3,'source_overlay':{'bytes':len(a),'sha256':hashlib.sha256(a).hexdigest(),'git':git(a),'members':15},'native_source_unchanged':True,'independent_receiving':'pending'}
(P/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps(report))
