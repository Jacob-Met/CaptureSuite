import pathlib,json,hashlib,ast,time
R=pathlib.Path("D:/Hamon/worktrees/capture-frame-pair-db371a37f4c8");C=R/'candidate-r1';P=json.loads((R/'CANDIDATE-PACKET-r1.json').read_text())
proof=[]
for x in P['files']:
    p=C/x['path'];b=p.read_bytes();q=R/'author-gates-r1/staged-files'/x['path'];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
    before=ast.parse(x['content']);after=ast.parse(b)
    before.body=[n for n in before.body if not isinstance(n,(ast.Import,ast.ImportFrom))]
    after.body=[n for n in after.body if not isinstance(n,(ast.Import,ast.ImportFrom))]
    assert ast.dump(before)==ast.dump(after),x['path']
    proof.append({'path':x['path'],'sha256':hashlib.sha256(b).hexdigest(),'non_import_ast_equal':True})
p=C/'tests/ui/test_review_frame_comparison.py';text=p.read_text(encoding='utf-8')
old='independent replace preserves paused position rate interval; close reopens';new='replace preserves paused position/rate/repeat; close reopens'
assert text.count(old)==1
p.write_text(text.replace(old,new),encoding='utf-8',newline='\n')
(R/'LINT-STAGING-CORRECTION-r2.json').write_text(json.dumps({'at':time.time(),'reason':'Ruff E501 in observation group label only; no assertion/runtime change','proof':proof,'old':old,'new':new},indent=2)+'\n')
ast.parse((R/'run-author-gates-r2.py').read_text())
print('exact formatting/import-only proof; one observer label shortened; wrapper parsed')
