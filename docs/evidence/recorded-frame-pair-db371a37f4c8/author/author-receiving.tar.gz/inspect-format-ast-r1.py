import ast,json,pathlib,difflib
R=pathlib.Path("D:/Hamon/worktrees/capture-frame-pair-db371a37f4c8");P=json.loads((R/'CANDIDATE-PACKET-r1.json').read_text());x=next(x for x in P['files'] if x['path'].endswith('widgets_review_video_frames.py'))
a=ast.parse(x['content']);b=ast.parse((R/'candidate-r1'/x['path']).read_text(encoding='utf-8'))
for t in [a,b]:t.body=[n for n in t.body if not isinstance(n,(ast.Import,ast.ImportFrom))]
print('\n'.join(difflib.unified_diff(ast.dump(a,indent=2).splitlines(),ast.dump(b,indent=2).splitlines(),n=5)))
