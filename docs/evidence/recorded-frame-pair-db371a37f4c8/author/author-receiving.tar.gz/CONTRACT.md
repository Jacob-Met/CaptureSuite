# CaptureSuite #112 public author contract

Owner: estate-db371a37f4c8 / longwater_author_recovery, under the continuing native product mandate. Independent receiving will freeze original decoder/identity/lifecycle expectations before candidate access.

A researcher inspecting a finalized recording needs to keep one observed frame while choosing another segment or position, then compare the two without losing the first view. Add an explicit, session-local **Compare two frames** panel to the existing Recorded video viewer.

## Public consumer contract, before implementation

- Two independent slots, A and B. **Keep frame A/B** copies the current decoded frame only while the selected player is paused and a valid decoded image exists. The action never plays, pauses, seeks, changes speed or changes repeat. Invalid/unready/playing/oversized conversion refuses visibly and leaves both retained slots unchanged.
- Retain detached images, with the exact source ID, stream ID and package-relative segment path, decoded frame presentation timestamp in microseconds (or explicitly unavailable), observed player position in milliseconds, and decoded dimensions. Frame PTS and player position remain distinct; neither is session/checkpoint time or an exact seek/extraction guarantee.
- Images preserve aspect ratio and Qt frame presentation rotation/mirroring. Retaining a new frame replaces only its chosen slot. **Clear A/B** clears only that slot.
- Slots survive explicit segment changes, reload of a selected segment, pauses, collapsed/hidden review, and failure of a newly selected file within the same package. A package reset/load, failed package admission or viewer destruction clears both slots. New-player identity and existing selection generation prevent old frame callbacks from supplying a different segment's identity.
- Retain at most two images. Admit at most 16,777,216 decoded pixels and 64 MiB of converted ARGB32 pixel storage per slot before retaining; a refusal is explicit. This is a retained-image allocation policy, not a process-RSS guarantee. No disk writes, screenshot/export path, raw edits, autosave, inference, alignment, differencing or scientific equivalence claim.
- Existing explicit Play/Pause/seek, A/B repeat and requested/backend speed behavior remain unchanged. Focused new buttons use the existing viewer-local unmodified-Space convention; application shortcuts outside this panel retain their owner.

## Original and source boundary

Current main is `3960c0c756cd4e9facbde0d76eaaa3c31ab7c167`, tree `d1af33caaf7154e83def1dab035920907d417e8d` (1,280 leaves). This extension consumes accepted #103 source custody `9befdad4b8a6a5c420001ec9d77378115973ee53` / tree `8a5df2fbf36c32f78b6750252ba7fd7a4e2b285a`: widget `b02627d5b158ff2c69aff0b91c378d9034673615`, interval helper `44b4086d99653ea1582edf17c8df5c1fa504dba4`. T68 retains final native receiving/adoption of its combined review target; this claim does not replace that target.

Fenced paths: new `desktop/capture_desktop/review_video_frames.py` and `widgets_review_video_frames.py`; additive construction/frame-admission/reset hooks and helper methods in `widgets_review_video.py`, preserving existing methods except those small explicit hooks; focused new model/Qt tests; a dedicated operator guide plus index; additive review design decision and required PROGRESS entry. No ReviewScreen/app/daemon/capture/Analysis/exporter/shared runtime or dependency changes. #104 clip export, #107 offline private windows, #109 same-basename discovery and other owners stay independent. The #103 author directly confirmed no newer conflicting viewer reservation.

## Native qualification and publication boundary

Reuse the already admitted read-only MSI Python 3.12.10 / Qt 6.12.0 runtime and synthetic retained MKV fixtures. Before candidate source: independently readmit exact original source/runtime, establish real decoded-frame availability, original playback/identity behavior and missing pair controls. Then test actual native keep/replace/clear, distinct red/blue/green segments, stale callbacks, package/reset/failure preservation, keyboard activation, compact dark/light presentation and unchanged raw bytes. No physical capture/device claim.

AGENTS, review design/operator guide and all three complete current workflows were read. Workflows trigger push main/master or v* tags, PR or manual dispatch; none subscribes to issues/comments/create. This issue is inert coordination. Standing no-Actions remains: no PR/main/tag/dispatch/workflow edits or shared installation. Source and evidence use immutable objects first; final source publication/adoption requires fresh owner/workflow/current-parent checks. No candidate or receiving acceptance is implied by this claim.
