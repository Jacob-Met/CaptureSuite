import pathlib,json,hashlib,ast,time
R=pathlib.Path("D:/Hamon/worktrees/capture-frame-pair-db371a37f4c8");C=R/'candidate-r1';P=json.loads((R/'CANDIDATE-PACKET-r1.json').read_text(encoding='utf-8'))
proof=[]
for x in P['files']:
    p=C/x['path'];b=p.read_bytes();q=R/'author-gates-r1/staged-files'/x['path'];q.parent.mkdir(parents=True,exist_ok=True)
    if q.exists():assert q.read_bytes()==b
    else:q.write_bytes(b)
    before=ast.parse(x['content']);after=ast.parse(b)
    before.body=[n for n in before.body if not isinstance(n,(ast.Import,ast.ImportFrom))]
    after.body=[n for n in after.body if not isinstance(n,(ast.Import,ast.ImportFrom))]
    assert ast.dump(before)==ast.dump(after),x['path']
    proof.append({'path':x['path'],'sha256':hashlib.sha256(b).hexdigest(),'non_import_ast_equal':True})
p=C/'tests/ui/test_review_frame_comparison.py';text=p.read_text(encoding='utf-8')
old='independent replace preserves paused position rate interval; close reopens';new='replace preserves paused position/rate/repeat; close reopens'
assert text.count(old)==1
p.write_text(text.replace(old,new),encoding='utf-8',newline='\n')
(R/'LINT-STAGING-CORRECTION-r3.json').write_text(json.dumps({'at':time.time(),'reason':'R2 observer read UTF-8 JSON using Windows default encoding. Explicit UTF-8 proves formatting/import-only. One E501 observation label shortened; no assertion/runtime change.','proof':proof,'old':old,'new':new},indent=2)+'\n',encoding='utf-8')
ast.parse((R/'run-author-gates-r2.py').read_text(encoding='utf-8'))
print('exact formatting/import-only proof; one observer label shortened; wrapper parsed')
