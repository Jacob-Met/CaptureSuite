from __future__ import annotations
import gc, hashlib, json, os, sys, time, traceback
from pathlib import Path
ROOT=Path("D:/Hamon/receiving/capture-frame-pair-root-db371a37f4c8")
CANDIDATE=ROOT/"candidate-r1"
sys.dont_write_bytecode=True
for p in ("desktop","libs/python/capture_analysis","libs/python/capture_session","libs/python/capture_protocol"):
    sys.path.insert(0,str(CANDIDATE/p))
from PySide6.QtCore import qVersion
from PySide6.QtGui import QColor,QImage
from PySide6.QtMultimedia import QVideoFrame,QtVideo
from PySide6.QtWidgets import QApplication
from capture_desktop.review_video import RecordedVideoSegment
from capture_desktop.review_video_frames import retain_video_frame
app=QApplication([])
OUT=ROOT/"candidate-model-r1"
OUT.mkdir(exist_ok=False)
r={"schema":"capture112-independent-candidate-native-model-v1","start":time.time(),"pid":os.getpid(),"parent":os.getppid(),"qt":qVersion(),"platform":app.platformName(),"cases":[],"original_freeze_sha256":hashlib.sha256((ROOT/"ORIGINAL-FREEZE-r2.json").read_bytes()).hexdigest()}
assert r["original_freeze_sha256"]=="ec83fad003ac5245529c0560b5c4e52dcdaf1b128b1edd8bf851f0b277c80b9f"
assert qVersion()=="6.12.0" and app.platformName()=="windows"
segment=RecordedVideoSegment("camera <exact>","stream & exact","sources/camera/streams/view/segments/0007.mkv")
def image_hash(image):
    return hashlib.sha256(bytes(image.constBits())).hexdigest()
def check(name,call):
    try:r["cases"].append({"name":name,"ok":True,"result":call()})
    except Exception:r["cases"].append({"name":name,"ok":False,"traceback":traceback.format_exc()})
    (OUT/"progress.json").write_text(json.dumps(r,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
colors={letter:QColor(*value) for letter,value in zip("ABCDEF",[(240,30,20),(10,220,30),(20,40,230),(235,215,20),(225,25,210),(25,215,220)])}
def base_frame():
    image=QImage(3,2,QImage.Format.Format_ARGB32)
    for i,letter in enumerate("ABCDEF"):image.setPixelColor(i%3,i//3,colors[letter])
    return image,QVideoFrame(image)
original=json.loads((ROOT/"ORIGINAL-FREEZE-r2.json").read_text(encoding="utf-8"))
rotations={0:QtVideo.Rotation.None_,90:QtVideo.Rotation.Clockwise90,180:QtVideo.Rotation.Clockwise180,270:QtVideo.Rotation.Clockwise270}
def transforms():
    rows=[]
    for fixed in original["presentation"]["rows"]:
        image,frame=base_frame()
        frame.setRotation(rotations[fixed["angle"]]);frame.setMirrored(fixed["mirrored"]);frame.setStartTime(123456)
        got=retain_video_frame(frame,segment,4321)
        assert got.segment==segment and got.frame_start_us==123456 and got.player_position_ms==4321
        assert got.decoded_width==3 and got.decoded_height==2
        assert got.rotation_degrees==fixed["angle"] and got.mirrored==fixed["mirrored"]
        expected=fixed["literal"]
        assert got.image.width()==len(expected[0]) and got.image.height()==len(expected)
        for y,line in enumerate(expected):
            for x,letter in enumerate(line):assert got.image.pixelColor(x,y)==colors[letter]
        assert image_hash(got.image)==fixed["presented"]["sha256"]
        assert got.image.format()==QImage.Format.Format_ARGB32
        assert got.image.save(str(OUT/("matrix-"+str(fixed["angle"])+"-"+str(fixed["mirrored"])+".png")))
        rows.append({"rotation":fixed["angle"],"mirror":fixed["mirrored"],"sha256":image_hash(got.image),"pts_us":got.frame_start_us,"position_ms":got.player_position_ms})
    return rows
def detach_and_unknown_pts():
    image,frame=base_frame()
    got=retain_video_frame(frame,segment,17)
    assert got.frame_start_us is None
    frozen=image_hash(got.image)
    assert frame.map(QVideoFrame.MapMode.ReadWrite)
    data=frame.bits(0)
    before=bytes(data[:4]);data[:4]=bytes([0,0,0,255]);after=bytes(data[:4])
    assert before!=after
    del data
    frame.unmap()
    image.fill(QColor("black"))
    del frame,image
    gc.collect()
    assert image_hash(got.image)==frozen
    assert got.image.pixelColor(0,0)==colors["A"]
    return {"frame_pts":None,"position":17,"native_mapped_buffer_changed":True,"retained_sha256":frozen}
class ObserveConversion:
    def __init__(self,frame,returned=None):
        self.frame=frame;self.calls=0;self.returned=returned
    def __getattr__(self,name):return getattr(self.frame,name)
    def toImage(self):
        self.calls+=1
        return self.frame.toImage() if self.returned is None else self.returned
def limits():
    rows=[]
    for w,h,accepted in [(4096,4096,True),(8192,2048,True),(4097,4096,False)]:
        image=QImage(w,h,QImage.Format.Format_ARGB32);image.fill(QColor(12,34,56,255))
        frame=QVideoFrame(image);assert frame.isValid()
        watched=ObserveConversion(frame)
        if accepted:
            kept=retain_video_frame(watched,segment,9)
            assert kept.image.sizeInBytes()==67108864
            assert kept.decoded_width==w and kept.decoded_height==h
            assert kept.image.pixelColor(w-1,h-1)==QColor(12,34,56,255)
            assert watched.calls==1
            rows.append({"size":[w,h],"accepted":True,"storage":kept.image.sizeInBytes(),"conversion_calls":watched.calls})
            del kept
        else:
            try:retain_video_frame(watched,segment,9)
            except ValueError as exc:
                assert "16,777,216" in str(exc) and "64 MiB" in str(exc)
                assert watched.calls==0
                rows.append({"size":[w,h],"accepted":False,"reason":str(exc),"conversion_calls":watched.calls})
            else:raise AssertionError("Oversized native frame admitted")
        del watched,frame,image
        gc.collect()
    return rows
def native_refusals():
    rows=[]
    try:retain_video_frame(QVideoFrame(),segment,0)
    except ValueError as exc:rows.append({"case":"invalid_native_QVideoFrame","message":str(exc)})
    else:raise AssertionError("Invalid frame admitted")
    image,frame=base_frame()
    null=ObserveConversion(frame,QImage())
    try:retain_video_frame(null,segment,0)
    except ValueError as exc:
        assert null.calls==1
        rows.append({"case":"injected_null_conversion_after_valid_native_geometry","message":str(exc)})
    else:raise AssertionError("Null conversion admitted")
    large=QImage(4097,4096,QImage.Format.Format_ARGB32);large.fill(QColor("blue"))
    mismatched=ObserveConversion(frame,large)
    try:retain_video_frame(mismatched,segment,0)
    except ValueError as exc:
        assert mismatched.calls==1 and "comparison limit" in str(exc)
        rows.append({"case":"injected_oversized_conversion_of_small_valid_native_frame","message":str(exc)})
    else:raise AssertionError("Oversized conversion admitted")
    return rows
check("all_eight_frozen_literal_pixel_transforms",transforms)
check("detached_from_mutated_native_buffer_and_unavailable_pts",detach_and_unknown_pts)
check("inclusive_pixel_storage_and_first_oversize",limits)
check("invalid_and_conversion_refusals",native_refusals)
r["source"]=[]
for e in json.loads((ROOT/"CANDIDATE-ADMISSION-r1.json").read_text(encoding="utf-8"))["files"]:
    p=CANDIDATE/e["path"]
    got=hashlib.sha256(p.read_bytes()).hexdigest()
    assert got==e["sha256"]
    assert p.stat().st_mtime_ns==int(e["mtimeNs"])
    r["source"].append({"path":e["path"],"sha256":got,"mtime_exact":True})
r["end"]=time.time();r["ok"]=all(c["ok"] for c in r["cases"])
(OUT/"receipt.json").write_text(json.dumps(r,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"ok":r["ok"],"pid":os.getpid(),"cases":r["cases"]},ensure_ascii=False))
sys.exit(0 if r["ok"] else 1)
