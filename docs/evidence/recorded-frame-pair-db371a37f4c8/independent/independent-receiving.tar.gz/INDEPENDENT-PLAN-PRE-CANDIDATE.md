# CaptureSuite #112 independent original-first receiving plan

Original source: 9befdad4b8a6a5c420001ec9d77378115973ee53, tree 8a5df2fbf36c32f78b6750252ba7fd7a4e2b285a.
Boundary: only offered 132 original files, public contract/addendum, original fixture and readonly 18,539-file native runtime admitted. Candidate runtime, author tests, goldens and author native outcomes remain withheld.

## Original controls
1. Native original widget has play/seek/rate/interval/reload/disclosure, and no Compare/Keep/Clear pair controls.
2. Original inventory has four exact source/stream/path identities; equal 0001.mkv basenames stay distinct and literal angle brackets/ampersands stay literal.
3. Actual decoding of three color MKVs gives 160x120 native images. Record each complete ARGB32 pixel hash/color grid/startTime microseconds and player position milliseconds separately.
4. Explicit Play then Pause reaches PausedState. Paused seek/rate/interval changes do not play. Reload/select/invalid media clear interval/rate without autoplay. Collapse/hide preserves interval and does not auto-resume.
5. Old player and generation cannot affect current state through original _sync/_failed callbacks.
6. A hand-colored 3x2 native QImage/QVideoFrame demonstrates detached copying and separates raw conversion from presentation. All four rotations and two mirror states have literal pixel expectations.
7. A real host Space QShortcut establishes native focused-button routing. This is a viewer-host test; no complete MainWindow run is claimed.
8. Source/fixture hashes and mtimes remain exact. Runtime uses -B and no installation.

## Candidate consumer expectations
- Viewer-owned nonmodal Compare two frames panel, retaining original segment and playback access in compact Review layout.
- Keep frame A/B only admits a paused, ready, valid decoded frame for the current player and generation. Keep itself changes no position/play state/interval/repeat/requested or reported speed. Invalid, null, unready, playing and oversized input visibly refuse with both old slots exact.
- Each slot is independent and detached. Preserve literal source, stream, package-relative path, observed frame PTS or explicit unavailable, separately observed player milliseconds and decoded dimensions.
- Stale old-player and old-generation frame callbacks cannot supply image, availability or identity for the selected segment.
- At most two retained ARGB32 images. Inclusive 16,777,216 pixels and 64 MiB per slot; test inclusive boundary and first larger dimensions before retention. This is not a process-RSS guarantee.
- Present pixels with clockwise rotation then horizontal presentation mirroring and preserve image aspect ratio on resize.
- Keep slots through segment selection/reload/decoder failure, hide/collapse and comparison close/hide within one package. Clear only selected slot.
- Package reset/load, failed package admission and viewer destruction clear both slots.
- Native unmodified Space activates focused Keep/Clear despite a conflicting host shortcut; other modifiers and unrelated controls keep their routing.
- Compact dark/light windows expose controls and literal provenance while original video controls remain usable. Review at 900x700 and 1280x800; record actual minimum geometry rather than inventing a universal screen guarantee.
- Product does not write original files, export, infer alignment, compare scientific equivalence, or add shared runtime dependencies.

## Hand-colored pixel matrices
Raw 3x2: [A B C] [D E F].
Clockwise 90: [D A] [E B] [F C].
Clockwise 180: [F E D] [C B A].
Clockwise 270: [C F] [B E] [A D].
Mirrored 0: [C B A] [F E D].
Mirrored 90: [A D] [B E] [C F].
Mirrored 180: [D E F] [A B C].
Mirrored 270: [F C] [E B] [D A].

No exact seek/extraction, session/checkpoint mapping, physical capture, installed adoption, CI run or complete application integration claim.
