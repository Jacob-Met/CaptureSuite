$ErrorActionPreference = 'Stop'
$root = 'D:/Hamon/receiving/capture-frame-pair-root-db371a37f4c8'
$os = Get-CimInstance Win32_OperatingSystem
$c = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'"
$d = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='D:'"
$guard = [ordered]@{schema='capture112-root-native-guard-v1';at=[DateTime]::UtcNow.ToString('o');pid=$PID;machine=[Environment]::MachineName;user=[System.Security.Principal.WindowsIdentity]::GetCurrent().Name;boot=$os.LastBootUpTime.ToUniversalTime().ToString('o');freeC=[long]$c.FreeSpace;freeD=[long]$d.FreeSpace;freeMemory=[long]$os.FreePhysicalMemory*1024;floorC=1073741824;floorD=1073741824;floorMemory=2147483648}
$guard | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 "$root/ORIGINAL-ADMISSION-GUARD.json"
if ($guard.machine -ne 'MSI' -or $guard.user -ne 'MSI\Veria' -or $guard.boot -ne '2026-10-04T04:03:32.5000000Z' -or $guard.freeC -lt $guard.floorC -or $guard.freeD -lt $guard.floorD -or $guard.freeMemory -lt $guard.floorMemory) { throw 'Identity, boot or resource guard refused' }
$started=[DateTime]::UtcNow.ToString('o')
$p = Start-Process -FilePath 'C:/Program Files/nodejs/node.exe' -ArgumentList @("$root/admit-original.mjs") -WorkingDirectory $root -RedirectStandardOutput "$root/ORIGINAL-ADMISSION.stdout" -RedirectStandardError "$root/ORIGINAL-ADMISSION.stderr" -PassThru
$child=$p.Id
$done=$p.WaitForExit(180000)
if (!$done) { Stop-Process -Id $child -ErrorAction SilentlyContinue; throw 'Bounded original admission timed out' }
$p.Refresh()
[ordered]@{schema='capture112-root-child-exit-v1';start=$started;end=[DateTime]::UtcNow.ToString('o');controller=$PID;child=$child;exit=$p.ExitCode} | ConvertTo-Json | Set-Content -Encoding UTF8 "$root/ORIGINAL-ADMISSION-EXIT.json"
if ($p.ExitCode -ne 0) { throw "Original admission failed with $($p.ExitCode)" }
