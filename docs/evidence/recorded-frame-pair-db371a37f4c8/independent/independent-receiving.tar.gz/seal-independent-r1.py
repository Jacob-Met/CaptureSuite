from __future__ import annotations
import hashlib,json,os,subprocess,tarfile,time
from pathlib import Path
ROOT=Path("D:/Hamon/receiving/capture-frame-pair-root-db371a37f4c8")
OUT=ROOT/"seal-r1"
OUT.mkdir(exist_ok=False)
def pin(p):
    b=p.read_bytes()
    return {"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),"git":hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest(),"mtime_ns":p.stat().st_mtime_ns}
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
closed=read(ROOT/"INDEPENDENT-RECEIVING-CLOSE-r2.json")
assert pin(ROOT/"INDEPENDENT-RECEIVING-CLOSE-r2.json")["sha256"]=="57e5b87ee8d1cc1ccf29f7951712f37a8884544459ad9bf0c5eb42c7f09d8bc1"
assert read(ROOT/"INDEPENDENT-CLOSE-r2-EXIT.json")["exitCode"]==0
for e in closed["payloads"]:
    p=pin(ROOT/e["path"])
    assert p["sha256"]==e["sha256"] and p["git"]==e["git"],e["path"]
for e in read(ROOT/"original-native-r2/receipt.json")["source_after"]:
    p=pin(ROOT/"original"/e["path"])
    assert p["sha256"]==e["sha256"] and p["mtime_ns"]==e["mtime_ns"]
for e in read(ROOT/"CANDIDATE-ADMISSION-r1.json")["files"]:
    p=pin(ROOT/"candidate-r1"/e["path"])
    assert p["sha256"]==e["sha256"] and str(p["mtime_ns"])==e["mtimeNs"]
payloads=[]
for p in sorted(ROOT.rglob("*")):
    rel=p.relative_to(ROOT).as_posix()
    if rel=="seal-r1" or rel.startswith("seal-r1/") or rel.startswith("SEAL-INDEPENDENT-r1"):continue
    assert not p.is_symlink(),rel
    if p.is_file():payloads.append({"path":rel,**pin(p)})
manifest={"schema":"capture112-independent-native-seal-manifest-v1","at":time.time(),"root":str(ROOT),"original_files":132,"candidate_files":138,"closed_independent_receiving":pin(ROOT/"INDEPENDENT-RECEIVING-CLOSE-r2.json"),"author_disclosure":"Root read author report/tests only after the recorded independent closure; no author source/report is silently substituted for this receiver's expected results.","payloads":payloads}
(OUT/"MANIFEST.json").write_bytes((json.dumps(manifest,ensure_ascii=False,indent=2)+"\n").encode())
report=(ROOT/"INDEPENDENT.md").read_bytes();(OUT/"INDEPENDENT.md").write_bytes(report)
archive=OUT/"independent-receiving.tar.gz"
with tarfile.open(archive,"x:gz") as t:
    for e in payloads:t.add(ROOT/e["path"],arcname=e["path"],recursive=False)
    t.add(OUT/"MANIFEST.json",arcname="MANIFEST.json",recursive=False)
expected={e["path"]:e for e in payloads};expected["MANIFEST.json"]=pin(OUT/"MANIFEST.json")
members=[]
with tarfile.open(archive,"r:gz") as t:
    for m in t:
        assert m.isfile() and not m.name.startswith(("/", "\\")) and ".." not in Path(m.name).parts and m.name not in members,m.name
        members.append(m.name);assert m.name in expected,m.name
        b=t.extractfile(m).read();e=expected[m.name]
        assert len(b)==e["bytes"] and hashlib.sha256(b).hexdigest()==e["sha256"],m.name
assert set(members)==set(expected)
for e in payloads:
    p=pin(ROOT/e["path"]);assert p=={k:e[k] for k in ["bytes","sha256","git","mtime_ns"]},e["path"]
raw=subprocess.check_output(["powershell.exe","-NoProfile","-Command","Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CreationDate,CommandLine | ConvertTo-Json -Depth 5 -Compress"],timeout=20)
processes=json.loads(raw.decode("utf-8-sig"));by={p["ProcessId"]:p for p in processes}
ancestors=set();p=by.get(os.getpid())
while p and p["ProcessId"] not in ancestors:ancestors.add(p["ProcessId"]);p=by.get(p["ParentProcessId"])
owned=[p for p in processes if str(ROOT).replace("\\","/") in (p.get("CommandLine") or "").replace("\\","/") and p["ProcessId"] not in ancestors and not(p["ParentProcessId"]==os.getpid() and p["Name"]=="powershell.exe")]
assert not owned,owned
close_exit=read(ROOT/"INDEPENDENT-CLOSE-r2-EXIT.json")
close_ids=[close_exit["child"],close_exit["controller"],close_exit["parent"]]
close_census=[{"pid":v,"present":v in by,"process":{k:by[v].get(k) for k in ["Name","CreationDate","ExecutablePath"]} if v in by else None} for v in close_ids]
audit={"schema":"capture112-independent-seal-final-audit-v1","at":time.time(),"pid":os.getpid(),"parent":os.getppid(),"payloads_exact":len(payloads),"safe_unique_regular_members":len(members),"original_and_candidate_source_exact":True,"prior_close_pids":close_census,"owned_processes":[],"source_executed":False}
(OUT/"FINAL-AUDIT.json").write_bytes((json.dumps(audit,ensure_ascii=False,indent=2)+"\n").encode())
sealed={"schema":"capture112-independent-archive-seal-v1","at":time.time(),"pid":os.getpid(),"parent":os.getppid(),"payload_count":len(payloads),"member_count":len(members),"archive":pin(archive),"manifest":pin(OUT/"MANIFEST.json"),"report":pin(OUT/"INDEPENDENT.md"),"audit":pin(OUT/"FINAL-AUDIT.json"),"no_product_rerun":True}
(OUT/"SEAL.json").write_bytes((json.dumps(sealed,ensure_ascii=False,indent=2)+"\n").encode())
prefix="docs/evidence/recorded-frame-pair-db371a37f4c8/independent/"
objects=[]
for name in ["independent-receiving.tar.gz","INDEPENDENT.md","MANIFEST.json","FINAL-AUDIT.json","SEAL.json"]:
    p=OUT/name;objects.append({"path":prefix+name,"native":str(p),**pin(p)})
(OUT/"OBJECT-MAP.json").write_bytes((json.dumps(objects,ensure_ascii=False,indent=2)+"\n").encode())
for name in ["independent-receiving.tar.gz","INDEPENDENT.md","MANIFEST.json","FINAL-AUDIT.json","SEAL.json"]:
    p=OUT/name
    import base64
    (OUT/(name+".b64")).write_bytes(base64.b64encode(p.read_bytes())+b"\n")
print(json.dumps({"ok":True,"pid":os.getpid(),"payloads":len(payloads),"members":len(members),"objects":objects,"close_census":close_census},ensure_ascii=False))
