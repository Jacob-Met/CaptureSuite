from __future__ import annotations
import hashlib, json, os, sys, time, traceback
from pathlib import Path
ROOT = Path("D:/Hamon/receiving/capture-frame-pair-root-db371a37f4c8")
ORIGINAL = ROOT / "original"
sys.dont_write_bytecode = True
for relative in ("desktop", "libs/python/capture_analysis", "libs/python/capture_session", "libs/python/capture_protocol"):
    sys.path.insert(0, str(ORIGINAL / relative))
from PySide6.QtCore import QCoreApplication, QEvent, QRectF, Qt, qVersion
from PySide6.QtGui import QColor, QImage, QKeySequence, QPainter, QShortcut, QTransform
from PySide6.QtMultimedia import QMediaPlayer, QVideoFrame, QtVideo
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QDialog, QPushButton, QVBoxLayout, QWidget
from capture_desktop import theme
from capture_desktop.widgets_review_video import RecordedVideoReview

OUT = ROOT / "original-native-r1"
OUT.mkdir(exist_ok=False)
result = {"schema": "capture112-independent-native-original-v1", "start": time.time(),
          "pid": os.getpid(), "parent": os.getppid(), "python": sys.version,
          "qt": qVersion(), "groups": [], "observations": {}, "candidate_exposed": False}
app = QApplication([])
result["platform"] = app.platformName()
assert qVersion() == "6.12.0"
assert sys.version_info[:3] == (3, 12, 10)
assert app.platformName() == "windows"

def pins():
    manifest = json.loads((ROOT / "ORIGINAL-ADMISSION-PACKET.json").read_text(encoding="utf-8"))["manifest"]
    return [{"path": e["path"], "bytes": (ORIGINAL / e["path"]).stat().st_size,
             "sha256": hashlib.sha256((ORIGINAL / e["path"]).read_bytes()).hexdigest(),
             "mtime_ns": (ORIGINAL / e["path"]).stat().st_mtime_ns} for e in manifest]

source_before = pins()

def wait(predicate, label, timeout=8000):
    until = time.monotonic() + timeout / 1000
    while time.monotonic() < until:
        app.processEvents()
        if predicate():
            return
        QTest.qWait(15)
    raise AssertionError("Timed out: " + label)

def observe(name, function):
    started = time.time()
    try:
        value = function()
        result["groups"].append({"name": name, "ok": True, "seconds": time.time() - started})
        result["observations"][name] = value
    except Exception:
        result["groups"].append({"name": name, "ok": False, "seconds": time.time() - started,
                                 "traceback": traceback.format_exc()})
    (OUT / "progress.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def pixels(image):
    rgba = image.convertToFormat(QImage.Format.Format_ARGB32)
    return {"width": rgba.width(), "height": rgba.height(), "storage_bytes": rgba.sizeInBytes(),
            "sha256": hashlib.sha256(bytes(rgba.constBits())).hexdigest(),
            "center_rgba": list(rgba.pixelColor(rgba.width() // 2, rgba.height() // 2).getRgb()),
            "grid_rgba": [[list(rgba.pixelColor(x, y).getRgb()) for x in (0, rgba.width()//2, rgba.width()-1)]
                           for y in (0, rgba.height()//2, rgba.height()-1)]}

def primitive():
    colors = {letter: QColor(*value) for letter, value in zip("ABCDEF",
             [(240,30,20), (10,220,30), (20,40,230), (235,215,20), (225,25,210), (25,215,220)])}
    image = QImage(3, 2, QImage.Format.Format_ARGB32)
    for i, letter in enumerate("ABCDEF"):
        image.setPixelColor(i % 3, i // 3, colors[letter])
    frame = QVideoFrame(image)
    assert frame.isValid()
    assert frame.startTime() == -1
    frame.setStartTime(123456)
    assert frame.startTime() == 123456
    raw = frame.toImage().convertToFormat(QImage.Format.Format_ARGB32).copy()
    original_hash = pixels(raw)["sha256"]
    expected = {
        (0, False): ["ABC", "DEF"], (90, False): ["DA", "EB", "FC"],
        (180, False): ["FED", "CBA"], (270, False): ["CF", "BE", "AD"],
        (0, True): ["CBA", "FED"], (90, True): ["AD", "BE", "CF"],
        (180, True): ["DEF", "ABC"], (270, True): ["FC", "EB", "DA"]}
    rotations = {0: QtVideo.Rotation.None_, 90: QtVideo.Rotation.Clockwise90,
                 180: QtVideo.Rotation.Clockwise180, 270: QtVideo.Rotation.Clockwise270}
    rows = []
    for (angle, mirrored), matrix in expected.items():
        frame.setRotation(rotations[angle])
        frame.setMirrored(mirrored)
        unchanged = frame.toImage().convertToFormat(QImage.Format.Format_ARGB32)
        assert pixels(unchanged)["sha256"] == original_hash
        presented = raw.transformed(QTransform().rotate(angle))
        if mirrored:
            presented = presented.mirrored(True, False)
        assert presented.width() == len(matrix[0]) and presented.height() == len(matrix)
        for y, line in enumerate(matrix):
            for x, letter in enumerate(line):
                assert presented.pixelColor(x, y) == colors[letter]
        canvas = QImage(presented.size(), QImage.Format.Format_ARGB32)
        canvas.fill(QColor("black"))
        painter = QPainter(canvas)
        try:
            frame.paint(painter, QRectF(0, 0, canvas.width(), canvas.height()), QVideoFrame.PaintOptions())
        finally:
            painter.end()
        for y, line in enumerate(matrix):
            for x, letter in enumerate(line):
                actual = canvas.pixelColor(x, y)
                assert actual == colors[letter], (angle, mirrored, x, y, actual.getRgb(), colors[letter].getRgb())
        rows.append({"angle": angle, "mirrored": mirrored, "literal": matrix,
                     "presented": pixels(presented), "native_frame_paint": pixels(canvas)})
    detached = raw.copy()
    image.fill(QColor("black"))
    assert pixels(detached)["sha256"] == original_hash
    return {"raw": pixels(raw), "frame_pts_us": frame.startTime(), "rows": rows, "detached_copy_exact": True}

host = QWidget()
host.setObjectName("Root")
host.setWindowTitle("CaptureSuite original independent receiving")
layout = QVBoxLayout(host)
view = RecordedVideoReview()
layout.addWidget(view)
checkpoint = []
shortcut = QShortcut(QKeySequence(Qt.Key.Key_Space), host)
shortcut.activated.connect(lambda: checkpoint.append("host Space"))
host.resize(900, 700)
theme.apply_theme(app, setting="dark")
host.show()
wait(lambda: host.isVisible(), "native host visible")
fixture = ORIGINAL / "tests/fixtures/review_video"

def state():
    player = view._player
    return {"generation": view._generation, "ready": view._ready, "identity": view._identity.text(),
            "selected": view._choice.currentIndex(), "play_requested": view._play_requested,
            "player_state": player.playbackState().name if player else None,
            "position_ms": player.position() if player else None, "duration_ms": player.duration() if player else None,
            "requested_rate": view._rate.currentData(), "reported_rate": player.playbackRate() if player else None,
            "interval": {"a": view._interval.start_ms, "b": view._interval.end_ms, "enabled": view._interval.enabled},
            "status": view._status.text()}

def inventory():
    assert not any("Compare two frames" in b.text() or "Keep frame" in b.text() for b in view.findChildren(QPushButton))
    assert not view.findChildren(QDialog)
    view.load_package(str(fixture), state="finalized")
    assert view._player is None and not view._ready and view._choice.count() == 5
    QTest.mouseClick(view._toggle, Qt.MouseButton.LeftButton)
    assert view._body.isVisible()
    expected = [
        ("sim.left <literal>", "front & camera", "sources/sim.left/streams/front/segments/0001.mkv"),
        ("sim.left <literal>", "front & camera", "sources/sim.left/streams/front/segments/0002.mkv"),
        ("sim.right <literal>", "front & camera", "sources/sim.right/streams/front/segments/0001.mkv"),
        ("sim.right <literal>", "front & camera", "sources/sim.right/streams/front/segments/invalid.mkv")]
    actual = [(s.source_id, s.stream_id, s.relative_path) for s in view._segments]
    assert actual == expected, actual
    return {"segments": actual, "buttons": [b.text() for b in view.findChildren(QPushButton)], "state": state()}

def decode(index):
    view._choice.setCurrentIndex(index)
    wait(lambda: view._player is not None and view._ready, "original selected video ready")
    player = view._player
    assert player.playbackState() != QMediaPlayer.PlaybackState.PlayingState
    QTest.mouseClick(view._play, Qt.MouseButton.LeftButton)
    wait(lambda: player.position() >= 250 and view._video.videoSink().videoFrame().isValid(), "original actual decoded frame")
    QTest.mouseClick(view._play, Qt.MouseButton.LeftButton)
    wait(lambda: player.playbackState() == QMediaPlayer.PlaybackState.PausedState, "original explicit pause")
    frame = view._video.videoSink().videoFrame()
    image = frame.toImage().convertToFormat(QImage.Format.Format_ARGB32).copy()
    assert not image.isNull()
    measured = pixels(image)
    assert (measured["width"], measured["height"]) == (160, 120)
    segment = view._segments[index - 1]
    measured.update({"source_id": segment.source_id, "stream_id": segment.stream_id,
                     "path": segment.relative_path, "frame_pts_us": frame.startTime(),
                     "observed_position_ms": player.position(), "rotation": frame.rotation().name,
                     "mirrored": frame.mirrored(), "state": state()})
    assert image.save(str(OUT / ("decoded-" + str(index) + ".png")))
    return measured

def actual_decoding():
    rows = [decode(index) for index in (1, 2, 3)]
    channels = []
    for row in rows:
        rgb = row["center_rgba"][:3]
        winner = rgb.index(max(rgb))
        assert max(rgb) >= 120 and max(rgb) > sorted(rgb)[1] * 2
        channels.append(winner)
    assert sorted(channels) == [0, 1, 2], channels
    return {"segments": rows, "different_color_channels": channels}

def controls_and_identity():
    player = view._player
    assert player and player.playbackState() == QMediaPlayer.PlaybackState.PausedState
    view._seek.setValue(2000)
    QTest.qWait(60)
    QTest.mouseClick(view._mark_a, Qt.MouseButton.LeftButton)
    a = player.position()
    assert view._interval.start_ms == a
    view._seek.setValue(7000)
    QTest.qWait(60)
    QTest.mouseClick(view._mark_b, Qt.MouseButton.LeftButton)
    b = player.position()
    assert view._interval.end_ms == b and a < b
    QTest.mouseClick(view._repeat, Qt.MouseButton.LeftButton)
    view._rate.setCurrentIndex(1)
    QTest.qWait(30)
    assert player.playbackState() == QMediaPlayer.PlaybackState.PausedState
    assert view._interval.enabled and player.playbackRate() == 0.5
    configured = state()
    QTest.mouseClick(view._toggle, Qt.MouseButton.LeftButton)
    QTest.qWait(50)
    assert not view._body.isVisible() and not view._play_requested
    QTest.mouseClick(view._toggle, Qt.MouseButton.LeftButton)
    host.hide()
    QTest.qWait(30)
    host.show()
    QTest.qWait(30)
    assert view._interval.start_ms == a and view._interval.end_ms == b and view._interval.enabled
    assert player.playbackState() == QMediaPlayer.PlaybackState.PausedState
    view._play.setFocus()
    host.activateWindow()
    QTest.qWait(30)
    before_checkpoint = len(checkpoint)
    QTest.keyClick(view._play, Qt.Key.Key_Space)
    wait(lambda: player.playbackState() == QMediaPlayer.PlaybackState.PlayingState, "Space starts focused Play")
    QTest.keyClick(view._play, Qt.Key.Key_Space)
    wait(lambda: player.playbackState() == QMediaPlayer.PlaybackState.PausedState, "Space pauses focused Play")
    assert len(checkpoint) == before_checkpoint
    old_player, old_generation = view._player, view._generation
    QTest.mouseClick(view._reload, Qt.MouseButton.LeftButton)
    wait(lambda: view._ready, "original reload ready")
    assert view._player is not old_player and view._generation > old_generation
    assert view._interval.start_ms is None and not view._interval.enabled
    assert view._rate.currentData() == 1.0 and not view._play_requested
    before_stale = state()
    view._sync(old_player, old_generation)
    view._failed(old_player, old_generation, "stale original error")
    assert state() == before_stale
    view._choice.setCurrentIndex(4)
    wait(lambda: view._player is None and "Cannot play" in view._status.text(), "invalid MKV refusal")
    assert not view._play.isEnabled() and view._rate.currentData() == 1.0
    failure = state()
    view.load_package(str(fixture), state="recording")
    assert view._player is None and view._choice.count() == 1 and "finalized" in view._status.text()
    view.load_package(str(fixture), state="finalized_recovered")
    assert view._choice.count() == 5 and view._player is None
    return {"configured": configured, "reload": before_stale, "invalid_media": failure,
            "host_shortcut_interceptions": len(checkpoint), "old_callback_ignored": True}

def native_layout():
    rows = []
    for setting, size in (("dark", (900, 700)), ("light", (900, 700)), ("dark", (1280, 800))):
        theme.apply_theme(app, setting=setting)
        host.resize(*size)
        app.processEvents()
        controls = [view._choice, view._reload, view._play, view._seek, view._rate,
                    view._mark_a, view._mark_b, view._repeat, view._clear_interval]
        rows.append({"theme": setting, "requested_size": list(size), "actual_size": [host.width(), host.height()],
                     "controls": [{"name": w.accessibleName() or (w.text() if hasattr(w, "text") else type(w).__name__),
                                   "visible": w.isVisible(), "geometry": [w.x(), w.y(), w.width(), w.height()]}
                                  for w in controls]})
        assert all(w.isVisible() for w in controls)
        assert host.grab().save(str(OUT / ("original-" + setting + "-" + str(size[0]) + ".png")))
    return rows

try:
    observe("native_pixel_presentation_primitives", primitive)
    observe("original_inventory_and_missing_pair_controls", inventory)
    observe("actual_three_segment_decoding", actual_decoding)
    observe("original_controls_identity_and_failure", controls_and_identity)
    observe("original_native_layout", native_layout)
finally:
    view.reset()
    host.close()
    host.deleteLater()
    QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
    app.processEvents()
    after = pins()
    result["source_before"] = source_before
    result["source_after"] = after
    result["source_and_fixture_exact"] = source_before == after
    result["end"] = time.time()
    result["ok"] = all(g["ok"] for g in result["groups"]) and result["source_and_fixture_exact"]
    (OUT / "receipt.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"ok": result["ok"], "pid": os.getpid(), "groups": result["groups"],
                      "source_and_fixture_exact": result["source_and_fixture_exact"]}, ensure_ascii=False))
sys.exit(0 if result["ok"] else 1)
