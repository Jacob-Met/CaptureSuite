from __future__ import annotations
import gc,hashlib,json,os,sys,time,traceback
from pathlib import Path
ROOT=Path("D:/Hamon/receiving/capture-frame-pair-root-db371a37f4c8")
CANDIDATE=ROOT/"candidate-r1"
sys.dont_write_bytecode=True
for p in ("desktop","libs/python/capture_analysis","libs/python/capture_session","libs/python/capture_protocol"):
    sys.path.insert(0,str(CANDIDATE/p))
from PySide6.QtCore import QCoreApplication,QEvent,QPoint,Qt,qVersion
from PySide6.QtGui import QColor,QImage,QKeyEvent,QKeySequence,QShortcut
from PySide6.QtMultimedia import QMediaPlayer,QVideoFrame
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication,QScrollArea,QVBoxLayout,QWidget
import shiboken6
from capture_desktop import theme
from capture_desktop.review_video import media_time
from capture_desktop.screen_review import ReviewScreen
from capture_desktop.state import CaptureState
from capture_desktop.widgets_review_video import RecordedVideoReview
import capture_desktop.widgets_review_video as viewer_module
app=QApplication([])
assert app.platformName()=="windows" and qVersion()=="6.12.0"
OUT=ROOT/"candidate-ui-r2";OUT.mkdir(exist_ok=False)
fixed=json.loads((ROOT/"ORIGINAL-FREEZE-r2.json").read_text(encoding="utf-8"))
original_frames={i+1:v for i,v in enumerate(fixed["actualDecodedFrames"])}
fixture=CANDIDATE/"tests/fixtures/review_video"
report={"schema":"capture112-independent-native-ui-postexposure-correction-v2","start":time.time(),"pid":os.getpid(),"parent":os.getppid(),"platform":app.platformName(),"qt":qVersion(),"groups":[],"observations":{},"original_freeze":"ec83fad003ac5245529c0560b5c4e52dcdaf1b128b1edd8bf851f0b277c80b9f"}

correction=json.loads((ROOT/"INDEPENDENT-UI-CORRECTION-r2-FREEZE.json").read_text(encoding="utf-8"))
assert correction["candidate_exposed"] is True and correction["author_tests_outcomes_withheld"] is True
assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest()==correction["corrected_ui_script"]["sha256"]
report["correction_freeze"]=correction["at"]
report["correction_scope"]="One failed UI group only; current decoded native QImage before Keep replaces fixed 300ms pixels after seek. All six previous groups and model remain their original runs."

def wait(predicate,label,timeout=8000):
    end=time.monotonic()+timeout/1000
    while time.monotonic()<end:
        app.processEvents()
        if predicate():return
        QTest.qWait(15)
    raise AssertionError("Timed out: "+label)
def click(button):
    assert button.isEnabled() and button.isVisible(),(button.text(),button.isEnabled(),button.isVisible())
    QTest.mouseClick(button,Qt.MouseButton.LeftButton)
def ih(image):
    return hashlib.sha256(bytes(image.constBits())).hexdigest()
def frame_value(f):
    if f is None:return None
    return {"source":f.segment.source_id,"stream":f.segment.stream_id,"path":f.segment.relative_path,
            "pts_us":f.frame_start_us,"position_ms":f.player_position_ms,"decoded":[f.decoded_width,f.decoded_height],
            "rotation":f.rotation_degrees,"mirror":f.mirrored,"display":[f.image.width(),f.image.height()],
            "bytes":f.image.sizeInBytes(),"pixels":ih(f.image)}
def slots(s):
    return {k:frame_value(v) for k,v in s.dialog.frames.items()}
def playback(s):
    v=s.view;p=v._player
    return {"generation":v._generation,"selected":v._choice.currentIndex(),"ready":v._ready,
            "state":p.playbackState().name if p else None,"position":p.position() if p else None,
            "duration":p.duration() if p else None,"play_requested":v._play_requested,
            "requested_rate":v._rate.currentData(),"reported_rate":p.playbackRate() if p else None,
            "a":v._interval.start_ms,"b":v._interval.end_ms,"repeat":v._interval.enabled}
class Scene:
    def __init__(self,review=False):
        self.review=review
        self.host=ReviewScreen(CaptureState()) if review else QWidget()
        self.host.setObjectName("Root")
        self.host.setWindowTitle("CaptureSuite independent retained-frame receiving")
        if review:self.view=self.host._recorded_video
        else:
            self.view=RecordedVideoReview()
            layout=QVBoxLayout(self.host);layout.addWidget(self.view)
        self.dialog=self.view._comparison
        self.host.resize(900,700);theme.apply_theme(app,setting="dark")
        self.host.show();app.processEvents()
        self.view.load_package(str(fixture),state="finalized")
        self.view._toggle.setChecked(True);app.processEvents()
        self.host_shortcuts=[]
        self.shortcut=QShortcut(QKeySequence(Qt.Key.Key_Space),self.host)
        self.shortcut.activated.connect(lambda:self.host_shortcuts.append("host Space"))
    def __enter__(self):return self
    def __exit__(self,*args):
        if shiboken6.isValid(self.host):
            self.view.reset();self.host.close();self.host.deleteLater()
            QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete);app.processEvents()
        gc.collect()
    def open(self):
        if not self.dialog.isVisible():click(self.view._compare_frames)
        assert self.dialog.isVisible() and not self.dialog.isModal()
        assert self.dialog.parent() is self.view
    def decode(self,index):
        v=self.view
        if v._choice.currentIndex()==index:click(v._reload)
        else:v._choice.setCurrentIndex(index)
        wait(lambda:v._player is not None and v._ready,"ready "+str(index))
        p=v._player
        assert p.playbackState()!=QMediaPlayer.PlaybackState.PlayingState
        click(v._play)
        wait(lambda:p.position()>=250 and v._video.videoSink().videoFrame().isValid(),"decoded "+str(index))
        click(v._play)
        wait(lambda:p.playbackState()==QMediaPlayer.PlaybackState.PausedState,"paused "+str(index))
        QTest.qWait(40)
        return p
    def keep(self,slot,index):
        self.open();v=self.view;p=v._player
        before=playback(self)
        observed_native=v._video.videoSink().videoFrame()
        observed_pts=observed_native.startTime()
        assert observed_native.rotation().value==0 and not observed_native.mirrored()
        observed_image=observed_native.toImage().convertToFormat(QImage.Format.Format_ARGB32).copy()
        assert not observed_image.isNull()
        observed_pixels=ih(observed_image)
        assert observed_image.save(str(OUT/("decoded-before-keep-"+slot+".png")))
        other="B" if slot=="A" else "A";other_before=frame_value(self.dialog.frames[other])
        click(self.dialog._keep[slot])
        f=self.dialog.frames[slot];assert f is not None
        assert playback(self)==before
        assert frame_value(self.dialog.frames[other])==other_before
        expected=original_frames[index]
        assert ih(f.image)==observed_pixels
        report["observations"]["current_native_pixels_before_keep"]={"sha256":observed_pixels,"original_300ms_sha256":expected["sha256"],"frame_pts_us":observed_pts,"player_position_ms":before["position"],"different_from_300ms":observed_pixels!=expected["sha256"]}
        assert observed_pixels!=expected["sha256"]
        assert f.segment.source_id==expected["source_id"] and f.segment.stream_id==expected["stream_id"]
        assert f.segment.relative_path==expected["path"]
        assert f.frame_start_us==(observed_pts if observed_pts>=0 else None)
        assert f.player_position_ms==before["position"] and [f.decoded_width,f.decoded_height]==[160,120]
        text=self.dialog._metadata[slot].text()
        assert self.dialog._metadata[slot].textFormat()==Qt.TextFormat.PlainText
        for term in (f.segment.source_id,f.segment.stream_id,f.segment.relative_path,
                     "Decoded frame PTS: "+str(f.frame_start_us)+" µs",
                     "Player position when kept: "+media_time(f.player_position_ms),"160 × 120"):
            assert term in text,term
        return frame_value(f)
def group(name,fn):
    start=time.time()
    try:
        result=fn();report["groups"].append({"name":name,"ok":True,"seconds":time.time()-start})
        report["observations"][name]=result
    except Exception:report["groups"].append({"name":name,"ok":False,"seconds":time.time()-start,"traceback":traceback.format_exc()})
    (OUT/"progress.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
def admission_and_no_playback_side_effect():
    with Scene() as s:
        s.open();assert slots(s)=={"A":None,"B":None}
        before=playback(s);click(s.dialog._keep["A"])
        assert playback(s)==before and slots(s)=={"A":None,"B":None}
        assert "Frame not kept:" in s.dialog._notice.text()
        unready=s.dialog._notice.text()
        s.view._choice.setCurrentIndex(1)
        wait(lambda:s.view._ready,"stopped loaded segment")
        before=playback(s);click(s.dialog._keep["A"])
        assert playback(s)==before and slots(s)=={"A":None,"B":None}
        stopped=s.dialog._notice.text();assert "Pause" in stopped
        p=s.view._player;click(s.view._play)
        wait(lambda:p.position()>=250,"playing control")
        before=playback(s);click(s.dialog._keep["B"]);after=playback(s)
        assert after["state"]=="PlayingState" and after["play_requested"]
        assert {k:v for k,v in before.items() if k!="position"}=={k:v for k,v in after.items() if k!="position"}
        assert after["position"]>=before["position"] and slots(s)=={"A":None,"B":None}
        playing=s.dialog._notice.text();assert "Pause" in playing
        click(s.view._play);wait(lambda:p.playbackState()==QMediaPlayer.PlaybackState.PausedState,"pause")
        QTest.qWait(40)
        s.view._seek.setValue(2000);QTest.qWait(60);click(s.view._mark_a)
        s.view._seek.setValue(7000);QTest.qWait(60);click(s.view._mark_b)
        click(s.view._repeat);s.view._rate.setCurrentIndex(1);QTest.qWait(40)
        assert s.view._interval.enabled and p.playbackRate()==0.5
        kept=s.keep("A",1)
        return {"unready":unready,"stopped":stopped,"playing":playing,"kept":kept,"paused_config_exact":playback(s)}
def independent_replacement_clear():
    with Scene() as s:
        s.decode(1);a=s.keep("A",1);assert slots(s)["B"] is None
        before=slots(s);s.decode(3);assert slots(s)==before
        b=s.keep("B",3);pair=slots(s)
        s.decode(2);assert slots(s)==pair
        replacement=s.keep("A",2);assert slots(s)["B"]==b
        before=playback(s);click(s.dialog._clear["B"])
        assert slots(s)=={"A":replacement,"B":None} and playback(s)==before
        assert not s.dialog._clear["B"].isEnabled()
        click(s.dialog._clear["A"]);assert slots(s)=={"A":None,"B":None}
        assert not s.dialog._clear["A"].isEnabled()
        return {"original_A":a,"original_B":b,"replacement_A":replacement,"final":slots(s)}
def lifecycle():
    with Scene() as s:
        s.decode(1);s.keep("A",1);s.decode(3);s.keep("B",3)
        pair=slots(s);states=[]
        s.dialog.close();assert not s.dialog.isVisible() and slots(s)==pair
        s.open();assert slots(s)==pair
        QTest.keyClick(s.dialog,Qt.Key.Key_Escape);assert not s.dialog.isVisible() and slots(s)==pair
        s.open()
        click(s.view._toggle);QTest.qWait(30)
        assert not s.view._body.isVisible() and slots(s)==pair and not s.view._play_requested
        click(s.view._toggle);QTest.qWait(30)
        s.host.hide();QTest.qWait(30);assert slots(s)==pair
        s.host.show();QTest.qWait(30);s.open();assert slots(s)==pair
        click(s.view._reload);wait(lambda:s.view._ready,"reload with retained pair")
        assert slots(s)==pair and not s.view._play_requested
        states.append({"phase":"reload","slots":slots(s),"playback":playback(s)})
        s.view._choice.setCurrentIndex(4)
        wait(lambda:s.view._player is None and "Cannot play" in s.view._status.text(),"decoder refusal with pair")
        assert slots(s)==pair
        click(s.dialog._keep["A"]);assert slots(s)==pair and "Frame not kept" in s.dialog._notice.text()
        states.append({"phase":"failed_media","slots":slots(s),"notice":s.dialog._notice.text()})
        s.view.load_package(str(fixture),state="recording")
        assert slots(s)=={"A":None,"B":None}
        assert all(s.dialog._metadata[k].text()=="No frame retained." for k in ("A","B"))
        s.view.load_package(str(fixture),state="finalized_recovered")
        s.decode(2);s.keep("A",2);s.view.load_package(str(fixture),state="finalized")
        assert slots(s)=={"A":None,"B":None}
        states.append({"phase":"same_package_load_clears","slots":slots(s)})
        return states
def stale_and_atomic_refusal():
    with Scene() as s:
        s.decode(1);s.keep("A",1);s.decode(3);s.keep("B",3);pair=slots(s)
        old_player,old_video,old_generation=s.view._player,s.view._video,s.view._generation
        old_sink=old_video.videoSink()
        old_frame=old_sink.videoFrame()
        s.view._choice.setCurrentIndex(2)
        old_sink_alive=shiboken6.isValid(old_sink)
        if old_sink_alive:old_sink.videoFrameChanged.emit(old_frame)
        before=playback(s);s.view._sync(old_player,old_generation);s.view._failed(old_player,old_generation,"stale receiver injection")
        assert playback(s)==before and slots(s)==pair
        wait(lambda:s.view._ready,"new player after stale sink")
        click(s.view._play);wait(lambda:s.view._player.position()>=250,"new decoded frame")
        click(s.view._play);QTest.qWait(40)
        sink=s.view._video.videoSink();sink.setVideoFrame(QVideoFrame())
        assert not sink.videoFrame().isValid()
        before=playback(s);click(s.dialog._keep["A"])
        assert playback(s)==before and slots(s)==pair and "No decoded frame" in s.dialog._notice.text()
        invalid=s.dialog._notice.text()
        large=QImage(4097,4096,QImage.Format.Format_ARGB32);large.fill(QColor("blue"))
        native_large=QVideoFrame(large);assert native_large.isValid()
        sink.setVideoFrame(native_large);assert sink.videoFrame().width()==4097
        before=playback(s);click(s.dialog._keep["B"])
        assert playback(s)==before and slots(s)==pair and "16,777,216" in s.dialog._notice.text()
        oversize=s.dialog._notice.text()
        sink.setVideoFrame(QVideoFrame());del native_large,large;gc.collect()
        s.decode(2);assert slots(s)==pair
        original_helper=viewer_module.retain_video_frame
        def change_selection_after_copy(*args):
            copied=original_helper(*args)
            s.view._choice.setCurrentIndex(1)
            return copied
        viewer_module.retain_video_frame=change_selection_after_copy
        try:click(s.dialog._keep["A"])
        finally:viewer_module.retain_video_frame=original_helper
        assert slots(s)==pair and "selected video changed" in s.dialog._notice.text()
        changed=s.dialog._notice.text()
        return {"old_sink_still_live_at_direct_selection_boundary":old_sink_alive,"old_callbacks_ignored":True,
                "invalid_native_frame":invalid,"oversized_native_frame":oversize,
                "reentrant_actual_selection_injection":changed,"pair":pair}
def keyboard():
    with Scene() as s:
        s.decode(1);s.keep("A",1)
        intercepted=[]
        shortcut=QShortcut(QKeySequence(Qt.Key.Key_Space),s.dialog)
        shortcut.activated.connect(lambda:intercepted.append("panel Space"))
        s.dialog.activateWindow();s.dialog._keep["B"].setFocus();QTest.qWait(40)
        before=playback(s);QTest.keyClick(s.dialog._keep["B"],Qt.Key.Key_Space)
        assert s.dialog.frames["B"] is not None and slots(s)["A"] is not None
        assert playback(s)==before and not intercepted
        b=slots(s)["B"];s.dialog._clear["A"].setFocus()
        QTest.keyClick(s.dialog._clear["A"],Qt.Key.Key_Space)
        assert slots(s)=={"A":None,"B":b} and not intercepted
        routing=[]
        for modifiers in (Qt.KeyboardModifier.NoModifier,Qt.KeyboardModifier.ShiftModifier,Qt.KeyboardModifier.ControlModifier,Qt.KeyboardModifier.AltModifier):
            event=QKeyEvent(QEvent.Type.ShortcutOverride,Qt.Key.Key_Space,modifiers)
            handled=s.dialog.eventFilter(s.dialog._keep["B"],event)
            assert handled==(modifiers==Qt.KeyboardModifier.NoModifier)
            routing.append({"modifier":modifiers.value,"handled":handled})
        s.dialog.close();s.host.activateWindow();s.view._compare_frames.setFocus();QTest.qWait(40)
        QTest.keyClick(s.view._compare_frames,Qt.Key.Key_Space)
        assert s.dialog.isVisible() and not s.host_shortcuts
        return {"panel_shortcut":intercepted,"host_shortcut":s.host_shortcuts,"routing":routing,"after":slots(s)}
def screen_layout():
    with Scene(review=True) as s:
        s.decode(1);s.keep("A",1);s.decode(3);s.keep("B",3);pair=slots(s);rows=[]
        controls=[s.view._choice,s.view._reload,s.view._play,s.view._seek,s.view._rate,
                  s.view._mark_a,s.view._mark_b,s.view._repeat,s.view._clear_interval,s.view._compare_frames,s.host._btn_export]
        for mode,size in (("dark",(900,700)),("light",(900,700)),("dark",(1280,800)),("light",(1280,800))):
            theme.apply_theme(app,setting=mode);s.host.resize(*size);s.dialog.resize(840 if size[0]==900 else 1000,540 if size[0]==900 else 640)
            app.processEvents();QTest.qWait(40)
            host_size=[s.host.width(),s.host.height()]
            s.dialog.hide();app.processEvents();hidden_size=[s.host.width(),s.host.height()]
            s.open();app.processEvents();assert [s.host.width(),s.host.height()]==hidden_size==host_size
            assert slots(s)==pair
            control_rows=[]
            for w in controls:
                point=w.mapTo(s.host,QPoint(0,0))
                assert w.isVisible()
                assert 0<=point.x() and 0<=point.y() and point.x()+w.width()<=s.host.width()+1 and point.y()+w.height()<=s.host.height()+1
                control_rows.append({"name":w.accessibleName() or (w.text() if hasattr(w,"text") else type(w).__name__),
                                     "rect":[point.x(),point.y(),w.width(),w.height()]})
            canvas_rows=[]
            for slot,index in (("A",1),("B",3)):
                canvas=s.dialog._canvases[slot];image=canvas.grab().toImage()
                color=original_frames[index]["center_rgba"][:3]
                def match(x,y):
                    actual=image.pixelColor(x,y).getRgb()[:3]
                    return all(abs(a-b)<=2 for a,b in zip(actual,color))
                xs=[x for x in range(image.width()) if match(x,image.height()//2)]
                ys=[y for y in range(image.height()) if match(image.width()//2,y)]
                assert xs and ys
                width=xs[-1]-xs[0]+1;height=ys[-1]-ys[0]+1
                assert abs(width*120-height*160)<=320,(width,height)
                assert s.dialog._metadata[slot].isVisible() and s.dialog._keep[slot].isVisible() and s.dialog._clear[slot].isVisible()
                canvas_rows.append({"slot":slot,"canvas":[image.width(),image.height()],"painted":[width,height],"aspect_error_cross_product":width*120-height*160})
            name=mode+"-"+str(size[0])
            assert s.host.grab().save(str(OUT/("review-"+name+".png")))
            assert s.dialog.grab().save(str(OUT/("comparison-"+name+".png")))
            rows.append({"theme":mode,"requested":list(size),"actual_review":host_size,
                         "actual_comparison":[s.dialog.width(),s.dialog.height()],"controls":control_rows,"canvas":canvas_rows,
                         "opening_comparison_preserves_review_geometry":True})
        return rows
def package_failure_and_destroy():
    with Scene(review=True) as s:
        s.decode(1);s.keep("A",1);s.decode(3);s.keep("B",3)
        s.host.load_package(str(ROOT/"missing-package-for-original-ReviewScreen-path"))
        assert slots(s)=={"A":None,"B":None}
        assert "Could not load package" in s.host._banner.text()
        failed=s.host._banner.text()
        s.view.load_package(str(fixture),state="finalized")
        s.decode(1);s.keep("A",1);s.decode(3);s.keep("B",3)
        frames=s.dialog.frames;canvases=dict(s.dialog._canvases)
        dialog,player,video=s.dialog,s.view._player,s.view._video
        s.host.deleteLater();QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete);app.processEvents()
        assert not shiboken6.isValid(dialog) and not shiboken6.isValid(player) and not shiboken6.isValid(video)
        assert frames=={"A":None,"B":None} and all(c.frame is None for c in canvases.values())
        return {"failed_package":failed,"destroyed_native_dialog_player_video":True,"held_python_frames_released":True}
group("actual_refusal_pause_and_playback_preservation",admission_and_no_playback_side_effect)
# Previously passed in R1; intentionally not rerun: group("native_keep_replace_clear_independence",independent_replacement_clear)
# Previously passed in R1; intentionally not rerun: group("panel_visibility_segment_failure_and_package_lifecycle",lifecycle)
# Previously passed in R1; intentionally not rerun: group("old_identity_invalid_oversize_and_reentrant_selection",stale_and_atomic_refusal)
# Previously passed in R1; intentionally not rerun: group("actual_Space_activation_and_modifier_filter_scope",keyboard)
# Previously passed in R1; intentionally not rerun: group("actual_ReviewScreen_compact_dark_light_and_image_aspect",screen_layout)
# Previously passed in R1; intentionally not rerun: group("actual_ReviewScreen_failed_admission_and_native_destruction",package_failure_and_destroy)
report["files"]=[]
for e in json.loads((ROOT/"CANDIDATE-ADMISSION-r1.json").read_text(encoding="utf-8"))["files"]:
    p=CANDIDATE/e["path"];sha=hashlib.sha256(p.read_bytes()).hexdigest()
    assert sha==e["sha256"] and p.stat().st_mtime_ns==int(e["mtimeNs"])
    report["files"].append({"path":e["path"],"sha256":sha,"mtime_exact":True})
report["native_visible_windows"]=[w.windowTitle() for w in app.topLevelWidgets() if w.isVisible()]
assert report["native_visible_windows"]==[]
report["end"]=time.time();report["ok"]=all(g["ok"] for g in report["groups"])
(OUT/"receipt.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"ok":report["ok"],"pid":os.getpid(),"groups":report["groups"],"visible_windows":report["native_visible_windows"]},ensure_ascii=False))
sys.exit(0 if report["ok"] else 1)
