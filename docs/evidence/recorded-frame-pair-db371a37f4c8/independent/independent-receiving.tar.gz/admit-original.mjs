import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const root='D:/Hamon/receiving/capture-frame-pair-root-db371a37f4c8';
const packet=JSON.parse(fs.readFileSync(root+'/ORIGINAL-ADMISSION-PACKET.json','utf8'));
const start=new Date().toISOString();
function sums(p){const fd=fs.openSync(p,'r'); const size=fs.fstatSync(fd).size;const h=crypto.createHash('sha256'),g=crypto.createHash('sha1');g.update('blob '+size+'\0');const buffer=Buffer.allocUnsafe(65536);let n;try{while((n=fs.readSync(fd,buffer,0,buffer.length,null))!==0){h.update(buffer.subarray(0,n));g.update(buffer.subarray(0,n));}}finally{fs.closeSync(fd);}return {bytes:size,sha256:h.digest('hex'),git:g.digest('hex')};}
function safe(p){assert(!path.isAbsolute(p)&&!p.split(/[\\/]/).includes('..'));return p;}
const suppliedManifest=sums(packet.offer.source_manifest.path);assert.equal(suppliedManifest.sha256,packet.offer.source_manifest.sha256);
assert.equal(packet.manifest.length,132);assert.equal(packet.manifest.reduce((s,e)=>s+e.bytes,0),757632);
const supplied=JSON.parse(fs.readFileSync(packet.offer.source_manifest.path,'utf8').replace(/^\uFEFF/,''));assert.deepEqual(supplied,packet.manifest);
const leaves=new Map(packet.source_tree.tree.filter(e=>e.type!=='tree').map(e=>[e.path,e]));
assert.equal(packet.source_tree.truncated,false);assert.equal(packet.source_tree.sha,packet.offer.source_tree);
const source=[];
for(const e of packet.manifest){safe(e.path);const t=leaves.get(e.path);assert(t&&t.type==='blob'&&t.sha===e.git&&t.size===e.bytes,e.path+' canonical tree');const from=packet.offer.source_root+'/'+e.path;const before=sums(from);assert.equal(before.bytes,e.bytes);assert.equal(before.sha256,e.sha256);assert.equal(before.git,e.git);const dest=root+'/original/'+e.path;fs.mkdirSync(path.dirname(dest),{recursive:true});fs.copyFileSync(from,dest,fs.constants.COPYFILE_EXCL);assert.deepEqual(sums(dest),before);source.push({...e,donor:from,receiver:dest,mode:t.mode,mtimeNs:String(fs.statSync(from,{bigint:true}).mtimeNs)});}
const rm=sums(packet.offer.runtime.manifest);assert.equal(rm.sha256,packet.offer.runtime.manifest_sha256);
const runtime=JSON.parse(fs.readFileSync(packet.offer.runtime.manifest,'utf8').replace(/^\uFEFF/,''));assert.equal(runtime.files.length,18539);assert.equal(runtime.files.reduce((s,e)=>s+e.bytes,0),1171247985);
const runtimeChecked=[];
for(const e of runtime.files){safe(e.path);const p=runtime.root+'/'+e.path;const s=sums(p);assert.equal(s.bytes,e.bytes,p+' size');assert.equal(s.sha256,e.sha256,p+' sha');runtimeChecked.push({path:e.path,...s,mtimeNs:String(fs.statSync(p,{bigint:true}).mtimeNs)});}
const expected=new Set(runtime.files.map(e=>e.path.replaceAll('\\','/')));
const actual=[];function walk(p,prefix){for(const e of fs.readdirSync(p,{withFileTypes:true})){const rel=prefix+'/'+e.name;if(e.isDirectory())walk(p+'/'+e.name,rel);else if(e.isFile())actual.push(rel);else throw Error('Unadmitted runtime link '+rel);}}
walk(runtime.root+'/venv','venv');actual.sort();assert.equal(actual.length,expected.size);assert(actual.every(p=>expected.has(p)));
const receipt={schema:'capture112-root-original-admission-v1',start,end:new Date().toISOString(),pid:process.pid,parent:process.ppid,node:process.version,sourceBase:packet.offer.source_base,tree:packet.offer.source_tree,treeLeafCount:leaves.size,source,sourceBytes:source.reduce((s,e)=>s+e.bytes,0),runtimeManifest:rm,runtimeRoot:runtime.root,runtimeCount:runtimeChecked.length,runtimeBytes:runtimeChecked.reduce((s,e)=>s+e.bytes,0),runtimeInventoryExact:true,runtime:runtimeChecked,candidateExposure:false};
fs.writeFileSync(root+'/ORIGINAL-ADMISSION.json',JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({ok:true,pid:process.pid,source:source.length,runtime:runtimeChecked.length,receipt:sums(root+'/ORIGINAL-ADMISSION.json')}));
