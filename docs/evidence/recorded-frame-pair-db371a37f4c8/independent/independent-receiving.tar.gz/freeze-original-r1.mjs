import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import cp from 'node:child_process';import assert from 'node:assert/strict';
const root='D:/Hamon/receiving/capture-frame-pair-root-db371a37f4c8';
const json=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));
const hash=p=>{const b=fs.readFileSync(p);return {bytes:b.length,sha256:crypto.createHash('sha256').update(b).digest('hex'),git:crypto.createHash('sha1').update('blob '+b.length+'\0').update(b).digest('hex')};};
const r1=json(root+'/original-native-r1/receipt.json'),r2=json(root+'/original-native-r2/receipt.json'),admission=json(root+'/ORIGINAL-ADMISSION-r4.json');
assert.deepEqual(r1.groups.filter(g=>g.ok).map(g=>g.name),['original_inventory_and_missing_pair_controls','original_controls_identity_and_failure','original_native_layout']);
assert.equal(r1.groups.filter(g=>!g.ok).length,2);assert.equal(r1.ok,false);assert.equal(r2.ok,true);assert.equal(r2.groups.length,2);assert(r1.source_and_fixture_exact&&r2.source_and_fixture_exact);assert.equal(json(root+'/ORIGINAL-NATIVE-r2-EXIT.json').exitCode,0);
for(const e of admission.sourceFiles){const got=hash(root+'/original/'+e.path);assert.equal(got.sha256,e.sha256);assert.equal(got.git,e.git);}
const ps=cp.execFileSync('powershell.exe',['-NoProfile','-Command','Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CreationDate,CommandLine | ConvertTo-Json -Depth 5 -Compress'],{encoding:'utf8'});
const processes=JSON.parse(ps),byId=new Map(processes.map(p=>[p.ProcessId,p]));const ancestors=new Set();let p=byId.get(process.pid);while(p&&!ancestors.has(p.ProcessId)){ancestors.add(p.ProcessId);p=byId.get(p.ParentProcessId);}
const actualOwn=processes.filter(p=>String(p.CommandLine||'').replaceAll('\\','/').includes(root)&&!ancestors.has(p.ProcessId)&&p.ParentProcessId!==process.pid);
assert.equal(actualOwn.length,0,JSON.stringify(actualOwn.map(p=>({pid:p.ProcessId,name:p.Name}))));
const known=[21756,10580,28560,2824,27440,17844,10144,29264,6396,22684,9396,6356,11464,21204,27232,25424,24580,15940,16464,18248,14820,16992,25864,20720,21620,25428];
const census=known.map(pid=>{const p=byId.get(pid);return p?{pid,present:true,name:p.Name,path:p.ExecutablePath,creation:p.CreationDate,owned:String(p.CommandLine||'').replaceAll('\\','/').includes(root)}:{pid,present:false};});assert(census.every(p=>!p.owned));
const runtime=json(root+'/ORIGINAL-ADMISSION-PACKET.json').offer.runtime;
const rm=json(runtime.manifest);const ledger=fs.readFileSync(root+'/RUNTIME-HASH-LEDGER-r2.jsonl','utf8').trimEnd().split('\n').map(x=>JSON.parse(x));
for(const e of ledger){const st=fs.statSync(rm.root+'/'+e.path,{bigint:true});assert.equal(Number(st.size),e.bytes);assert.equal(String(st.mtimeNs),e.mtimeNs);}
const alias=admission.runtimeLinks[0];assert.equal(fs.readlinkSync(rm.root+'/'+alias.path),alias.rawTarget);assert.equal(fs.realpathSync(rm.root+'/'+alias.path),alias.resolved);
const correction={schema:'capture112-native-original-receiver-corrections-v1',at:new Date().toISOString(),beforeCandidate:true,originalR1:hash(root+'/original-native-r1/receipt.json'),originalR2:hash(root+'/original-native-r2/receipt.json'),notes:[
'The exact offered second MKV is yellow. R1 expected red/blue/green based on the public qualification description and failed its color-family assertion. Root inspected all three native PNGs and froze red/yellow/green before candidate. No fixture was altered.',
'Native QVideoFrame.paint interpolates a rotated tiny 3x2 raster. The unchanged hand orientation matrices and exact QImage transform check were retained; R2 tested the same native frame presentation with 60px color blocks at their interiors, avoiding interpolation boundaries. All eight angle/mirror cases passed.',
'R1 positive inventory, playback/interval/rate/identity/keyboard/lifecycle and compact layout groups were preserved, not rerun as candidate evidence. R2 repeated only initialization and the two affected groups.',
'The original observers use QApplication platform windows, actual FFV1 multimedia decoding and viewer-host QShortcut; they do not claim a complete MainWindow run or GPU video screenshot equivalence.',
'All 132 source/fixture files remained exact, including mtimes. The original runtime manifest has18539 logical paths over15230 physical regular paths and3309 alias paths; the alias remains unchanged and inside the offered canonical closure.'
]};
fs.writeFileSync(root+'/ORIGINAL-CORRECTIONS-PRE-CANDIDATE.json',JSON.stringify(correction,null,2)+'\n',{flag:'wx'});
const files=[];function walk(dir,prefix=''){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const rel=prefix?prefix+'/'+e.name:e.name;if(e.isDirectory()){if(rel==='original')continue;walk(dir+'/'+e.name,rel);}else if(e.isFile()&&!/freeze-original-r1/.test(rel)&&rel!=='ORIGINAL-FREEZE.json')files.push({path:rel,...hash(dir+'/'+e.name)});}}
walk(root);files.sort((a,b)=>a.path.localeCompare(b.path));
const result={schema:'capture112-independent-original-freeze-v1',at:new Date().toISOString(),pid:process.pid,parent:process.ppid,candidateExposed:false,originalBase:admission.sourceBase,originalTree:admission.sourceTree,sourceFiles:132,originalAdmission:hash(root+'/ORIGINAL-ADMISSION-r4.json'),nativeOriginalFirst:r1.groups,nativeOriginalCorrection:r2.groups,handPlan:hash(root+'/INDEPENDENT-PLAN-PRE-CANDIDATE.md'),actualDecodedFrames:r2.observations.decoded_frames,presentation:r2.observations.native_pixel_presentation_primitives,correction:hash(root+'/ORIGINAL-CORRECTIONS-PRE-CANDIDATE.json'),census,ownedProcesses:[],runtimeLogicalPaths:18539,runtimePhysicalRegularPaths:15230,runtimeAliasPaths:3309,runtimeSizesMtimesAndAliasUnchanged:true,files};
fs.writeFileSync(root+'/ORIGINAL-FREEZE.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({ok:true,at:result.at,pid:process.pid,files:files.length,census,freeze:hash(root+'/ORIGINAL-FREEZE.json')}));
