import fs from 'node:fs';import crypto from 'node:crypto';
const root="D:/Hamon/receiving/capture-frame-pair-root-db371a37f4c8";
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const read=p=>fs.readFileSync(root+'/'+p);
const json=p=>JSON.parse(read(p).toString('utf8').replace(/^\uFEFF/,''));
const pin=p=>{const b=read(p),s=fs.statSync(root+'/'+p,{bigint:true});return {path:p,bytes:b.length,sha256:hash(b),mtimeNs:String(s.mtimeNs)};};
const ui=json('candidate-ui-r1/receipt.json'), control=json('original-postexposure-seek-r1/receipt.json');
if(ui.groups.length!==7||ui.groups.filter(g=>g.ok).length!==6||ui.groups.filter(g=>!g.ok)[0].name!=='actual_refusal_pause_and_playback_preservation')throw Error('Wrong historical UI result');
if(!control.ok||!control.source_and_fixture_exact||json('ORIGINAL-POSTEXPOSURE-SEEK-r1-EXIT.json').exitCode!==0)throw Error('Original control not closed');
const observation=control.observations.original_native_seek_and_current_decoded_pixels;
if(observation.hash_equal!==false||observation.after_native_seek_rate_repeat.sha256!=='053eb3e75029fd03c6a3d3b27d2f9e1edf00576666f8cc95b102750f206430c3')throw Error('Original pixel evidence differs');
const original=json('ORIGINAL-FREEZE-r2.json');
const admission=json('CANDIDATE-ADMISSION-r1.json');
for(const e of admission.files){const p=root+'/candidate-r1/'+e.path,b=fs.readFileSync(p),s=fs.statSync(p,{bigint:true});if(hash(b)!==e.sha256||String(s.mtimeNs)!==String(e.mtimeNs))throw Error('Candidate changed '+e.path);}
const priorPaths=['candidate-ui-r1.py','candidate-ui-r1/receipt.json','CANDIDATE-UI-r1-EXIT.json','original-postexposure-seek-r1.py','original-postexposure-seek-r1/receipt.json','ORIGINAL-POSTEXPOSURE-SEEK-r1-EXIT.json','original-postexposure-seek-r1/original-after-seek.png','INDEPENDENT-UI-CORRECTION-POSTEXPOSURE-r2.md'];
const result={schema:'capture112-independent-postexposure-ui-correction-freeze-v1',at:new Date().toISOString(),pid:process.pid,parent:process.ppid,candidate_exposed:true,author_tests_outcomes_withheld:true,scope:'Only the one failed UI group; six successful groups and four model groups are not rerun',historical_ui_groups:ui.groups,original_control:observation,original_control_source_exact:true,original_precandidate_freeze_sha256:hash(read('ORIGINAL-FREEZE-r2.json')),candidate_source_files_exact:admission.files.length,prior_artifacts:priorPaths.map(pin),corrected_ui_script:pin('candidate-ui-r2.py')};
fs.writeFileSync(root+'/INDEPENDENT-UI-CORRECTION-r2-FREEZE.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({ok:true,at:result.at,pid:process.pid,files:admission.files.length,freeze:pin('INDEPENDENT-UI-CORRECTION-r2-FREEZE.json')}));
