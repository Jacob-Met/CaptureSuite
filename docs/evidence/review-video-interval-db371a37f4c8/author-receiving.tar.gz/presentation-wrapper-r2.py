import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
BASE=Path(r"D:/Hamon/worktrees/capture-video-repeat-db371a37f4c8-production");ROOT=BASE/"candidate-r1";OUT=BASE/"presentation-wrapper-r2";OUT.mkdir(exist_ok=False)
def pins():return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(ROOT.rglob("*")) if p.is_file()}
guard=json.loads(subprocess.check_output(["powershell","-NoProfile","-Command","$o=Get-CimInstance Win32_OperatingSystem; @{free_memory_bytes=[int64]$o.FreePhysicalMemory*1024}|ConvertTo-Json -Compress"],text=True));guard["disk_free"]=shutil.disk_usage(BASE).free
assert guard["free_memory_bytes"]>=2*1024**3 and guard["disk_free"]>=512*1024**2,guard
before=pins();env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE="1",PYTHONUTF8="1",TEMP=str(BASE/"tmp"),TMP=str(BASE/"tmp"))
argv=[str(BASE/"venv/Scripts/python.exe"),"-B","-u",str(BASE/"presentation-r2.py")]
with (OUT/"stdout.txt").open("wb") as a,(OUT/"stderr.txt").open("wb") as b:
 p=subprocess.Popen(argv,cwd=BASE,env=env,stdout=a,stderr=b)
 (OUT/"started.json").write_text(json.dumps({"pid":os.getpid(),"child":p.pid,"argv":argv,"guard":guard,"at":time.time()})+"\n",encoding="utf-8")
 timed=False
 try:code=p.wait(timeout=60)
 except subprocess.TimeoutExpired:timed=True;p.terminate();code=p.wait(timeout=10)
after=pins();receipt={"finished":time.time(),"wrapper":os.getpid(),"child":p.pid,"code":code,"timed_out":timed,"source_exact":before==after,"before":before,"after":after}
(OUT/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8",newline="\n")
print(json.dumps({"code":code,"source_exact":before==after,"child":p.pid,"wrapper":os.getpid(),"sha256":hashlib.sha256((OUT/"receipt.json").read_bytes()).hexdigest()}),flush=True)
raise SystemExit(code)
