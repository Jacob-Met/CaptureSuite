import hashlib,json,os,sys,time,traceback
from pathlib import Path
BASE=Path(r"D:/Hamon/worktrees/capture-video-repeat-db371a37f4c8-production");ROOT=BASE/"candidate-r1";OUT=BASE/"presentation-r2";OUT.mkdir(exist_ok=False)
os.environ.update(QT_QPA_PLATFORM="offscreen",PYTHONDONTWRITEBYTECODE="1",MPLCONFIGDIR=str(OUT/"mpl"))
for key in ["LOCALAPPDATA","APPDATA","XDG_CONFIG_HOME","XDG_DATA_HOME","XDG_CACHE_HOME"]:
 folder=OUT/key.lower();folder.mkdir();os.environ[key]=str(folder)
for rel in ["desktop","libs/python/capture_analysis","libs/python/capture_session","libs/python/capture_protocol"]:sys.path.insert(0,str(ROOT/rel))
from PySide6.QtCore import QCoreApplication,QEvent,Qt
from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QFontDatabase
from PySide6.QtMultimedia import QMediaPlayer
from PySide6.QtTest import QTest
from capture_desktop import theme
from capture_desktop.widgets_review_video import RecordedVideoReview
app=QApplication([]);video=None
receipt={"started":time.time(),"pid":os.getpid(),"scope":"Native Windows Qt offscreen QWidget controls plus actual decoded QVideoSink pixels. QWidget captures do not claim GPU/onscreen video or physical input.","captures":[]}
def wait(predicate):
 end=time.monotonic()+12
 while time.monotonic()<end:
  app.processEvents()
  if predicate():return
  QTest.qWait(10)
 raise AssertionError("native presentation readiness")
try:
 fonts=[]
 for name in ["segoeui.ttf","segoeuib.ttf"]:
  path=Path("C:/Windows/Fonts")/name
  assert path.is_file()
  handle=QFontDatabase.addApplicationFont(str(path));assert handle>=0
  fonts.append({"path":str(path),"sha256":hashlib.sha256(path.read_bytes()).hexdigest(),"families":QFontDatabase.applicationFontFamilies(handle)})
 receipt["fonts_loaded_only_in_receiving_application"]=fonts
 receipt["adaptation"]="Canonical #89 presentation route: read-only registration of existing OS fonts; explicit native Play/decode/Pause before paused inspection. No OS/font/product modification."
 theme.apply_theme(app,setting="dark")
 video=RecordedVideoReview();video.resize(1060,720);video.show();video._toggle.setChecked(True)
 video.load_package(str(ROOT/"tests/fixtures/review_video"),state="finalized");video._choice.setCurrentIndex(1)
 wait(lambda:video._ready)
 p=video._player
 QTest.mouseClick(video._play,Qt.MouseButton.LeftButton)
 wait(lambda:p.videoSink().videoFrame().isValid() and p.position()>=100)
 QTest.mouseClick(video._play,Qt.MouseButton.LeftButton)
 wait(lambda:p.playbackState()==QMediaPlayer.PlaybackState.PausedState)
 video._seek.setValue(2000);wait(lambda:p.position()==400);QTest.mouseClick(video._mark_a,Qt.MouseButton.LeftButton)
 video._seek.setValue(6000);wait(lambda:p.position()==1200);QTest.mouseClick(video._mark_b,Qt.MouseButton.LeftButton)
 QTest.mouseClick(video._repeat,Qt.MouseButton.LeftButton);video._rate.setCurrentIndex(1)
 video._seek.setValue(4250);wait(lambda:p.position()==850)
 assert p.playbackState()!=QMediaPlayer.PlaybackState.PlayingState
 for name,mode,width,height in [("dark","dark",1060,720),("compact","dark",720,620),("light","light",1060,720)]:
  theme.apply_theme(app,setting=mode);video.resize(width,height);app.processEvents();QTest.qWait(80)
  controls=[video._choice,video._play,video._seek,video._rate,video._mark_a,video._mark_b,video._repeat,video._clear_interval,video._interval_label,video._rate_label,video._interval_help]
  geometry=[]
  for c in controls:
   rect=c.rect();top=c.mapTo(video,rect.topLeft());bottom=c.mapTo(video,rect.bottomRight())
   assert video.rect().contains(top) and video.rect().contains(bottom),(name,c.objectName(),top,bottom,video.size())
   geometry.append({"class":type(c).__name__,"text":c.text() if hasattr(c,"text") else c.currentText() if hasattr(c,"currentText") else "seek","x":top.x(),"y":top.y(),"w":rect.width(),"h":rect.height()})
  path=OUT/(name+".png");assert video.grab().save(str(path))
  receipt["captures"].append({"name":name,"requested":[width,height],"actual":[video.width(),video.height()],"sha256":hashlib.sha256(path.read_bytes()).hexdigest(),"bytes":path.stat().st_size,"controls":geometry})
 assert "\u00d7" in video._rate_label.text() and "\u2013" in video._repeat.text()
 frame=p.videoSink().videoFrame()
 wait(lambda:p.videoSink().videoFrame().isValid())
 image=p.videoSink().videoFrame().toImage();assert not image.isNull()
 assert image.save(str(OUT/"decoded-frame.png"))
 receipt["decoded"]={"width":image.width(),"height":image.height(),"center_rgba":image.pixelColor(image.width()//2,image.height()//2).getRgb()}
 receipt["outcome"]="pass"
except Exception:
 receipt.update(outcome="fail",traceback=traceback.format_exc())
 if video is not None:video.grab().save(str(OUT/"failure.png"))
finally:
 if video is not None:
  video.reset();video.close();video.deleteLater();QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete);app.processEvents()
 receipt["finished"]=time.time();(OUT/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8",newline="\n")
 print(json.dumps({"outcome":receipt["outcome"],"error":receipt.get("traceback"),"receipt_sha256":hashlib.sha256((OUT/"receipt.json").read_bytes()).hexdigest()}),flush=True)
raise SystemExit(0 if receipt["outcome"]=="pass" else 1)
