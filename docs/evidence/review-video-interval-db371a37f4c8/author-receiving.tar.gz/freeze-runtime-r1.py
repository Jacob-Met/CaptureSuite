import ctypes,hashlib,json,os,subprocess,time
from pathlib import Path
BASE=Path(r"D:/Hamon/worktrees/capture-video-repeat-db371a37f4c8-production")
OUT=BASE/"environment-final-r1";assert not OUT.exists();OUT.mkdir()
def pin(p,root):
 h=hashlib.sha256()
 with p.open("rb") as f:
  while b:=f.read(1024*1024):h.update(b)
 return {"path":p.relative_to(root).as_posix(),"bytes":p.stat().st_size,"sha256":h.hexdigest()}
first=json.loads((BASE/"environment-deps-r1/receipt.json").read_text());assert first["outcome"]=="pass"
selected=json.loads((BASE/"environment-deps-r1/installed-files.json").read_text())
for f in selected:
 p=Path(f["path"]);actual=pin(p,BASE);assert actual["bytes"]==f["bytes"] and actual["sha256"]==f["sha256"]
files=[];links=[]
for name in ["venv","python"]:
 for p in sorted((BASE/name).rglob("*")):
  if p.is_symlink():links.append({"path":p.relative_to(BASE).as_posix(),"target":str(p.readlink())})
  elif p.is_file():files.append(pin(p,BASE))
manifest={"schema":"capture-repeat-full-runtime-r1","root":str(BASE),"files":files,"links":links,"scope":"Complete private managed CPython and private venv; excludes cache, bootstrap tool, source and receipts."}
(OUT/"runtime-files.json").write_text(json.dumps(manifest,indent=2)+"\n",encoding="utf-8")
result=subprocess.run(["py","-0p"],capture_output=True,timeout=10)
(OUT/"registered-python.stdout").write_bytes(result.stdout);(OUT/"registered-python.stderr").write_bytes(result.stderr)
census=subprocess.run(["powershell","-NoProfile","-Command","Get-CimInstance Win32_Process | Where-Object { $_.ProcessId -in @(22596,10488,14580,26908,18404) } | Select-Object ProcessId,Name | ConvertTo-Json"],capture_output=True,timeout=15)
(OUT/"prior-process-census.txt").write_bytes(census.stdout)
assert census.returncode==0 and not census.stdout.strip(),census.stdout
receipt={"at":time.time(),"runtime_manifest":pin(OUT/"runtime-files.json",BASE),"files":len(files),"bytes":sum(f["bytes"] for f in files),"links":links,"initial_venv_manifest_exact":True,"prior_owned_processes_absent":[22596,10488,14580,26908,18404],"registered_python_stdout":result.stdout.decode(errors="replace"),"registered_python_stderr":result.stderr.decode(errors="replace"),"python":str(BASE/"venv/Scripts/python.exe"),"outcome":"pass"}
(OUT/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
print(json.dumps(receipt),flush=True)
