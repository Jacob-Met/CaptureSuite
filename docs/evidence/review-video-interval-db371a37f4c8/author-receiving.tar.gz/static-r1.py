import hashlib,json,os,subprocess,time,runpy
from pathlib import Path
BASE=Path(r"D:/Hamon/worktrees/capture-video-repeat-db371a37f4c8-production");ROOT=BASE/"candidate-r1";OUT=BASE/"static-r1";OUT.mkdir(exist_ok=False)
PY=BASE/"venv/Scripts/python.exe"
files=["desktop/capture_desktop/widgets_review_video.py","desktop/capture_desktop/review_video_interval.py","tests/test_review_video_interval.py","tests/ui/test_review_video_interval.py"]
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE="1",PYTHONUTF8="1",TEMP=str(BASE/"tmp"),TMP=str(BASE/"tmp"),RUFF_CACHE_DIR=str(OUT/"ruff-cache"))
receipt={"started":time.time(),"pid":os.getpid(),"commands":[]}
def run(label,args):
 with (OUT/(label+".stdout")).open("wb") as a,(OUT/(label+".stderr")).open("wb") as b:
  p=subprocess.Popen([str(PY),*args],cwd=ROOT,env=env,stdout=a,stderr=b)
  try:code=p.wait(timeout=60)
  except subprocess.TimeoutExpired:p.terminate();code=p.wait(timeout=10)
 entry={"label":label,"argv":[str(PY),*args],"pid":p.pid,"code":code};receipt["commands"].append(entry);print(json.dumps(entry),flush=True)
 return code
run("first-lint",["-m","ruff","check",*files])
assert run("format",["-m","ruff","format",*files])==0
assert run("imports",["-m","ruff","check","--select","I","--fix",*files])==0
code=run("final-lint",["-m","ruff","check",*files])
model=run("models",["-B","-m","pytest","-p","no:cacheprovider","--basetemp",str(OUT/"pytest-tmp"),"--junitxml",str(OUT/"models.xml"),"-q","tests/test_review_video_model.py","tests/test_review_video_interval.py"])
module=runpy.run_path(str(ROOT/"tools/check_licenses.py"))
license_checks={r:module["_expected_spdx"](ROOT/r) in "\n".join((ROOT/r).read_text().splitlines()[:40]) for r in files}
receipt.update(finished=time.time(),scope="Scoped four-file Ruff and exact existing license-policy SPDX check; not repository-wide license topology.",license_checks=license_checks,files=[{"path":r,"sha256":hashlib.sha256((ROOT/r).read_bytes()).hexdigest(),"bytes":(ROOT/r).stat().st_size} for r in files],passed=code==0 and model==0 and all(license_checks.values()))
(OUT/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8",newline="\n")
print(json.dumps(receipt),flush=True)
raise SystemExit(0 if receipt["passed"] else 1)
