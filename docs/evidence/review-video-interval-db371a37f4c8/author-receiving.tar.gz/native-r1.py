import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
BASE=Path(r"D:/Hamon/worktrees/capture-video-repeat-db371a37f4c8-production");ROOT=BASE/"candidate-r1";OUT=BASE/"native-r1";OUT.mkdir(exist_ok=False)
PY=BASE/"venv/Scripts/python.exe"
test=ROOT/"tests/ui/test_review_video_interval.py"
shutil.copyfile(test,OUT/"test-before-lint-correction.py")
t=test.read_text();assert t.count("zip(positions, positions[1:])")==4
test.write_text(t.replace("zip(positions, positions[1:])","zip(positions, positions[1:], strict=False)"),encoding="utf-8",newline="\n")
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE="1",PYTHONUTF8="1",TEMP=str(BASE/"tmp"),TMP=str(BASE/"tmp"),QT_QPA_PLATFORM="offscreen",RUFF_CACHE_DIR=str(OUT/"ruff-cache"),CAPTURE_REPEAT_EVIDENCE=str(OUT))
def pins(root):
 return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob("*")) if p.is_file()}
def run(label,args,limit):
 with (OUT/(label+".stdout")).open("wb") as a,(OUT/(label+".stderr")).open("wb") as b:
  p=subprocess.Popen([str(PY),*args],cwd=ROOT,env=env,stdout=a,stderr=b)
  (OUT/(label+"-started.json")).write_text(json.dumps({"wrapper":os.getpid(),"child":p.pid,"argv":args,"at":time.time()})+"\n")
  timed=False
  try:code=p.wait(timeout=limit)
  except subprocess.TimeoutExpired:timed=True;p.terminate();code=p.wait(timeout=10)
 entry={"label":label,"argv":[str(PY),*args],"pid":p.pid,"code":code,"timed_out":timed}
 print(json.dumps(entry),flush=True);return entry
receipt={"started":time.time(),"pid":os.getpid(),"commands":[]}
files=["desktop/capture_desktop/widgets_review_video.py","desktop/capture_desktop/review_video_interval.py","tests/test_review_video_interval.py","tests/ui/test_review_video_interval.py"]
receipt["commands"].append(run("ruff",["-m","ruff","check",*files],30))
assert receipt["commands"][-1]["code"]==0
guard=json.loads(subprocess.check_output(["powershell","-NoProfile","-Command","$o=Get-CimInstance Win32_OperatingSystem; @{identity=[System.Security.Principal.WindowsIdentity]::GetCurrent().Name;free_memory_bytes=[int64]$o.FreePhysicalMemory*1024}|ConvertTo-Json -Compress"],text=True))
guard["disk_free"]=shutil.disk_usage(BASE).free;assert guard["free_memory_bytes"]>=2*1024**3 and guard["disk_free"]>=512*1024**2,guard
receipt["guard"]=guard;receipt["before"]=pins(ROOT)
receipt["commands"].append(run("pytest",["-B","-m","pytest","-p","no:cacheprovider","--basetemp",str(OUT/"pytest-tmp"),"--junitxml",str(OUT/"native.xml"),"-q","tests/ui/test_review_video.py","tests/ui/test_review_video_interval.py"],150))
receipt.update(finished=time.time(),after=pins(ROOT));receipt["source_exact"]=receipt["before"]==receipt["after"];receipt["pass"]=all(c["code"]==0 for c in receipt["commands"]) and receipt["source_exact"]
(OUT/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8",newline="\n")
print(json.dumps({"pass":receipt["pass"],"source_exact":receipt["source_exact"],"commands":receipt["commands"],"receipt_sha256":hashlib.sha256((OUT/"receipt.json").read_bytes()).hexdigest()}),flush=True)
raise SystemExit(0 if receipt["pass"] else 1)
