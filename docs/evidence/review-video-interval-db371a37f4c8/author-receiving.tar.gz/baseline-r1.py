import hashlib,json,os,sys,time,traceback
from pathlib import Path
BASE=Path(r"D:/Hamon/worktrees/capture-video-repeat-db371a37f4c8-production")
OUT=BASE/"baseline-r1";OUT.mkdir(exist_ok=False)
ROOT=BASE/"original"
os.environ.update(QT_QPA_PLATFORM="offscreen",PYTHONDONTWRITEBYTECODE="1",MPLCONFIGDIR=str(OUT/"mpl-cache"))
for key,suffix in [("LOCALAPPDATA","local"),("APPDATA","roaming"),("XDG_CONFIG_HOME","config"),("XDG_DATA_HOME","data"),("XDG_CACHE_HOME","cache")]:
 folder=OUT/suffix;folder.mkdir();os.environ[key]=str(folder)
for rel in ["desktop","libs/python/capture_analysis","libs/python/capture_session","libs/python/capture_protocol"]:
 sys.path.insert(0,str(ROOT/rel))
import PySide6
from PySide6.QtCore import QCoreApplication,QEvent,Qt
from PySide6.QtMultimedia import QMediaPlayer
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication,QComboBox,QPushButton
from capture_desktop.widgets_review_video import RecordedVideoReview
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
admit=json.loads((BASE/"original-admission.json").read_text())
def source():return {f["path"]:sha(Path(f["path"])) for f in admit["source"]+admit["fixture"]}
expected={f["path"]:f["sha256"] for f in admit["source"]+admit["fixture"]}
def wait(pred,label):
 end=time.monotonic()+12
 while time.monotonic()<end:
  app.processEvents()
  if pred():return
  QTest.qWait(10)
 raise AssertionError(label)
receipt={"schema":"capture-repeat-author-original-r1","started":time.time(),"pid":os.getpid(),"python":sys.version,"executable":sys.executable,"qt":PySide6.__version__,"groups":[],"boundary":"Actual native Windows Qt offscreen widget/decoder and QTest controls; no physical foreground input or GPU-window screenshot claim."}
app=QApplication([]);view=None
try:
 assert source()==expected
 view=RecordedVideoReview();view.resize(1060,700);view.show();view._toggle.setChecked(True)
 view.load_package(str(ROOT/"tests/fixtures/review_video"),state="finalized")
 assert view._player is None and view._choice.count()==5
 receipt["groups"].append("Original package inventory does not autoplay")
 view._choice.setCurrentIndex(1)
 wait(lambda:view._ready,"original decoder readiness")
 p=view._player
 assert p.duration()==2000 and p.playbackRate()==1 and p.playbackState()==QMediaPlayer.PlaybackState.StoppedState
 buttons=[b.text() for b in view.findChildren(QPushButton)]
 combos=[[c.itemText(i) for i in range(c.count())] for c in view.findChildren(QComboBox)]
 assert buttons==["Reload selected","Play"] and len(combos)==1,(buttons,combos)
 receipt["original_controls"]={"buttons":buttons,"comboboxes":combos,"rate":p.playbackRate(),"duration_ms":p.duration()}
 receipt["groups"].append("Original actual widget has only Play/Reload and segment chooser; no interval/rate workflow")
 frames=[];p.videoSink().videoFrameChanged.connect(lambda f:frames.append(f.isValid()))
 QTest.mouseClick(view._play,Qt.MouseButton.LeftButton)
 wait(lambda:p.position()>=300 and any(frames),"actual playback progression and decoded frame")
 QTest.mouseClick(view._play,Qt.MouseButton.LeftButton)
 wait(lambda:p.playbackState()==QMediaPlayer.PlaybackState.PausedState,"pause")
 pos=p.position();QTest.qWait(200);assert p.position()==pos
 receipt["groups"].append("Native Play/Pause progresses media and receives decoded frames; pause retains position")
 view._seek.setValue(5000)
 wait(lambda:p.position()==1000 and "00:00:01.000" in view._clock.text(),"paused segment seek")
 assert p.playbackState()==QMediaPlayer.PlaybackState.PausedState
 receipt["groups"].append("Original paused 50-percent seek maps to1000ms without playback")
 receipt.update(outcome="pass",decoded_frames=len(frames),source_after_exact=source()==expected)
 assert receipt["source_after_exact"]
except Exception:
 receipt.update(outcome="fail",traceback=traceback.format_exc())
finally:
 if view is not None:view.reset();view.close();view.deleteLater()
 QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete);app.processEvents()
 receipt["finished"]=time.time();receipt["source_after"]=source()
 (OUT/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8",newline="\n")
 print(json.dumps({"outcome":receipt["outcome"],"groups":receipt["groups"],"receipt_sha256":sha(OUT/"receipt.json"),"error":receipt.get("traceback")}),flush=True)
if receipt["outcome"]!="pass":raise SystemExit(1)
