import hashlib,json,os,shutil,subprocess,time,difflib
from pathlib import Path
BASE=Path(r"D:/Hamon/worktrees/capture-video-repeat-db371a37f4c8-production");ROOT=BASE/"candidate-r1";OUT=BASE/"native-r3";OUT.mkdir(exist_ok=False)
PY=BASE/"venv/Scripts/python.exe"
test=ROOT/"tests/ui/test_review_video_interval.py";old=test.read_text(encoding="utf-8");shutil.copyfile(test,OUT/"test-before-utf8-correction.py")
lines=old.splitlines(True);matching=[i for i,l in enumerate(lines) if 'assert f"{rate:g}' in l];assert len(matching)==1
lines[matching[0]]='            assert f"{rate:g}\\u00d7" in video._rate_label.text()\n'
new="".join(lines);test.write_text(new,encoding="utf-8",newline="\n")
(OUT/"test-utf8.patch").write_text("".join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile="receiver-r2",tofile="receiver-r3")),encoding="utf-8",newline="\n")
widget=ROOT/"desktop/capture_desktop/widgets_review_video.py";helper=ROOT/"desktop/capture_desktop/review_video_interval.py"
assert hashlib.sha256(widget.read_bytes()).hexdigest()=="e2e02b417b75d590f118608cd63bf0e9b9af94f12170c43776f3643c06ecd4eb"
assert hashlib.sha256(helper.read_bytes()).hexdigest()=="798a836270de8a586eb3341ebccfc142ed59541822982187b3d14d79f2eecc97"
original=BASE/"original/desktop/capture_desktop/widgets_review_video.py"
patch="".join(difflib.unified_diff(original.read_text(encoding="utf-8").splitlines(True),widget.read_text(encoding="utf-8").splitlines(True),fromfile="original/widgets_review_video.py",tofile="candidate-r1/widgets_review_video.py"))
(BASE/"widget-delta-utf8-r1.patch").write_text(patch,encoding="utf-8",newline="\n")
literals=[l for l in widget.read_text(encoding="utf-8").splitlines() if "Backend-reported speed" in l or 'QCheckBox("Repeat' in l or "self._rate.addItem" in l]
audit={"product_bytes_unchanged":True,"lines":[{"text":l,"non_ascii":[hex(ord(c)) for c in l if ord(c)>127]} for l in literals],"original_patch_retained":str(BASE/"widget-delta-r1.patch"),"corrected_patch_sha256":hashlib.sha256((BASE/"widget-delta-utf8-r1.patch").read_bytes()).hexdigest(),"receiver_changed_lines":1}
(OUT/"utf8-audit.json").write_text(json.dumps(audit,indent=2)+"\n",encoding="utf-8",newline="\n")
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE="1",PYTHONUTF8="1",TEMP=str(BASE/"tmp"),TMP=str(BASE/"tmp"),QT_QPA_PLATFORM="offscreen",RUFF_CACHE_DIR=str(OUT/"ruff-cache"),CAPTURE_REPEAT_EVIDENCE=str(OUT))
def pins():return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(ROOT.rglob("*")) if p.is_file()}
guard=json.loads(subprocess.check_output(["powershell","-NoProfile","-Command","$o=Get-CimInstance Win32_OperatingSystem; @{free_memory_bytes=[int64]$o.FreePhysicalMemory*1024}|ConvertTo-Json -Compress"],text=True));guard["disk_free"]=shutil.disk_usage(BASE).free
assert guard["free_memory_bytes"]>=2*1024**3 and guard["disk_free"]>=512*1024**2,guard
receipt={"started":time.time(),"pid":os.getpid(),"guard":guard,"before":pins(),"commands":[],"scope":"Finish only speed/reset case with one corrected receiver Unicode literal, then native control layout/decoded-pixel presentation. R2's11passed cases remain separate; no broad replay."}
commands=[("ruff",["-m","ruff","check","desktop/capture_desktop/widgets_review_video.py","desktop/capture_desktop/review_video_interval.py","tests/test_review_video_interval.py","tests/ui/test_review_video_interval.py"],30),("speed-reset",["-B","-m","pytest","-p","no:cacheprovider","--basetemp",str(OUT/"pytest-tmp"),"--junitxml",str(OUT/"native.xml"),"-s","-vv","tests/ui/test_review_video_interval.py::test_actual_speed_progression_and_selection_reset"],60),("presentation",["-B","-u",str(BASE/"presentation-r1.py")],60)]
for label,args,limit in commands:
 with (OUT/(label+".stdout")).open("wb") as a,(OUT/(label+".stderr")).open("wb") as b:
  p=subprocess.Popen([str(PY),*args],cwd=ROOT,env=env,stdout=a,stderr=b)
  (OUT/(label+"-started.json")).write_text(json.dumps({"wrapper":os.getpid(),"child":p.pid,"argv":args,"at":time.time()})+"\n",encoding="utf-8")
  timed=False
  try:code=p.wait(timeout=limit)
  except subprocess.TimeoutExpired:timed=True;p.terminate();code=p.wait(timeout=10)
 entry={"label":label,"pid":p.pid,"code":code,"timed_out":timed};receipt["commands"].append(entry);print(json.dumps(entry),flush=True)
 if code!=0:break
receipt.update(finished=time.time(),after=pins());receipt["source_exact"]=receipt["before"]==receipt["after"];receipt["pass"]=all(c["code"]==0 for c in receipt["commands"]) and len(receipt["commands"])==3 and receipt["source_exact"]
(OUT/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8",newline="\n")
print(json.dumps({"pass":receipt["pass"],"source_exact":receipt["source_exact"],"commands":receipt["commands"],"receipt_sha256":hashlib.sha256((OUT/"receipt.json").read_bytes()).hexdigest()}),flush=True)
raise SystemExit(0 if receipt["pass"] else 1)
