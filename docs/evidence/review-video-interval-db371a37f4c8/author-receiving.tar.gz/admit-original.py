import hashlib,json,shutil,time
from pathlib import Path
BASE=Path(r"D:/Hamon/worktrees/capture-video-repeat-db371a37f4c8-production")
packet=BASE/"original-source-packet.json"
obj=json.loads(packet.read_text(encoding="utf-8"))
assert shutil.disk_usage(BASE).free>512*1024**2
root=BASE/"original";assert not root.exists()
def pin(p):
 b=p.read_bytes();return {"path":str(p),"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),"git":hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()}
for f in obj["files"]:
 b=f["content"].encode()
 assert len(b)==f["bytes"] and hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()==f["git"],f["path"]
 target=root/f["path"];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
fixture=Path(r"D:/Hamon/receiving/capture-video-repeat-db371a37f4c8/original-fixture")
before=[pin(p) for p in sorted(fixture.rglob("*")) if p.is_file()]
shutil.copytree(fixture,root/"tests/fixtures/review_video")
for f in before:
 target=root/"tests/fixtures/review_video"/Path(f["path"]).relative_to(fixture)
 assert pin(target)["sha256"]==f["sha256"]
receipt={"at":time.time(),"source_packet":pin(packet),"commit":obj["commit"],"tree":obj["tree"],"source":[pin(root/f["path"]) for f in obj["files"]],"fixture":[pin(p) for p in sorted((root/"tests/fixtures/review_video").rglob("*")) if p.is_file()],"fixture_source_unchanged":before==[pin(p) for p in sorted(fixture.rglob("*")) if p.is_file()]}
assert receipt["fixture_source_unchanged"]
(BASE/"original-admission.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"receipt":pin(BASE/"original-admission.json"),"source_count":len(receipt["source"]),"fixture_count":len(receipt["fixture"])}),flush=True)
