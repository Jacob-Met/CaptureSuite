import ctypes,hashlib,json,os,shutil,subprocess,time,traceback
from pathlib import Path
BASE=Path(r"D:/Hamon/worktrees/capture-video-repeat-db371a37f4c8-production")
OUT=BASE/"environment-deps-r1";OUT.mkdir(exist_ok=False)
before=json.loads((BASE/"environment-r1/receipt.json").read_text());assert before["outcome"]=="pass"
env=os.environ.copy();env.update(before["private_environment"]);env.update(UV_CONCURRENT_DOWNLOADS="2",UV_CONCURRENT_INSTALLS="2",UV_CONCURRENT_BUILDS="1",UV_THREADPOOL_SIZE="2")
uv=BASE/"tools/uv.exe";py=BASE/"venv/Scripts/python.exe"
receipt={"started":time.time(),"commands":[],"supported_python":"3.12.10","package_selection":"Exact versions from previously qualified runtime, allowed by current project requirements; new private environment, not original donor."}
def pin(p):
 b=p.read_bytes();return {"path":str(p),"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}
def run(label,args,timeout=240):
 t=time.time()
 r=subprocess.run(args,cwd=BASE,env=env,capture_output=True,timeout=timeout)
 (OUT/(label+".stdout")).write_bytes(r.stdout);(OUT/(label+".stderr")).write_bytes(r.stderr)
 receipt["commands"].append({"label":label,"argv":args,"returncode":r.returncode,"elapsed":time.time()-t,"stdout":pin(OUT/(label+".stdout")),"stderr":pin(OUT/(label+".stderr"))})
 assert r.returncode==0,(label,r.returncode,r.stderr.decode(errors="replace"))
 return r.stdout
try:
 assert shutil.disk_usage(BASE).free>=2*1024**3
 requirements="PySide6==6.12.0\nprotobuf==4.25.9\njsonschema==4.26.0\nPyYAML==6.0.3\npytest==9.1.1\nruff==0.16.10\nnumpy==2.5.3\nscipy==1.18.1\npandas==3.0.6\npyarrow==25.0.1\nmatplotlib==3.11.2\nmcap==1.5.0\npyqtgraph==0.14.0\n"
 (OUT/"requirements.in").write_text(requirements,encoding="utf-8")
 run("resolve",[str(uv),"--no-config","pip","compile",str(OUT/"requirements.in"),"--python",str(py),"--generate-hashes","--output-file",str(OUT/"requirements.lock")])
 run("sync",[str(uv),"--no-config","pip","sync","--python",str(py),"--require-hashes","--only-binary",":all:",str(OUT/"requirements.lock")])
 run("check",[str(uv),"--no-config","pip","check","--python",str(py)],30)
 run("versions",[str(uv),"--no-config","pip","list","--python",str(py),"--format","json"],30)
 run("qt-import",[str(py),"-B","-c","import sys,PySide6; from PySide6.QtMultimedia import QMediaPlayer; print(sys.version); print(PySide6.__version__)"],30)
 files=[pin(p) for p in sorted((BASE/"venv").rglob("*")) if p.is_file()]
 (OUT/"installed-files.json").write_text(json.dumps(files,indent=2)+"\n",encoding="utf-8")
 receipt.update(outcome="pass",installed_count=len(files),installed_bytes=sum(x["bytes"] for x in files),installed_manifest=pin(OUT/"installed-files.json"),lock=pin(OUT/"requirements.lock"),python=pin(py))
except Exception:
 receipt.update(outcome="fail",traceback=traceback.format_exc())
finally:
 receipt["finished"]=time.time()
 (OUT/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
 print(json.dumps({"outcome":receipt["outcome"],"receipt":pin(OUT/"receipt.json"),"error":receipt.get("traceback"),"installed_count":receipt.get("installed_count"),"installed_bytes":receipt.get("installed_bytes")}),flush=True)
if receipt["outcome"]!="pass":raise SystemExit(1)
