import hashlib,json,os,subprocess,time
from pathlib import Path
BASE=Path(r"D:/Hamon/worktrees/capture-video-repeat-db371a37f4c8-production")
OUT=BASE/"baseline-wrapper-r1";OUT.mkdir(exist_ok=False)
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE="1",PYTHONUTF8="1",TEMP=str(BASE/"tmp"),TMP=str(BASE/"tmp"))
argv=[str(BASE/"venv/Scripts/python.exe"),"-B","-u",str(BASE/"baseline-r1.py")]
with (OUT/"stdout.txt").open("wb") as stdout,(OUT/"stderr.txt").open("wb") as stderr:
 p=subprocess.Popen(argv,cwd=BASE,env=env,stdout=stdout,stderr=stderr)
 (OUT/"started.json").write_text(json.dumps({"wrapper":os.getpid(),"child":p.pid,"argv":argv,"started":time.time()})+"\n")
 try:code=p.wait(timeout=90)
 except subprocess.TimeoutExpired:p.terminate();code=p.wait(timeout=10)
receipt={"child":p.pid,"returncode":code,"finished":time.time(),"stdout_sha256":hashlib.sha256((OUT/"stdout.txt").read_bytes()).hexdigest(),"stderr_sha256":hashlib.sha256((OUT/"stderr.txt").read_bytes()).hexdigest()}
(OUT/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt),flush=True)
raise SystemExit(code)
