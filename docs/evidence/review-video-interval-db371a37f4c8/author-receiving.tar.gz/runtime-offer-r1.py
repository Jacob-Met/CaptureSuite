import hashlib,json,time,difflib
from pathlib import Path
BASE=Path(r"D:/Hamon/worktrees/capture-video-repeat-db371a37f4c8-production");ROOT=BASE/"candidate-r1"
rels=["desktop/capture_desktop/widgets_review_video.py","desktop/capture_desktop/review_video_interval.py","docs/operator/RECORDED_VIDEO_REVIEW.md"]
def pin(p):
 b=p.read_bytes();return {"path":str(p),"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),"git":hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()}
old=BASE/"original/desktop/capture_desktop/widgets_review_video.py";new=ROOT/rels[0]
patch="".join(difflib.unified_diff(old.read_text().splitlines(True),new.read_text().splitlines(True),fromfile="original/"+rels[0],tofile="candidate-r1/"+rels[0]))
(BASE/"widget-delta-r1.patch").write_text(patch,encoding="utf-8",newline="\n")
receipt={"schema":"capture-repeat-runtime-offer-r1","at":time.time(),"status":"R1 source frozen for root static review; native candidate gate negative with abort, diagnostic pending; not accepted.","canonical_commit":"3960c0c756cd4e9facbde0d76eaaa3c31ab7c167","original":pin(old),"candidate":[pin(ROOT/r) for r in rels],"delta":pin(BASE/"widget-delta-r1.patch"),"native_negative":pin(BASE/"native-r1/receipt.json"),"no_author_tests":"This runtime-only offer excludes test source/outcome expectations."}
(BASE/"RUNTIME-OFFER-r1.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8",newline="\n")
print(json.dumps(receipt),flush=True)
