import base64,gzip,hashlib,io,json,os,subprocess,tarfile,time
from pathlib import Path
BASE=Path(r"D:/Hamon/worktrees/capture-video-repeat-db371a37f4c8-production");OUT=BASE/"publication-r1";OUT.mkdir(exist_ok=False)
def pin(p):
 b=p.read_bytes();return {"path":str(p.relative_to(BASE)),"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),"git":hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()}
excluded_roots={"venv","python","python-bin","uv-cache","tmp","tools","publication-r1"}
excluded_names={"ruff-cache","__pycache__",".pytest_cache",".ruff_cache"}
files=[]
for p in sorted(BASE.rglob("*")):
 if not p.is_file():continue
 rel=p.relative_to(BASE)
 if rel.parts[0] in excluded_roots or any(x in excluded_names for x in rel.parts) or p.suffix==".whl":continue
 files.append(p)
entries=[pin(p) for p in files]
manifest={"schema":"capture-video-repeat-author-archive-r1","files":entries,"excluded_roots":sorted(excluded_roots),"excluded_names":sorted(excluded_names),"excluded_suffixes":[".whl"],"boundary":"Exact whole selected source,receivers,logs,original failures,final passes and pin/provenance files. Runtime/cache/download bodies omitted, retained natively."}
mb=(json.dumps(manifest,indent=2)+"\n").encode();(OUT/"MANIFEST.json").write_bytes(mb)
archive=OUT/"capture-video-interval-author.tar.gz"
with archive.open("wb") as raw:
 with gzip.GzipFile(fileobj=raw,mode="wb",mtime=0,filename="") as gz:
  with tarfile.open(fileobj=gz,mode="w") as tar:
   for p,e in zip(files,entries,strict=True):
    b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==e["sha256"]
    i=tarfile.TarInfo(e["path"].replace("\\","/"));i.size=len(b);i.mode=0o644;i.mtime=0;tar.addfile(i,io.BytesIO(b))
   i=tarfile.TarInfo("MANIFEST.json");i.size=len(mb);i.mode=0o644;i.mtime=0;tar.addfile(i,io.BytesIO(mb))
with tarfile.open(archive,"r:gz") as tar:
 members=tar.getmembers();assert len(members)==len(entries)+1
 for e in entries:
  b=tar.extractfile(e["path"].replace("\\","/")).read();assert len(b)==e["bytes"] and hashlib.sha256(b).hexdigest()==e["sha256"]
 assert tar.extractfile("MANIFEST.json").read()==mb
assert entries==[pin(p) for p in files]
census=subprocess.check_output(["powershell","-NoProfile","-Command","$p=@(Get-CimInstance Win32_Process | Where-Object { $_.Name -ne 'powershell.exe' -and $_.CommandLine -like '*capture-video-repeat-db371a37f4c8-production*' }); @($p | Select-Object ProcessId,ParentProcessId,Name,CommandLine) | ConvertTo-Json -Compress -Depth 4"],text=True)
(OUT/"process-census.json").write_text(census,encoding="utf-8")
blob=archive.read_bytes();b64=base64.b64encode(blob).decode()
(OUT/"archive.b64").write_text("\n".join(b64[i:i+64000] for i in range(0,len(b64),64000))+"\n",encoding="ascii",newline="\n")
seal={"schema":"capture-video-interval-author-seal-r1","at":time.time(),"sealer_pid":os.getpid(),"archive":pin(archive),"manifest":pin(OUT/"MANIFEST.json"),"payload_members":len(entries),"total_members":len(entries)+1,"payload_bytes":sum(x["bytes"] for x in entries),"roundtrip_exact":True,"source_after_exact":True,"base64_chars":len(b64),"base64_lines":(len(b64)+63999)//64000,"base64_line_width":64000}
(OUT/"SEAL.json").write_text(json.dumps(seal,indent=2)+"\n",encoding="utf-8",newline="\n")
freeze=json.loads((BASE/"SOURCE-FREEZE.json").read_text(encoding="utf-8"))
texts={f["repository_path"]:Path(f["path"]).read_text(encoding="utf-8") for f in freeze["files"]}
for name in ["AUTHOR.md","SOURCE-FREEZE.json","WORKFLOW-AUDIT.json","CUSTODY-NOTES.json"]:
 texts["docs/evidence/review-video-interval-db371a37f4c8/"+name]=(BASE/name).read_text(encoding="utf-8")
for name in ["MANIFEST.json","SEAL.json"]:
 texts["docs/evidence/review-video-interval-db371a37f4c8/author-"+name.lower()]=(OUT/name).read_text(encoding="utf-8")
(OUT/"TEXT-PAYLOAD.json").write_text(json.dumps(texts,ensure_ascii=True)+"\n",encoding="ascii",newline="\n")
print(json.dumps(seal),flush=True)
