import ctypes,hashlib,json,os,shutil,subprocess,time,traceback,urllib.request,zipfile
from pathlib import Path
BASE=Path(r"D:/Hamon/worktrees/capture-video-repeat-db371a37f4c8-production")
OUT=BASE/"environment-r1";OUT.mkdir(exist_ok=False)
class Memory(ctypes.Structure):
 _fields_=[("length",ctypes.c_ulong),("load",ctypes.c_ulong)]+[(x,ctypes.c_ulonglong) for x in ["total","available","page_total","page_available","virtual_total","virtual_available","extended"]]
m=Memory();m.length=ctypes.sizeof(m);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
receipt={"started":time.time(),"filesystem_free":shutil.disk_usage(BASE).free,"memory_available":m.available,"commands":[],"boundary":"Private tool extraction and managed Python with registry disabled; own cache/bin/temp only."}
def pin(p):
 b=p.read_bytes();return {"path":str(p),"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}
def fetch(url,dest,limit):
 with urllib.request.urlopen(url,timeout=30) as response:
  assert response.url.startswith("https://"),response.url
  b=response.read(limit+1)
  assert len(b)<=limit
 dest.write_bytes(b);return b
def run(label,args,env,timeout=240):
 t=time.time();r=subprocess.run(args,cwd=BASE,env=env,capture_output=True,timeout=timeout)
 (OUT/(label+".stdout")).write_bytes(r.stdout);(OUT/(label+".stderr")).write_bytes(r.stderr)
 receipt["commands"].append({"label":label,"argv":args,"returncode":r.returncode,"elapsed":time.time()-t,"stdout":pin(OUT/(label+".stdout")),"stderr":pin(OUT/(label+".stderr"))})
 assert r.returncode==0,(label,r.returncode,r.stderr.decode(errors="replace"))
 return r.stdout
try:
 assert receipt["filesystem_free"]>=2*1024**3 and m.available>=2*1024**3
 metadata=fetch("https://pypi.org/pypi/uv/0.12.23/json",OUT/"uv-pypi.json",2*1024**2)
 data=json.loads(metadata)
 wheels=[x for x in data["urls"] if x["filename"].endswith("win_amd64.whl")]
 assert len(wheels)==1
 wheel=wheels[0];assert wheel["size"]<=100*1024**2
 b=fetch(wheel["url"],OUT/wheel["filename"],100*1024**2)
 assert len(b)==wheel["size"] and hashlib.sha256(b).hexdigest()==wheel["digests"]["sha256"]
 receipt["uv_wheel"]={**pin(OUT/wheel["filename"]),"url":wheel["url"],"pypi_sha256":wheel["digests"]["sha256"]}
 with zipfile.ZipFile(OUT/wheel["filename"]) as z:
  entries=[x for x in z.infolist() if x.filename.endswith("/uv.exe")]
  assert len(entries)==1 and entries[0].file_size<200*1024**2
  uv=BASE/"tools/uv.exe";uv.parent.mkdir()
  uv.write_bytes(z.read(entries[0]))
 receipt["uv_executable"]=pin(uv)
 env=os.environ.copy()
 env.update(UV_CACHE_DIR=str(BASE/"uv-cache"),UV_PYTHON_INSTALL_DIR=str(BASE/"python"),UV_PYTHON_BIN_DIR=str(BASE/"python-bin"),UV_PYTHON_INSTALL_REGISTRY="0",UV_PYTHON_NO_REGISTRY="1",UV_NO_PROGRESS="1",UV_NO_CONFIG="1",UV_PYTHON_DOWNLOADS="manual",PYTHONDONTWRITEBYTECODE="1",PYTHONUTF8="1",TMP=str(BASE/"tmp"),TEMP=str(BASE/"tmp"))
 (BASE/"tmp").mkdir()
 receipt["private_environment"]={k:env[k] for k in env if k.startswith("UV_") or k in ["TMP","TEMP","PYTHONUTF8","PYTHONDONTWRITEBYTECODE"]}
 run("uv-version",[str(uv),"--version"],env,10)
 help_text=run("uv-python-help",[str(uv),"python","install","--help"],env,10)
 assert b"--no-registry" in help_text
 run("python-install",[str(uv),"--no-config","python","install","3.12.10","--no-registry"],env)
 executable=run("python-find",[str(uv),"--no-config","python","find","--managed-python","3.12.10"],env,15).decode().strip()
 assert Path(executable).resolve().is_relative_to((BASE/"python").resolve())
 receipt["python_executable"]=pin(Path(executable))
 run("venv",[str(uv),"--no-config","venv","--python",executable,str(BASE/"venv")],env,30)
 receipt["outcome"]="pass"
except Exception:
 receipt["outcome"]="fail";receipt["traceback"]=traceback.format_exc()
finally:
 receipt["finished"]=time.time()
 (OUT/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
 print(json.dumps({"outcome":receipt["outcome"],"receipt":pin(OUT/"receipt.json"),"error":receipt.get("traceback"),"python":receipt.get("python_executable")}),flush=True)
if receipt["outcome"]!="pass":raise SystemExit(1)
