import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
BASE=Path(r"D:/Hamon/worktrees/capture-video-repeat-db371a37f4c8-production");ROOT=BASE/"candidate-r1";OUT=BASE/"native-diagnostic-r1";OUT.mkdir(exist_ok=False)
PY=BASE/"venv/Scripts/python.exe"
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE="1",PYTHONUTF8="1",TEMP=str(BASE/"tmp"),TMP=str(BASE/"tmp"),QT_QPA_PLATFORM="offscreen",CAPTURE_REPEAT_EVIDENCE=str(OUT))
def pins():return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(ROOT.rglob("*")) if p.is_file()}
guard=json.loads(subprocess.check_output(["powershell","-NoProfile","-Command","$o=Get-CimInstance Win32_OperatingSystem; @{free_memory_bytes=[int64]$o.FreePhysicalMemory*1024}|ConvertTo-Json -Compress"],text=True));guard["disk_free"]=shutil.disk_usage(BASE).free
assert guard["free_memory_bytes"]>=2*1024**3 and guard["disk_free"]>=512*1024**2,guard
receipt={"schema":"capture-native-order-diagnostic-r1","pid":os.getpid(),"started":time.time(),"guard":guard,"before":pins(),"commands":[],"boundary":"Unchanged product/tests, no pytest output capture so native fatal Qt details remain visible; isolated uncompleted case then the new five-case file only."}
for label,selector in [("isolated-uncompleted","tests/ui/test_review_video_interval.py::test_actual_repeat_cycles_then_disable_clear_and_playing_seek"),("new-file-only","tests/ui/test_review_video_interval.py")]:
 argv=[str(PY),"-B","-m","pytest","-p","no:cacheprovider","--basetemp",str(OUT/(label+"-tmp")),"--junitxml",str(OUT/(label+".xml")),"-s","-vv",selector]
 with (OUT/(label+".stdout")).open("wb") as a,(OUT/(label+".stderr")).open("wb") as b:
  p=subprocess.Popen(argv,cwd=ROOT,env=env,stdout=a,stderr=b)
  (OUT/(label+"-started.json")).write_text(json.dumps({"wrapper":os.getpid(),"child":p.pid,"argv":argv,"at":time.time()})+"\n")
  timed=False
  try:code=p.wait(timeout=80)
  except subprocess.TimeoutExpired:timed=True;p.terminate();code=p.wait(timeout=10)
 receipt["commands"].append({"label":label,"pid":p.pid,"code":code,"timed_out":timed});print(json.dumps(receipt["commands"][-1]),flush=True)
 if code!=0:break
receipt.update(finished=time.time(),after=pins());receipt["source_exact"]=receipt["before"]==receipt["after"]
(OUT/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8",newline="\n")
print(json.dumps({"commands":receipt["commands"],"source_exact":receipt["source_exact"],"receipt_sha256":hashlib.sha256((OUT/"receipt.json").read_bytes()).hexdigest()}),flush=True)
raise SystemExit(0 if all(x["code"]==0 for x in receipt["commands"]) else 1)
