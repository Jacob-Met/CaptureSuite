"""Bounded launcher for the independent candidate Qt receiver. Staging alone runs nothing."""
from __future__ import annotations
import argparse, ctypes, hashlib, json, os, pathlib, shutil, subprocess, sys, time, traceback
from datetime import datetime, timezone
sys.dont_write_bytecode=True

def stamp():return datetime.now(timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
class Memory(ctypes.Structure):
    _fields_=[("dwLength",ctypes.c_ulong),("dwMemoryLoad",ctypes.c_ulong),
              ("ullTotalPhys",ctypes.c_ulonglong),("ullAvailPhys",ctypes.c_ulonglong),
              ("ullTotalPageFile",ctypes.c_ulonglong),("ullAvailPageFile",ctypes.c_ulonglong),
              ("ullTotalVirtual",ctypes.c_ulonglong),("ullAvailVirtual",ctypes.c_ulonglong),
              ("ullAvailExtendedVirtual",ctypes.c_ulonglong)]
ap=argparse.ArgumentParser()
ap.add_argument("--admission",required=True);ap.add_argument("--run",required=True)
a=ap.parse_args()
admission=pathlib.Path(a.admission).resolve()
assert sha(admission)=="1a801e522e0c0e850f64a296be4c8ff153ab4525d10b048f559529d1471f0416"
d=json.loads(admission.read_bytes())
assert d["kind"]=="capturesuite-candidate-native-admission-v1"
driver=pathlib.Path(__file__).resolve().parent/"candidate-native-r1.py"
assert sha(driver)=="72526eeb5eb489c5e92b152fd77ffc32062adcced2c29028cf3431fe42808110"
assert pathlib.Path(d["python"]).is_file()
mem=Memory();mem.dwLength=ctypes.sizeof(mem)
assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(mem))
assert mem.ullAvailPhys>512*1024*1024
run=pathlib.Path(a.run).resolve()
assert not run.exists()
free=shutil.disk_usage(run.parent).free
assert free>64*1024*1024
run.mkdir() # do not place an admission failure in a reused run/finally
(run/"cwd").mkdir();(run/"tmp").mkdir()
record={"started":stamp(),"status":"RUNNING","driver_sha256":sha(driver),"admission_sha256":sha(admission),
        "memory_available_bytes":mem.ullAvailPhys,"free_bytes":free,"wrapper_pid":os.getpid(),
        "native_ui_launch":True,"child_environment_overrides":{"PYTHONDONTWRITEBYTECODE":"1","TEMP":str(run/"tmp"),"TMP":str(run/"tmp")}}
env=os.environ.copy();env.update(record["child_environment_overrides"])
record["qt_environment"]={k:env.get(k) for k in ("QT_QPA_PLATFORM","QT_MEDIA_BACKEND","QT_OPENGL","QT_QUICK_BACKEND")}
p=None
try:
    argv=[d["python"],"-B",str(driver),"--admission",str(admission),"--output",str(run/"native")]
    record["argv"]=argv;record["cwd"]=str(run/"cwd")
    with (run/"stdout.log").open("xb") as stdout,(run/"stderr.log").open("xb") as stderr:
        p=subprocess.Popen(argv,cwd=run/"cwd",env=env,stdout=stdout,stderr=stderr,
                           creationflags=subprocess.CREATE_NEW_PROCESS_GROUP)
        record["child_pid"]=p.pid
        (run/"launch.json").write_text(json.dumps(record,indent=2)+"\n",encoding="utf-8")
        try:record["exit_code"]=p.wait(timeout=90)
        except subprocess.TimeoutExpired:
            record["timeout_seconds"]=90;p.terminate()
            try:record["exit_code"]=p.wait(timeout=5)
            except subprocess.TimeoutExpired:p.kill();record["exit_code"]=p.wait(timeout=5);record["force_kill"]=True
    receipt=run/"native/receipt.json"
    if receipt.exists():
        record["native_receipt_sha256"]=sha(receipt)
        native=json.loads(receipt.read_bytes())
        record["native_status"]=native.get("status");record["groups"]=native.get("groups")
    record["status"]="PASS" if record.get("exit_code")==0 and record.get("native_status")=="PASS" and "timeout_seconds" not in record else "FAIL"
except BaseException:
    record["status"]="FAIL";record["failure"]=traceback.format_exc()
finally:
    if p is not None and p.poll() is None:
        p.terminate()
        try:p.wait(timeout=5)
        except subprocess.TimeoutExpired:p.kill();p.wait(timeout=5);record["force_kill"]=True
    record["child_observed_closed"]=p is None or p.poll() is not None
    record["finished"]=stamp()
    with (run/"wrapper-receipt.json").open("x",encoding="utf-8") as f:
        json.dump(record,f,indent=2);f.write("\n");f.flush();os.fsync(f.fileno())
print(json.dumps(record))
sys.exit(0 if record["status"]=="PASS" else 1)
