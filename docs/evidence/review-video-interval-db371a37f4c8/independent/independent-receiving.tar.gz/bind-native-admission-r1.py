import pathlib,json,hashlib,sys,datetime,os,ctypes
sys.dont_write_bytecode=True
r=pathlib.Path('D:/Hamon/receiving/capture-video-repeat-db371a37f4c8')
runtime=json.loads((r/'runtime-admission-r1.json').read_bytes())
assert runtime['status']=='PASS'
root=pathlib.Path(runtime['runtime_root']).resolve()
assert pathlib.Path(sys.executable).resolve()==pathlib.Path(runtime['python']).resolve()
rows=json.loads((r/'runtime-files-frozen-r1.json').read_bytes())['files'];expected={x['path']:x for x in rows}
from PySide6 import QtCore,QtGui,QtWidgets,QtMultimedia,QtMultimediaWidgets
import PySide6
paths=[pathlib.Path(m.__file__).resolve() for m in (PySide6,QtCore,QtGui,QtWidgets,QtMultimedia,QtMultimediaWidgets)]
kernel=ctypes.windll.kernel32
kernel.GetModuleHandleW.argtypes=[ctypes.c_wchar_p];kernel.GetModuleHandleW.restype=ctypes.c_void_p
kernel.GetModuleFileNameW.argtypes=[ctypes.c_void_p,ctypes.c_wchar_p,ctypes.c_uint32];kernel.GetModuleFileNameW.restype=ctypes.c_uint32
for name in ('python312.dll','Qt6Core.dll','Qt6Gui.dll','Qt6Widgets.dll','Qt6Multimedia.dll','Qt6MultimediaWidgets.dll'):
 handle=kernel.GetModuleHandleW(name);assert handle,name
 buf=ctypes.create_unicode_buffer(32768);assert kernel.GetModuleFileNameW(handle,buf,len(buf)),name
 paths.append(pathlib.Path(buf.value).resolve())
proof=[]
for p in paths:
 rel=p.relative_to(root).as_posix();b=p.read_bytes();sha=hashlib.sha256(b).hexdigest()
 assert len(b)==expected[rel]['bytes'] and sha==expected[rel]['sha256'],rel
 proof.append({'path':rel,'bytes':len(b),'sha256':sha})
source=json.loads((r/'original-source-admission-r1.json').read_bytes())
fixture=json.loads((r/'original-fixture-manifest.json').read_bytes())
out={'kind':'capturesuite-original-native-admission-v1','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
     'python':sys.executable,'python_version':sys.version,'qt':QtCore.qVersion(),'pyside':PySide6.__version__,
     'loaded_modules_exact':proof,'plugin_path':QtCore.QLibraryInfo.path(QtCore.QLibraryInfo.LibraryPath.PluginsPath),
     'runtime_manifest_sha256':runtime['manifest_sha256'],'runtime_admission_sha256':hashlib.sha256((r/'runtime-admission-r1.json').read_bytes()).hexdigest(),
     'source_root':source['source_root'],'source_files':source['files'],
     'fixture_root':fixture['root'],'fixture_files':fixture['files'],'candidate_or_author_tests_read':False}
with (r/'native-admission-r1.json').open('x',encoding='utf-8') as f:json.dump(out,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps({k:v for k,v in out.items() if k not in ('source_files','fixture_files')}))
