import pathlib,ast,json,hashlib,datetime,os
B=pathlib.Path('D:/Hamon/worktrees/capture-video-repeat-db371a37f4c8-production')
R=pathlib.Path('D:/Hamon/receiving/capture-video-repeat-db371a37f4c8')
def ident(p):
 b=p.read_bytes()
 return b,{'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
old,op=ident(B/'original/desktop/capture_desktop/widgets_review_video.py')
new,np=ident(B/'candidate-r1/desktop/capture_desktop/widgets_review_video.py')
helper,hp=ident(B/'candidate-r1/desktop/capture_desktop/review_video_interval.py')
assert op['sha256']=='126c4ec87d5af60d151292ff1b2d7f7f3d5ad2f63112507c71d05385bf80f594'
assert np['sha256']=='e2e02b417b75d590f118608cd63bf0e9b9af94f12170c43776f3643c06ecd4eb'
assert hp['sha256']=='798a836270de8a586eb3341ebccfc142ed59541822982187b3d14d79f2eecc97'
def methods(b):
 text=b.decode('utf-8');tree=ast.parse(text)
 cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='RecordedVideoReview')
 return {n.name:{'ast':ast.dump(n,include_attributes=False),'text':ast.get_source_segment(text,n)} for n in cls.body if isinstance(n,ast.FunctionDef)}
a=methods(old);b=methods(new)
changed=[k for k in a if k in b and a[k]['ast']!=b[k]['ast']]
added=[k for k in b if k not in a];same=[k for k in a if k in b and a[k]['ast']==b[k]['ast']]
assert not set(a)-set(b)
assert all(a[k]['text']==b[k]['text'] for k in same)
text=new.decode('utf-8')
constants=[n.value for n in ast.walk(ast.parse(text)) if isinstance(n,ast.Constant) and isinstance(n.value,str)]
assert 'Repeat A\u2013B' in constants and 'Backend-reported speed \u2014' in constants
assert any('\u00d7' in x for x in constants) and any('\u00b7' in x for x in constants)
assert not any('\u00c3' in x or '\u00e2\u20ac' in x for x in constants)
original_helper=(B/'original/desktop/capture_desktop/review_video.py').read_bytes()
assert original_helper==(B/'candidate-r1/desktop/capture_desktop/review_video.py').read_bytes()
r={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'status':'Static review supports runtime-only R1; final independent native acceptance pending','original':op,'candidate':np,'intervalHelper':hp,'originalMethods':len(a),'candidateMethods':len(b),'changedMethods':changed,'addedMethods':added,'byteAndAstUnchangedMethods':same,'originalDiscoveryContainmentClockHelperByteExact':True,'utf8':{'candidateLiteralCodepointsCorrect':True,'repeat':'Repeat A\u2013B','times':'\u00d7','emDash':'\u2014','middleDot':'\u00b7','mojibakeConstantsAbsent':True},'sourceReview':['Endpoints come from native integer media position and require0<=A<B<=duration; setA clearsB and disables repeat, valid setB disables repeat; rejectedB keeps the previous state.','The explicit play-request flag is retired before pause/hide/collapse/reset and before old media are stopped; stale player identity+generation rejects queued old callbacks.','The loop adjustment flag guards synchronous signal recursion around seek-toA/play, while the explicit play flag gates restart. Paused endpoint/rate/repeat changes do not call play.','Rate control requests one of four stated values and separately displays the native property; it does not claim measured exact rate.','Existing package discovery, local containment and media-clock helper are byte exact; ReviewScreen/event-browser/storage/capture APIs are outside this source delta.'],'qualificationBoundary':'Root read original widget/helper before runtime-only candidate/delta/guide, and did not read authored test bodies. The first full candidate run aborted; isolated looping passed; the later full-order cleanup-adapted run and literal-only receiver correction require their actual retained records. This static audit did not import Qt, execute product code, change source or claim a physical/decoder gate.'}
assert (B/'candidate-r1/desktop/capture_desktop/widgets_review_video.py').read_bytes()==new
out=(json.dumps(r,indent=2)+'\n').encode()
with (R/'ROOT-SOURCE-REVIEW-r1.json').open('xb') as f:f.write(out)
print(json.dumps({'path':str(R/'ROOT-SOURCE-REVIEW-r1.json'),'bytes':len(out),'sha256':hashlib.sha256(out).hexdigest(),'originalMethods':len(a),'candidateMethods':len(b),'changed':changed,'added':added,'unchanged':same,'utf8Correct':True},indent=2))
