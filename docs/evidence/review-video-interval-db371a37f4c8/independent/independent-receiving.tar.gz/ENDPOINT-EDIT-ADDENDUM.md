# Pre-candidate endpoint-edit clarification

Received from production after the independent original native baseline and before any candidate or author-test read.

Original CONTRACT.md remains SHA2569a927a89ec61da5556c241ab06190f75af66c0accbe45f5a1cc1e68e1187f11f; candidate-semantic-fixtures.json remains SHA256fba168086e20110dfef781d8763cb2fb56f3b9aa1a400ad4d8122d0f67352c65.

Production's public design clarification: valid A/B endpoint edits disable Repeat until the operator explicitly re-enables it. Invalid B preserves the previous valid interval AND its enabled state. Setting endpoints still must not start paused playback. Production will record this in the guide/claim before its qualified offer.

The independently frozen scenarios already enable Repeat explicitly after valid endpoint setup. The C1 invalid-B observation will include the existing enabled state. No prior assertion, fixture, native result or product source is rewritten. This is an additive pre-candidate specification, not a reinterpretation of a failed run.
