"""Independent CaptureSuite #103 candidate receiver; frozen semantic fixtures and original oracles precede candidate."""
from __future__ import annotations
import argparse, hashlib, json, os, pathlib, shutil, sys, time, traceback
from datetime import datetime, timezone
sys.dont_write_bytecode = True

def digest(path):
    b=path.read_bytes()
    return {"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),
            "git":hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()}

def manifest(root):
    return {p.relative_to(root).as_posix():digest(p) for p in sorted(root.rglob("*")) if p.is_file()}

def pinned(root, rows):
    actual={}
    for row in rows:
        p=root.joinpath(*pathlib.PurePosixPath(row["path"]).parts)
        got=digest(p)
        for key in ("bytes","sha256","git"):
            if key in row: assert got[key]==row[key], (str(p),key,got[key],row[key])
        actual[row["path"]]=got
    return actual

ap=argparse.ArgumentParser()
ap.add_argument("--admission",required=True)
ap.add_argument("--output",required=True)
args=ap.parse_args()
fixtures_path=pathlib.Path(__file__).resolve().parent/"candidate-semantic-fixtures.json"
assert hashlib.sha256(fixtures_path.read_bytes()).hexdigest()=="fba168086e20110dfef781d8763cb2fb56f3b9aa1a400ad4d8122d0f67352c65"
fixtures=json.loads(fixtures_path.read_bytes())
admission_path=pathlib.Path(args.admission).resolve()
admission=json.loads(admission_path.read_bytes())
assert admission["kind"]=="capturesuite-candidate-native-admission-v1"
assert sys.version_info[:2]==(3,12),sys.version
assert os.path.normcase(str(pathlib.Path(sys.executable).resolve()))==os.path.normcase(str(pathlib.Path(admission["python"]).resolve()))
source=pathlib.Path(admission["source_root"]).resolve()
fixture=pathlib.Path(admission["fixture_root"]).resolve()
source_before=pinned(source,admission["source_files"])
fixture_before=pinned(fixture,admission["fixture_files"])
out=pathlib.Path(args.output).resolve()
assert not out.exists()
assert shutil.disk_usage(out.parent).free>32*1024*1024
out.mkdir() # fresh run admission occurs before try/finally, never reuse an uncertain run
package=out/"package"
shutil.copytree(fixture,package)
package_before=manifest(package)
result={"schema":"capture-independent-candidate-native-v1","started":datetime.now(timezone.utc).isoformat(),
        "admission":digest(admission_path),"python":sys.version,"executable":sys.executable,
        "source_before":source_before,"fixture_before":fixture_before,"package_before":package_before,
        "groups":[],"events":[],"snapshots":[],"decoded_frames":[],"status":"RUNNING",
        "limits":["Qt widget grabs do not prove an onscreen GPU video surface.",
                  "Supplemental direct stale-callback stimuli are not exhaustive backend-race proof."]}
window=widget=app=None
parked=None
started=time.monotonic()
try:
    for relative in ("desktop","libs/python/capture_analysis","libs/python/capture_session",
                     "libs/python/capture_protocol","libs/python/capture_worker"):
        sys.path.insert(0,str(source/relative))
    from PySide6 import __version__ as pyside_version
    from PySide6.QtCore import Qt,QEvent,qVersion
    from PySide6.QtGui import QKeySequence,QShortcut
    from PySide6.QtWidgets import QApplication,QMainWindow,QPushButton,QToolButton,QComboBox
    from PySide6.QtTest import QTest
    from PySide6.QtMultimedia import QMediaPlayer
    from capture_desktop.widgets_review_video import RecordedVideoReview
    from capture_desktop.review_video import media_time
    from capture_desktop import theme
    import capture_desktop.widgets_review_video as module
    assert pathlib.Path(module.__file__).resolve()==source/"desktop/capture_desktop/widgets_review_video.py"
    app=QApplication([])
    result["qt"]={"pyside":pyside_version,"qt":qVersion(),"platform":app.platformName()}
    assert app.platformName()=="windows",result["qt"]
    theme.apply_theme(app,setting="dark")
    window=QMainWindow();window.setWindowTitle("Independent recorded-video interval receiving")
    widget=RecordedVideoReview();window.setCentralWidget(widget);window.resize(1020,780)
    shortcut_count=[0]
    shortcut=QShortcut(QKeySequence("Space"),window)
    shortcut.setContext(Qt.ShortcutContext.WindowShortcut)
    shortcut.activated.connect(lambda:shortcut_count.__setitem__(0,shortcut_count[0]+1))
    window.show();window.raise_();window.activateWindow()

    def wait(predicate,label,seconds=12):
        deadline=time.monotonic()+seconds
        while time.monotonic()<deadline:
            if predicate():return
            QTest.qWait(20)
        raise AssertionError(label)
    def quiet(ms=250):QTest.qWait(ms)
    def snap(label):
        p=widget._player
        x={"label":label,"t":time.monotonic()-started,"generation":widget._generation,
           "ready":widget._ready,"identity":widget._identity.text(),"status":widget._status.text(),
           "clock":widget._clock.text(),"play_enabled":widget._play.isEnabled(),"seek_enabled":widget._seek.isEnabled(),
           "play_text":widget._play.text(),"player":None if p is None else
           {"identity":id(p),"position":p.position(),"duration":p.duration(),"rate":p.playbackRate(),
            "state":p.playbackState().name,"media_status":p.mediaStatus().name,"seekable":p.isSeekable()}}
        x.update(interval={"A":widget._interval.start_ms,"B":widget._interval.end_ms,"enabled":widget._interval.enabled,"label":widget._interval_label.text()},rate_label=widget._rate_label.text(),requested_rate=widget._rate.currentData(),play_requested=widget._play_requested)
        result["snapshots"].append(x);return x
    def bind(p):
        for name in ("positionChanged","durationChanged","mediaStatusChanged","playbackStateChanged",
                     "playbackRateChanged","errorOccurred","seekableChanged"):
            getattr(p,name).connect(lambda *values,n=name,identity=id(p):result["events"].append(
                {"t":time.monotonic()-started,"player":identity,"signal":n,
                 "values":[v if isinstance(v,(str,int,float,bool)) else str(v) for v in values]}))
        def frame_seen(frame):
            if not frame.isValid():return
            x={"t":time.monotonic()-started,"width":frame.width(),"height":frame.height(),
               "start_us":frame.startTime(),"end_us":frame.endTime()}
            if not result["decoded_frames"]:
                image=frame.toImage()
                x["image_null"]=image.isNull()
                if not image.isNull():
                    x["saved"]=image.save(str(out/"candidate-decoded-frame.png"))
                    x["center_rgba"]=image.pixelColor(image.width()//2,image.height()//2).getRgb()
            result["decoded_frames"].append(x)
        widget._video.videoSink().videoFrameChanged.connect(frame_seen)
    def select(index):
        widget._choice.setCurrentIndex(index)
        if widget._player is not None:bind(widget._player)
    def stopped():
        return widget._player is not None and widget._player.playbackState()!=QMediaPlayer.PlaybackState.PlayingState
    def pause_plateau(label):
        wait(stopped,label+" stopped");quiet(180)
        p=widget._player;pos=p.position();quiet(300)
        assert abs(p.position()-pos)<=60,(label,pos,p.position())
        assert stopped();snap(label)
    A=fixtures["media"]["A_ms"];B=fixtures["media"]["B_ms"]
    invalidB=fixtures["media"]["invalid_B_ms"]
    def click(control):
        assert control.isVisible() and control.isEnabled(),(control.objectName(),control.isVisible(),control.isEnabled())
        QTest.mouseClick(control,Qt.MouseButton.LeftButton)
    def ready():return widget._player is not None and widget._ready and widget._player.isSeekable() and widget._player.duration()==2000
    def seek(ms):
        p=widget._player;assert p is not None and widget._seek.isEnabled()
        widget._seek.setValue(ms*10000//p.duration())
        expected=ms
        if p.playbackState()==QMediaPlayer.PlaybackState.PlayingState and widget._interval.enabled:
            if not widget._interval.start_ms<=ms<widget._interval.end_ms:expected=widget._interval.start_ms
        wait(lambda:abs(p.position()-expected)<=100,"native seek "+str(ms))
        if stopped():assert p.position()==expected,(ms,p.position())
    def interval(a,b,enabled):
        assert (widget._interval.start_ms,widget._interval.end_ms,widget._interval.enabled)==(a,b,enabled),snap("interval mismatch")
        assert widget._repeat.isChecked()==enabled
        assert (media_time(a) if a is not None else "—") in widget._interval_label.text()
        assert (media_time(b) if b is not None else "—") in widget._interval_label.text()
    def repeat(enabled):
        assert widget._repeat.isEnabled()
        if widget._repeat.isChecked()!=enabled:click(widget._repeat)
        assert widget._repeat.isChecked()==enabled
    def set_rate(rate):
        control=widget._rate
        index=control.findData(rate);assert index>=0 and control.isEnabled()
        control.setFocus();QTest.keyClick(control,Qt.Key.Key_Home)
        for _ in range(index):QTest.keyClick(control,Qt.Key.Key_Down)
        wait(lambda:control.currentData()==rate and widget._player.playbackRate()==rate,"native rate accepted")
        assert f"{rate:g}×" in widget._rate_label.text(),widget._rate_label.text()
    def play():
        assert stopped();click(widget._play)
        wait(lambda:widget._player.playbackState()==QMediaPlayer.PlaybackState.PlayingState,"explicit play")
    def pause(label):
        if not stopped():click(widget._play)
        pause_plateau(label)
    def endpoints(a,b):
        assert stopped();seek(a);click(widget._mark_a);interval(a,None,False)
        seek(b);click(widget._mark_b);interval(a,b,False);assert stopped()
    def wraps(count,a,b,label):
        p=widget._player;series=[];seen=0;previous=p.position()
        frame_start=len(result["decoded_frames"]);deadline=time.monotonic()+12
        while time.monotonic()<deadline and seen<count:
            quiet(20);position=p.position()
            series.append({"at":time.monotonic()-started,"position_ms":position,"state":p.playbackState().name,"media_status":p.mediaStatus().name})
            if previous>=b-250 and position<=a+150 and previous-position>=300:seen+=1
            previous=position
        result.setdefault("wrap_observations",[]).append({"label":label,"count":seen,"series":series,"decoded_frames":len(result["decoded_frames"])-frame_start})
        assert seen>=count,(label,seen)
        assert len(result["decoded_frames"])>frame_start
        assert p.playbackState()==QMediaPlayer.PlaybackState.PlayingState
    def defaults():
        interval(None,None,False)
        assert widget._rate.currentData()==1.0
        if widget._player is not None:assert widget._player.playbackRate()==1.0
        assert not widget._play_requested and stopped()
    quiet(150)
    assert widget._player is None
    widget.load_package(str(package),state="finalized")
    quiet(150);assert widget._player is None
    click(widget._toggle)
    result["inventory"]=[s.label for s in widget._segments]
    assert len(widget._segments)==4
    select(1);wait(ready,"candidate original media ready")
    p=widget._player;defaults()
    assert "sim.left <literal>" in widget._identity.text() and "front & camera" in widget._identity.text()
    endpoints(A,B);set_rate(0.5);assert stopped();repeat(True);interval(A,B,True);assert stopped()
    seek(invalidB);click(widget._mark_b);interval(A,B,True);assert stopped()
    seek(0);quiet(200);assert stopped() and p.position()==0
    snap("C1 paused valid interval and invalid B retained")
    result["groups"].append("C1 paused setup and invalid endpoint preservation")

    play();assert A<=p.position()<B
    wraps(2,A,B,"C2 interior interval")
    pause("C2 pause");held=p.position();quiet(500);assert stopped() and abs(p.position()-held)<=60
    play();pause("C2 explicit resume pause")
    result["groups"].append("C2 native interval wraps and explicit pause intent")

    seek(1600);assert p.position()==1600 and stopped()
    play();assert A<=p.position()<B
    seek(0);assert A<=p.position()<B and not stopped()
    before=p.position();repeat(False)
    assert not stopped() and abs(p.position()-before)<=100
    wait(lambda:p.position()>B and not stopped(),"disabled repeat crosses prior B",5)
    pause("C3 after disabled repeat");held=p.position();click(widget._clear_interval)
    interval(None,None,False);assert stopped() and p.position()==held
    endpoints(A,B);repeat(True);play();before=p.position();click(widget._clear_interval)
    interval(None,None,False);assert not stopped() and abs(p.position()-before)<=100
    pause("C3 clear while playing");result["groups"].append("C3 outside seek, disable and clear preserve intent")

    result["rate_observations"]=[]
    for rate in fixtures["groups"][3]["rates"]:
        seek(100);set_rate(rate);quiet(180)
        assert stopped() and p.position()==100
        play();quiet(100);start=time.monotonic();first=p.position();frames=len(result["decoded_frames"]);samples=[]
        while (time.monotonic()-start)*1000<600:
            samples.append({"wall_ms":(time.monotonic()-start)*1000,"position_ms":p.position()});quiet(20)
        wall=(time.monotonic()-start)*1000;advance=p.position()-first;expected=wall*rate
        tolerance=max(100,expected*.25)
        observation={"rate":rate,"actual_rate":p.playbackRate(),"wall_ms":wall,"start_position_ms":first,
          "end_position_ms":p.position(),"advance_ms":advance,"expected_ms":expected,"tolerance_ms":tolerance,
          "frames_during_sample":len(result["decoded_frames"])-frames,"samples":samples,
          "state":p.playbackState().name,"status":p.mediaStatus().name}
        result["rate_observations"].append(observation)
        assert advance>0 and abs(advance-expected)<=tolerance,observation
        assert not stopped() and p.mediaStatus()!=QMediaPlayer.MediaStatus.EndOfMedia
        assert len(result["decoded_frames"])>frames
        pause("C4 rate "+str(rate))
    rates=[r["advance_ms"]/r["wall_ms"] for r in result["rate_observations"]]
    assert all(a<b for a,b in zip(rates,rates[1:])),rates
    result["groups"].append("C4 four UI speeds, native media progression and decoded frames")

    set_rate(1.0);endpoints(A,2000);repeat(True);seek(2000)
    assert stopped() and p.position()==2000
    quiet(500);assert stopped() and p.position()==2000
    play();wraps(2,A,2000,"C5 full media duration boundary")
    click(widget._toggle);pause_plateau("C5 collapsed")
    click(widget._toggle);pause_plateau("C5 expanded no resume")
    interval(A,2000,True)
    play();window.hide();pause_plateau("C5 hidden")
    window.show();pause_plateau("C5 shown no resume")
    interval(A,2000,True)
    result["groups"].append("C5 native end repeat, collapse/hide pause and no implicit resume")

    endpoints(A,B);set_rate(0.5);repeat(True)
    widget._repeat.setFocus();QTest.keyClick(widget._repeat,Qt.Key.Key_Space)
    interval(A,B,False);assert stopped() and shortcut_count[0]==0
    QTest.keyClick(widget._repeat,Qt.Key.Key_Space);interval(A,B,True)
    assert shortcut_count[0]==0
    assert window.grab().save(str(out/"candidate-controls-dark.png"))
    # Public pre-candidate clarification: a fresh valid A clears B and disables repeat.
    widget._mark_a.setFocus();seek(A);QTest.keyClick(widget._mark_a,Qt.Key.Key_Space)
    interval(A,None,False);assert shortcut_count[0]==0 and stopped()
    seek(B);widget._mark_b.setFocus();QTest.keyClick(widget._mark_b,Qt.Key.Key_Space)
    interval(A,B,False);assert shortcut_count[0]==0 and stopped()
    repeat(True);widget._clear_interval.setFocus();QTest.keyClick(widget._clear_interval,Qt.Key.Key_Space)
    interval(None,None,False);assert shortcut_count[0]==0 and stopped()
    endpoints(A,B);repeat(True);set_rate(0.5)
    snap("C7 focused keyboard controls preserve checkpoint shortcut")
    theme.apply_theme(app,setting="light");quiet(100)
    assert window.grab().save(str(out/"candidate-controls-light.png"))
    theme.apply_theme(app,setting="dark")
    result["groups"].append("C7 actual controls, identity, endpoint labels and keyboard ownership")

    old=p;generation=widget._generation
    select(2);wait(ready,"different segment ready");p=widget._player
    assert p is not old and widget._generation>generation;defaults()
    select(1);wait(ready,"original segment ready again");p=widget._player;defaults()
    endpoints(A,B);set_rate(0.5);repeat(True)
    old=p;generation=widget._generation
    click(widget._reload);assert widget._player is not old;bind(widget._player)
    wait(ready,"fresh reload ready");p=widget._player;defaults()
    before=snap("C6 before supplemental stale stimuli")
    widget._sync(old,generation);widget._failed(old,generation,"supplemental retired error")
    widget._sync(p,generation)
    after=snap("C6 after supplemental stale stimuli")
    for key in ("generation","ready","identity","status","clock","play_text","player","interval","rate_label","requested_rate","play_requested"):
        assert before[key]==after[key],key
    endpoints(A,B);set_rate(0.5);repeat(True)
    invalid=next(i+1 for i,s in enumerate(widget._segments) if s.relative_path.endswith("/invalid.mkv"))
    select(invalid);wait(lambda:widget._player is None and not widget._play.isEnabled(),"invalid decoder refusal")
    interval(None,None,False);assert widget._rate.currentData()==1.0 and not widget._rate.isEnabled()
    assert "Cannot play" in widget._status.text();snap("C6 invalid decoder retirement")
    target=package/widget._segments[0].relative_path;parked=target.with_suffix(".receiver-held")
    target.rename(parked);select(1);quiet(120)
    assert widget._player is None and not widget._play.isEnabled()
    interval(None,None,False);assert "Could not open" in widget._status.text()
    parked.rename(target);parked=None
    click(widget._reload);wait(ready,"restored retained bytes");p=widget._player;defaults()
    endpoints(A,B);set_rate(0.5);repeat(True)
    widget.reset();quiet(150)
    interval(None,None,False)
    assert widget._player is None and not widget._play.isEnabled() and not widget._seek.isEnabled() and not widget._rate.isEnabled()
    assert widget._rate.currentData()==1.0
    snap("C6 reset")
    result["groups"].append("C6 segment/reload/error/reset retirement and original bytes")
    result["shortcut_count"]=shortcut_count[0]
    result["status"]="PASS"
except BaseException:
    result["status"]="FAIL";result["failure"]=traceback.format_exc()
finally:
    if parked is not None and parked.exists():parked.rename(parked.with_suffix(".mkv"))
    try:
        if widget is not None:widget.reset()
        if window is not None:window.close();window.deleteLater()
        if app is not None:app.sendPostedEvents(None,QEvent.Type.DeferredDelete);app.processEvents()
    except BaseException:result["cleanup_error"]=traceback.format_exc();result["status"]="FAIL"
    try:
        result["source_after"]=pinned(source,admission["source_files"])
        result["fixture_after"]=pinned(fixture,admission["fixture_files"])
        result["package_after"]=manifest(package)
        assert result["source_after"]==source_before
        assert result["fixture_after"]==fixture_before
        assert result["package_after"]==package_before
        result["all_source_fixture_package_bytes_unchanged"]=True
    except BaseException:result["hash_error"]=traceback.format_exc();result["status"]="FAIL"
    result["finished"]=datetime.now(timezone.utc).isoformat()
    result["elapsed_seconds"]=time.monotonic()-started
    with (out/"receipt.json").open("x",encoding="utf-8") as f:
        json.dump(result,f,indent=2);f.write("\n");f.flush();os.fsync(f.fileno())
print(json.dumps({"status":result["status"],"groups":result["groups"],"receipt":str(out/"receipt.json")}))
sys.exit(0 if result["status"]=="PASS" else 1)
