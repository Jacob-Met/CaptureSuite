"""Independent original-only CaptureSuite #103 native baseline; never imports candidate tests."""
from __future__ import annotations
import argparse, hashlib, json, os, pathlib, shutil, sys, time, traceback
from datetime import datetime, timezone

def digest(path):
    b=path.read_bytes()
    return {"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),
            "git":hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()}

def manifest(root):
    return {p.relative_to(root).as_posix():digest(p) for p in sorted(root.rglob("*")) if p.is_file()}

def pinned(root, rows):
    actual={}
    for row in rows:
        p=root.joinpath(*pathlib.PurePosixPath(row["path"]).parts)
        got=digest(p)
        for key in ("bytes","sha256","git"):
            if key in row: assert got[key]==row[key], (str(p),key,got[key],row[key])
        actual[row["path"]]=got
    return actual

ap=argparse.ArgumentParser()
ap.add_argument("--admission",required=True)
ap.add_argument("--output",required=True)
args=ap.parse_args()
admission_path=pathlib.Path(args.admission).resolve()
admission=json.loads(admission_path.read_bytes())
assert admission["kind"]=="capturesuite-original-native-admission-v1"
assert sys.version_info[:2]==(3,12),sys.version
assert os.path.normcase(str(pathlib.Path(sys.executable).resolve()))==os.path.normcase(str(pathlib.Path(admission["python"]).resolve()))
source=pathlib.Path(admission["source_root"]).resolve()
fixture=pathlib.Path(admission["fixture_root"]).resolve()
source_before=pinned(source,admission["source_files"])
fixture_before=pinned(fixture,admission["fixture_files"])
out=pathlib.Path(args.output).resolve()
assert not out.exists()
assert shutil.disk_usage(out.parent).free>32*1024*1024
out.mkdir() # fresh run admission occurs before try/finally, never reuse an uncertain run
package=out/"package"
shutil.copytree(fixture,package)
package_before=manifest(package)
result={"schema":"capture-independent-original-native-v1","started":datetime.now(timezone.utc).isoformat(),
        "admission":digest(admission_path),"python":sys.version,"executable":sys.executable,
        "source_before":source_before,"fixture_before":fixture_before,"package_before":package_before,
        "groups":[],"events":[],"snapshots":[],"decoded_frames":[],"status":"RUNNING",
        "limits":["Qt widget grabs do not prove an onscreen GPU video surface.",
                  "Supplemental direct stale-callback stimuli are not exhaustive backend-race proof."]}
window=widget=app=None
parked=None
started=time.monotonic()
try:
    for relative in ("desktop","libs/python/capture_analysis","libs/python/capture_session",
                     "libs/python/capture_protocol","libs/python/capture_worker"):
        sys.path.insert(0,str(source/relative))
    from PySide6 import __version__ as pyside_version
    from PySide6.QtCore import Qt,QEvent,qVersion
    from PySide6.QtGui import QKeySequence,QShortcut
    from PySide6.QtWidgets import QApplication,QMainWindow,QPushButton,QToolButton,QComboBox
    from PySide6.QtTest import QTest
    from PySide6.QtMultimedia import QMediaPlayer
    from capture_desktop.widgets_review_video import RecordedVideoReview
    from capture_desktop.review_video import media_time
    from capture_desktop import theme
    import capture_desktop.widgets_review_video as module
    assert pathlib.Path(module.__file__).resolve()==source/"desktop/capture_desktop/widgets_review_video.py"
    app=QApplication([])
    result["qt"]={"pyside":pyside_version,"qt":qVersion(),"platform":app.platformName()}
    assert app.platformName()=="windows",result["qt"]
    theme.apply_theme(app,setting="dark")
    window=QMainWindow();window.setWindowTitle("Independent original recorded-video baseline")
    widget=RecordedVideoReview();window.setCentralWidget(widget);window.resize(1020,780)
    shortcut_count=[0]
    shortcut=QShortcut(QKeySequence("Space"),window)
    shortcut.setContext(Qt.ShortcutContext.WindowShortcut)
    shortcut.activated.connect(lambda:shortcut_count.__setitem__(0,shortcut_count[0]+1))
    window.show();window.raise_();window.activateWindow()

    def wait(predicate,label,seconds=12):
        deadline=time.monotonic()+seconds
        while time.monotonic()<deadline:
            if predicate():return
            QTest.qWait(20)
        raise AssertionError(label)
    def quiet(ms=250):QTest.qWait(ms)
    def snap(label):
        p=widget._player
        x={"label":label,"t":time.monotonic()-started,"generation":widget._generation,
           "ready":widget._ready,"identity":widget._identity.text(),"status":widget._status.text(),
           "clock":widget._clock.text(),"play_enabled":widget._play.isEnabled(),"seek_enabled":widget._seek.isEnabled(),
           "play_text":widget._play.text(),"player":None if p is None else
           {"identity":id(p),"position":p.position(),"duration":p.duration(),"rate":p.playbackRate(),
            "state":p.playbackState().name,"media_status":p.mediaStatus().name,"seekable":p.isSeekable()}}
        result["snapshots"].append(x);return x
    def bind(p):
        for name in ("positionChanged","durationChanged","mediaStatusChanged","playbackStateChanged",
                     "playbackRateChanged","errorOccurred","seekableChanged"):
            getattr(p,name).connect(lambda *values,n=name,identity=id(p):result["events"].append(
                {"t":time.monotonic()-started,"player":identity,"signal":n,
                 "values":[v if isinstance(v,(str,int,float,bool)) else str(v) for v in values]}))
        def frame_seen(frame):
            if not frame.isValid():return
            x={"t":time.monotonic()-started,"width":frame.width(),"height":frame.height(),
               "start_us":frame.startTime(),"end_us":frame.endTime()}
            if not result["decoded_frames"]:
                image=frame.toImage()
                x["image_null"]=image.isNull()
                if not image.isNull():
                    x["saved"]=image.save(str(out/"original-decoded-frame.png"))
                    x["center_rgba"]=image.pixelColor(image.width()//2,image.height()//2).getRgb()
            result["decoded_frames"].append(x)
        widget._video.videoSink().videoFrameChanged.connect(frame_seen)
    def select(index):
        widget._choice.setCurrentIndex(index)
        if widget._player is not None:bind(widget._player)
    def stopped():
        return widget._player is not None and widget._player.playbackState()!=QMediaPlayer.PlaybackState.PlayingState
    def pause_plateau(label):
        wait(stopped,label+" stopped");quiet(180)
        p=widget._player;pos=p.position();quiet(300)
        assert abs(p.position()-pos)<=60,(label,pos,p.position())
        assert stopped();snap(label)
    quiet(150)
    assert widget._player is None
    widget.load_package(str(package),state="finalized")
    quiet(180);assert widget._player is None
    QTest.mouseClick(widget._toggle,Qt.MouseButton.LeftButton)
    inventory=[x.label for x in widget._segments]
    result["inventory"]=inventory;assert len(inventory)==4
    result["original_controls"]={"buttons":[b.text() for cls in (QPushButton,QToolButton) for b in widget.findChildren(cls)],
                                 "comboboxes":[b.accessibleName() for b in widget.findChildren(QComboBox)]}
    assert len(widget.findChildren(QComboBox))==1
    result["groups"].append("inventory and explicit native control baseline")
    select(1);wait(lambda:widget._ready and widget._player.duration()>0,"native decoder ready")
    p=widget._player
    assert stopped() and p.isSeekable() and p.hasVideo()
    assert p.playbackRate()==1.0
    assert "sim.left <literal>" in widget._identity.text() and "front & camera" in widget._identity.text()
    result["duration_ms"]=p.duration();snap("selected idle")
    window.grab().save(str(out/"original-controls.png"))
    QTest.mouseClick(widget._play,Qt.MouseButton.LeftButton)
    wait(lambda:p.playbackState()==QMediaPlayer.PlaybackState.PlayingState and p.position()>=300,"native progression")
    widget._play.setFocus();QTest.keyClick(widget._play,Qt.Key.Key_Space)
    pause_plateau("keyboard pause")
    assert shortcut_count[0]==0,shortcut_count
    assert result["decoded_frames"],"no native decoded frame observed"
    result["groups"].append("real progression, decoded frame and focused Space pause")
    positions=[]
    for value in (2000,6000,3333):
        widget._seek.setValue(value)
        expected=p.duration()*value//10000
        wait(lambda:p.position()==expected,"exact native paused seek")
        assert stopped()
        assert media_time(expected) in widget._clock.text()
        positions.append({"slider":value,"expected_ms":expected,"actual_ms":p.position(),"clock":widget._clock.text()})
    result["seek_calibration"]=positions
    result["groups"].append("exact segment-local integer seek calibration")
    QTest.mouseClick(widget._play,Qt.MouseButton.LeftButton)
    wait(lambda:p.playbackState()==QMediaPlayer.PlaybackState.PlayingState,"play before collapse")
    QTest.mouseClick(widget._toggle,Qt.MouseButton.LeftButton);pause_plateau("collapsed")
    QTest.mouseClick(widget._toggle,Qt.MouseButton.LeftButton);pause_plateau("expanded no resume")
    QTest.mouseClick(widget._play,Qt.MouseButton.LeftButton)
    wait(lambda:p.playbackState()==QMediaPlayer.PlaybackState.PlayingState,"play before hide")
    window.hide();pause_plateau("hidden")
    window.show();pause_plateau("shown no resume")
    result["groups"].append("collapse and hide pause without implicit resume")
    old=p;old_generation=widget._generation
    QTest.mouseClick(widget._reload,Qt.MouseButton.LeftButton)
    assert widget._player is not old
    bind(widget._player);wait(lambda:widget._ready,"reload ready")
    assert widget._generation>old_generation and stopped()
    before=snap("reload before explicit stale stimuli")
    widget._sync(old,old_generation);widget._failed(old,old_generation,"retired synthetic error")
    widget._sync(widget._player,old_generation)
    after=snap("reload after explicit stale stimuli")
    for key in ("generation","ready","identity","status","clock","play_text","player"):
        assert before[key]==after[key],key
    result["groups"].append("fresh reload and unchanged retired callback guards")
    invalid=next(i+1 for i,s in enumerate(widget._segments) if s.relative_path.endswith("/invalid.mkv"))
    select(invalid)
    wait(lambda:widget._player is None and not widget._play.isEnabled(),"real invalid-media refusal")
    assert "Cannot play" in widget._status.text();snap("invalid media")
    target=package/widget._segments[0].relative_path
    parked=target.with_suffix(".receiver-held")
    target.rename(parked)
    select(1);quiet(120)
    assert widget._player is None and not widget._play.isEnabled()
    assert "Could not open" in widget._status.text();snap("missing after inventory")
    parked.rename(target);parked=None
    QTest.mouseClick(widget._reload,Qt.MouseButton.LeftButton)
    wait(lambda:widget._ready,"restored original file reload")
    assert stopped()
    result["groups"].append("actual invalid and temporarily missing owned media, restored reload")
    widget.reset();quiet(150)
    assert widget._player is None and not widget._play.isEnabled() and not widget._seek.isEnabled()
    snap("reset");result["groups"].append("package reset retires playback")
    result["status"]="PASS"
except BaseException:
    result["status"]="FAIL";result["failure"]=traceback.format_exc()
finally:
    if parked is not None and parked.exists():parked.rename(parked.with_suffix(".mkv"))
    try:
        if widget is not None:widget.reset()
        if window is not None:window.close();window.deleteLater()
        if app is not None:app.sendPostedEvents(None,QEvent.Type.DeferredDelete);app.processEvents()
    except BaseException:result["cleanup_error"]=traceback.format_exc();result["status"]="FAIL"
    try:
        result["source_after"]=pinned(source,admission["source_files"])
        result["fixture_after"]=pinned(fixture,admission["fixture_files"])
        result["package_after"]=manifest(package)
        assert result["source_after"]==source_before
        assert result["fixture_after"]==fixture_before
        assert result["package_after"]==package_before
        result["all_source_fixture_package_bytes_unchanged"]=True
    except BaseException:result["hash_error"]=traceback.format_exc();result["status"]="FAIL"
    result["finished"]=datetime.now(timezone.utc).isoformat()
    result["elapsed_seconds"]=time.monotonic()-started
    with (out/"receipt.json").open("x",encoding="utf-8") as f:
        json.dump(result,f,indent=2);f.write("\n");f.flush();os.fsync(f.fileno())
print(json.dumps({"status":result["status"],"groups":result["groups"],"receipt":str(out/"receipt.json")}))
sys.exit(0 if result["status"]=="PASS" else 1)
