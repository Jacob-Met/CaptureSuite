"""Final read-only receiving custody audit; no GUI, imports, services or source changes."""
import pathlib,json,hashlib,time,datetime,shutil,os
b=pathlib.Path('D:/Hamon/receiving/capture-video-repeat-db371a37f4c8')
def pin(p):
 x=p.read_bytes();return {'bytes':len(x),'sha256':hashlib.sha256(x).hexdigest(),'git':hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest()}
def exact(root,rows):
 for r in rows:
  got=pin(root/r['path'])
  assert all(got[k]==r[k] for k in ('bytes','sha256','git') if k in r),(r['path'],got)
 return len(rows)
start=time.monotonic()
original=json.loads((b/'native-admission-r1.json').read_bytes())
candidate=json.loads((b/'candidate-admission-r1.json').read_bytes())
out={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'RUNNING',
     'original_files':exact(pathlib.Path(original['source_root']),original['source_files']),
     'candidate_files':exact(pathlib.Path(candidate['source_root']),candidate['source_files']),
     'fixture_files':exact(pathlib.Path(original['fixture_root']),original['fixture_files'])}
mp=b/'runtime-files-frozen-r1.json';assert pin(mp)['sha256']=='d57d68032c6949a7d28813e62392d211c111828c0e7207682161d231df9217bb'
runtime=json.loads(mp.read_bytes());rr=pathlib.Path(runtime['root']);names=set()
for row in runtime['files']:
 p=rr/row['path'];got=pin(p)
 assert all(got[k]==row[k] for k in ('bytes','sha256')),row['path']
 names.add(row['path'])
 assert time.monotonic()-start<90,'bounded final runtime audit'
actual={p.relative_to(rr).as_posix() for group in ('python','venv') for p in (rr/group).rglob('*') if p.is_file()}
assert actual==names,{'extra':sorted(actual-names),'missing':sorted(names-actual)}
out['runtime_files']=len(names);out['runtime_bytes']=sum(x['bytes'] for x in runtime['files'])
out['full_runtime_file_set_and_bytes_exact']=True
expected={'CONTRACT.md':'9a927a89ec61da5556c241ab06190f75af66c0accbe45f5a1cc1e68e1187f11f',
'candidate-semantic-fixtures.json':'fba168086e20110dfef781d8763cb2fb56f3b9aa1a400ad4d8122d0f67352c65',
'ENDPOINT-EDIT-ADDENDUM.md':'c9857f77539550fee9918483be3fbf72f12721e429f664ebcadd68bf8617304a',
'SET-A-CLEAR-B-ADDENDUM.md':'6672a4331cb9d50590bb1841966b05f85a68dfebc2935a6fc735e89194c9364f',
'original-run-r1/native/receipt.json':'41f2e731b07bf88ababe675ba11490dfe6b2e4a0b6f3ea5578724880d29133d5',
'original-rates-run-r1/native/receipt.json':'aa54eb2981a7f0842b1f2f7ce57b5920454e24bbadb62e70a9a1ec590183b21b',
'candidate-run-r1/native/receipt.json':'6578f3abf013824687858c0526eac102628653cedf2688796493c83424face9c'}
out['pins']={}
for name,sha in expected.items():
 p=b/name; got=pin(p);assert got['sha256']==sha,name;out['pins'][name]=got
out['captures']={p.relative_to(b).as_posix():pin(p) for p in sorted((b/'candidate-run-r1/native').glob('*.png'))}
out['root_static_review']=pin(b/'ROOT-SOURCE-REVIEW-r1.json')
assert out['root_static_review']['sha256']=='c2f5255c2e199deba90e7dad80e66a7dade0d743612b95719ff9aff2c9ff9659'
out['root_static_review_authorship']='Root /root, independently staged after source review; not receiver-authored.'
out['status']='PASS';out['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();out['elapsed_seconds']=time.monotonic()-start
with (b/'FINAL-AUDIT-r1.json').open('x',encoding='utf-8') as f:json.dump(out,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps({'status':out['status'],'original':out['original_files'],'candidate':out['candidate_files'],'fixtures':out['fixture_files'],'runtime':out['runtime_files'],'elapsed_seconds':out['elapsed_seconds'],'audit':pin(b/'FINAL-AUDIT-r1.json')}))
