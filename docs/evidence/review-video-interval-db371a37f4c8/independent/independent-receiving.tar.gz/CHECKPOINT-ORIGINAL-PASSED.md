# CaptureSuite #103 independent receiver checkpoint

Receiver root: D:/Hamon/receiving/capture-video-repeat-db371a37f4c8.
Author root: D:/Hamon/worktrees/capture-video-repeat-db371a37f4c8-production.
Device MSI9ea77fe9-bb87-46e0-a5a8-8b3e25f6ff7e; base orchestration Python C:/Users/Veria/AppData/Local/Programs/Python/Python311/python.exe.
Real admitted product Python: author-root/venv/Scripts/python.exe,3.12.10,Qt6.12.0.

Contract9a927a89ec61da5556c241ab06190f75af66c0accbe45f5a1cc1e68e1187f11f is frozen before candidate/test reads.
Semantic fixturesfba168086e20110dfef781d8763cb2fb56f3b9aa1a400ad4d8122d0f67352c65 frozen03:02:42 after actual original calibration.
Endpoint edit addendumc9857f77539550fee9918483be3fbf72f12721e429f664ebcadd68bf8617304a: valid endpoint changes disable repeat until re-enabled; invalidB preserves interval+enabled state. Public author comment6073434029 reported, not yet directly read.

Original canonical main3960c0c756cd4e9facbde0d76eaaa3c31ab7c167/tree d1af33caaf7154e83def1dab035920907d417e8d,1280leaves.
All121 offered original runtime source files728095B independently exact; own original-source-admission-r1.json SHAc7869dc39a797fcaca402d0d1071e07c9095df7efa54049ccf2b4c0b022ed283.
Nine canonical fixture files16473B are frozen independently in original-fixture/; manifest b5e8392e52f975ecabd806d362cb325c468cb0fab5353c5b04917e44e461b1e0.
No candidate or author tests have been read.

New private runtime full18,539files/1,171,247,985B admitted exact; frozen runtime manifest d57d68032c6949a7d28813e62392d211c111828c0e7207682161d231df9217bb.
Own runtime-admission-r1.json SHA9e50beefbd0016bf99c64e415df55690284f8ea3191258db7d7a97991be2be58.
Actual PySide extensions and loaded CPython/Qt DLLs are byte-bound in native-admission-r1.json SHA30eb90e3a985d1e1ff88b0542832fa315a9e5b1d530eb10d6a88329cfa270fb8.
No registry/global install from receiver; earlier unavailable donors and supported-Python mismatch preserved.

Original native baseline PASS seven groups, original-run-r1/native/receipt.json SHA41f2e731b07bf88ababe675ba11490dfe6b2e4a0b6f3ea5578724880d29133d5.
Windows native platform, no Qt env overrides;2000ms fixture, exact400/1200/666ms paused seek+clock;6native decoded frames, first160x120 red(255,0,0,255); real play, Space pause, collapse/hide, fresh reload/stale guards, invalid/missing+restored media, reset.
All121source,9fixture and private package files unchanged.
Child19092 exit0, wrapper26596 finished02:58:48; observed metadata/child/root launcher PIDs absent on delayed02:59:54 census.
Original controls image8a32ec5b9bfb6ccdda36bf7c8df5a3f684653bb34010e295c5c15d50bb5a055b directly viewed: controls/identity/clock visible, no new loop/rate UI. QVideoWidget grab does not prove onscreen GPU pixels; actual decoded red frame saved separately.

Next:
1. Production owns Qt window for its author candidate run. At03:14:41 its first remote launch had no observed native effects (run dir/process/receipts absent), and it is making a guarded retry; do not inspect/replay its operation.
2. My original-only rate probe is staged and UNLAUNCHED. Driver original-rates-r1.py5578B SHA7b02802eaa6a4bdbffa81e8fea7f9af9b7084b6861e67e82f0ff916540068d5a; wrapper run-original-rates-r1.py4171B SHA9c5ae981599b231d9e5c651d8a851d10a5ed3823cd0d58f87366808a085c45c0.
3. After actual production Qt closure, run once using base orchestration Python -B wrapper --admission native-admission-r1.json --run original-rates-run-r1. Newdir guard,90s child bound,512MiB memory/64MiB disk floor. It tests actual public backend rates0.25/.5/1/2 on unchanged original with native frame/position/monotonic measurements and pause preservation; no candidate UI claim or settled baseline replay.
4. Preserve/reconcile receipt, stdout/stderr and actual child PIDs after every uncertain response. The remote tool often drops completed sessions; do not replay. Read durable receipt and census instead.
5. Then admit complete candidate runtime manifest/source-only offer, author test bodies withheld. Bind semantic fixtures to UI names without deriving assertions from implementation. Perform source audit, actual native loops/rates/lifecycle/keyboard receiving, keep all failures exact. No Actions/ref/PR/merge.

Staging negatives retained: first Python -c quoting lost double quotes before ast.parse; corrected command did not modify driver. github_fetch refuses binary UTF-8; purpose-built github_fetch_file encoding=base64 retrieved exact MKVs. Actual original runtime gates passed; these transport issues were not product defects.
