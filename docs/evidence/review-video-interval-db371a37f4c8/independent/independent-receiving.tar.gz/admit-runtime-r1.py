"""Read-only independent admission of the offered private CPython/Qt byte closure."""
from __future__ import annotations
import pathlib,json,hashlib,datetime,time,os,subprocess,sys
sys.dont_write_bytecode=True
r=pathlib.Path('D:/Hamon/receiving/capture-video-repeat-db371a37f4c8')
author=pathlib.Path('D:/Hamon/worktrees/capture-video-repeat-db371a37f4c8-production')
mp=author/'environment-final-r1/runtime-files.json'
raw=mp.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='d57d68032c6949a7d28813e62392d211c111828c0e7207682161d231df9217bb'
d=json.loads(raw)
assert pathlib.Path(d['root']).resolve()==author.resolve() and not d['links']
assert len(d['files'])==18539 and sum(x['bytes'] for x in d['files'])==1171247985
began=time.monotonic();seen=set();groups=set();counts={}
for row in d['files']:
 rel=pathlib.PurePosixPath(row['path'])
 assert not rel.is_absolute() and '..' not in rel.parts
 p=author.joinpath(*rel.parts)
 assert p.resolve().is_relative_to(author.resolve()) and not p.is_symlink()
 assert row['path'] not in seen
 seen.add(row['path']);groups.add(rel.parts[0]);counts[rel.parts[0]]=counts.get(rel.parts[0],0)+1
 b=p.read_bytes()
 assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],row['path']
 assert time.monotonic()-began<90,'runtime byte admission deadline'
actual={p.relative_to(author).as_posix() for group in groups for p in (author/group).rglob('*') if p.is_file()}
assert actual==seen,{'extra':sorted(actual-seen),'missing':sorted(seen-actual)}
lock=(author/'environment-deps-r1/requirements.lock').read_bytes()
assert hashlib.sha256(lock).hexdigest()=='1555072d6bd1c3b5244870b10f219bca0b4b7ef38ed3550c79d35f787ffa7fc6'
python=author/'venv/Scripts/python.exe'
probe="import sys,json,platform,importlib.metadata,PySide6; from PySide6.QtCore import qVersion; from PySide6.QtMultimedia import QMediaPlayer; print(json.dumps({'executable':sys.executable,'python':sys.version,'qt':qVersion(),'pyside':PySide6.__version__,'platform':platform.platform(),'prefix':sys.prefix,'base_prefix':sys.base_prefix,'distributions':sorted([{'name':d.metadata['Name'],'version':d.version} for d in importlib.metadata.distributions()],key=lambda x:x['name'].lower())}))"
result=subprocess.run([str(python),'-B','-c',probe],capture_output=True,timeout=20)
assert result.returncode==0,result.stderr.decode(errors='replace')
observed=json.loads(result.stdout)
assert observed['python'].startswith('3.12.10 ') and observed['pyside']=='6.12.0' and observed['qt']=='6.12.0'
expected=json.loads((author/'environment-deps-r1/versions.stdout').read_bytes())
normalize=lambda x:x.lower().replace('_','-')
assert {normalize(x['name']):x['version'] for x in expected}=={normalize(x['name']):x['version'] for x in observed['distributions']}
out={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS','runtime_root':str(author),'python':str(python),
     'files':len(seen),'bytes':1171247985,'groups':counts,'all_runtime_file_names_bytes_sha256_exact':True,
     'manifest_sha256':hashlib.sha256(raw).hexdigest(),'lock_sha256':hashlib.sha256(lock).hexdigest(),
     'observed':observed,'native_import_probe_exit':result.returncode,'native_import_probe_stderr':result.stderr.decode(errors='replace'),
     'elapsed_seconds':time.monotonic()-began,'no_gui_player_or_candidate_launched':True}
with (r/'runtime-admission-r1.json').open('x',encoding='utf-8') as f:json.dump(out,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
with (r/'runtime-files-frozen-r1.json').open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
print(json.dumps(out))
