# CaptureSuite #103 independent receiving contract

Frozen from original source and public behavior before any candidate or author-test read.
Receiver: estate-db371a37f4c8 / longwater_author_recovery.
Author: production. Root retains final acceptance.
Native namespace: D:/Hamon/receiving/capture-video-repeat-db371a37f4c8.

## Authority and source
Repository: Jacob-Met/CaptureSuite; issue103 and pre-implementation comment6073112744.
Original main3960c0c756cd4e9facbde0d76eaaa3c31ab7c167, complete1280-leaf tree d1af33caaf7154e83def1dab035920907d417e8d.
Original widget desktop/capture_desktop/widgets_review_video.py blob545df3c2f1d4992909186a13c94134143bc47826.
Original identity/clock helper review_video.py blob49c710c21724a4734017afa04b6324cab7304333.
Original themee309ce92bf66f65ca7c111698e1f536f05e4dca9; discoverd5c4fa7e06ac6e9139ebfc78fade90a3df5e451a; types2adf26816e0ef9e84e6763cf8bbff69d64697949.
Read-only source review: the widget creates one native QMediaPlayer and QVideoWidget for an explicit selection, keeps media time separate from session time, uses identity AND generation for callbacks, pauses on hide/collapse, and has no interval/speed controls. This is a source observation, not yet an executed baseline.

## Runtime admission before baseline
Project desktop/pyproject.toml requires CPython>=3.12,<3.13 and PySide6>=6.6,<7.
Independently read runtime/version/dependency provenance and retain usable byte identities before executing original source. No fake Qt, fake player, synthetic playback callbacks, or alternate unsupported Python may stand in for actual media/UI qualification.
Read the actual original import closure, including package initializers. capture_analysis eagerly imports jobs/qc; bypassing that initializer would be a limited isolated-module probe, not complete product admission.
Use an isolated original snapshot and a private synthetic finalized package. Preserve exact source, fixture and package bytes before/after. No user media, camera, capture daemon, live package, shared source/runtime mutation, Actions, refs, PRs or merge.
A private supported runtime may be provisioned by production under root's explicit instruction; the receiver admits it independently. Current MSI donor negatives remain historical facts, not a perpetual assumption.

## Original native baseline
On the same admitted native Qt environment later used for candidate receiving:
- Show the unchanged widget with default native platform, open the known original synthetic finalized package, and select a real video segment.
- Observe no automatic playback, actual source/stream/path identity, integer-millisecond media clock, native play/pause and seek, and unchanged file hashes.
- Observe actual position progression and pause stability, collapse/hide pause with no spontaneous resume, and fresh player/generation after selection or reload.
- Observe invalid/missing/no-selection states safely disabled; old-player callbacks cannot alter the current selection.
- Record visible original control inventory demonstrating absence of repeat and speed controls.
Retain actual Qt status/state/position/rate signals and monotonic times, errors, native platform/backend identities and screenshots. A source reading cannot replace this gate.

## Candidate-independent behavior predicates
1. Endpoints are selected from the current ready, seekable player's actual integer-ms position. Labels show the exact segment-local clock. Valid interval:0<=A<B<=known duration; no invented duration or session mapping.
2. Setting A/B, choosing speed and enabling repeat while paused never starts playback. Incomplete, invalid or unavailable intervals cannot repeat. Invalid B preserves an existing valid interval, as publicly clarified.
3. Enabling repeat is explicit. With repeat enabled, explicit Play from outside[A,B) normalizes toA then plays. A paused seek outside the interval remains where the operator put it until explicit Play.
4. During playback, crossing/reaching B returns toA and continues; a playing seek outside[A,B) likewise returns toA. Observe at least two actual native wrap transitions. Do not treat a setter call or an injected signal as playback proof.
5. Disabling Repeat preserves position and play/pause state. Clear removes endpoints and disables Repeat without starting or pausing playback. Ordinary native progression then continues past the former B.
6. Exposed rates are0.25x,0.5x,1x,2x, with1x default. Changing rate while paused preserves pause; changing rate while playing preserves playback. Observe backend-reported rate and actual native position/monotonic progression at slow/normal/fast rates; a requested setter value alone is insufficient. Preserve any backend refusal honestly.
7. Pause at or near a repeat boundary stays paused; queued status/position/end-of-media delivery must not restart it. Repeat ending exactly at media duration still obeys explicit-play intent.
8. Collapse/hide pauses, and reopening/showing does not resume automatically. Interval/rate may remain for the same retained player unless the public reset boundary applies.
9. Selection, reload, decoder error and package reset retire interval and speed to defaults together with old media. Old callbacks are refused by current identity and generation. Old media cannot resume in the background.
10. Source identity, media-versus-session explanation, read-only original files, reload and keyboard activation remain usable. A focused native control must receive its activation; app checkpoint Space routing must not steal the control's action.
11. Visual evidence must show actual interval endpoints, repeat state, rate and native media identity at an ordinary usable window size. No screenshot from an unrelated mock or retired source qualifies.
12. The source fence stays within the issue's declared widget/helper/tests/additive instructions and records; existing ReviewScreen/app/timeline/event-browser/discovery/capture/analysis/schema/dependency/workflow sources remain unchanged.

## Fixed receiving scenarios and transport binding
Semantic actions are frozen here; candidate labels/control names may be bound only after exact runtime admission. Do not read author test bodies to derive expectations.
Use canonical retained synthetic MKV bytes after independently verifying their Git identities. The original native baseline will determine decoder duration and supported seeking. Record chosen exact A/B positions before candidate admission; prefer interior positions near400ms and1200ms when the canonical fixture permits, plusB=duration for the end boundary. Freeze any fixture calibration from ORIGINAL only.
Independent case groups:
O original baseline described above.
C1 paused endpoint/rate/repeat setup, exact labels and invalidB preservation.
C2 real loop with two wraps; pause/queued boundary stability; explicit resume.
C3 paused/playing outside seeks; disable/clear while paused and playing.
C4 all four choices; actual progression witnesses at slow/normal/fast; rate change never starts a paused player.
C5 end-of-media loop, collapse/hide and non-resuming restore.
C6 segment switch/reload/reset/error/missing media; retired callbacks and defaults.
C7 keyboard/native shortcut routing, visible identities, exact final source/package bytes and owned-process closure.
Fixtures/assertions are preserved across candidate failures. Clarifications or transport corrections get dated addenda and retain old results. A disagreement with an unspecified public behavior must be reconciled before calling it a product defect.

## Current gate status
Public-source predicates frozen; no candidate or author tests read.
Original native baseline UNRUN. Runtime donor not admitted.
MSI base/registered Python3.11.9 and known SRS venv lack PySide6/PyQt6/PySide2. A bounded D:/Hamon depth4 scan completed1595 directories and found six venvs, none containing PySide6/PyQt6; one unrelated MAL temp directory denied and left untouched. Original LA7 donor is registry-offline. These are preserved discovery negatives only.
