# Pre-candidate Set A clarification

This additive record preserves CONTRACT.md SHA256 9a927a89ec61da5556c241ab06190f75af66c0accbe45f5a1cc1e68e1187f11f, candidate-semantic-fixtures.json SHA256 fba168086e20110dfef781d8763cb2fb56f3b9aa1a400ad4d8122d0f67352c65, and ENDPOINT-EDIT-ADDENDUM.md SHA256 c9857f77539550fee9918483be3fbf72f12721e429f664ebcadd68bf8617304a unchanged.

Before candidate source or author tests are read, the receiver directly read the full public clarification at https://github.com/Jacob-Met/CaptureSuite/issues/103#issuecomment-6073434029. It states that a valid Set A clears the prior B, and valid Set A or Set B disables Repeat until explicitly re-enabled. An invalid B preserves the prior interval and its enabled state. Disable Repeat and Clear preserve the playback position/state.

The independent receiver therefore expects a valid new A to leave only A, no B, with Repeat disabled; setting a subsequent valid B creates the strict A<B interval but leaves Repeat disabled. This is a public pre-candidate behavior clarification, not a finding inferred from implementation or a revision of a failed assertion. Existing frozen original source, semantic fixtures, runtime admission, and original native observations remain exact. Native execution of these clarified edits remains pending candidate admission.
