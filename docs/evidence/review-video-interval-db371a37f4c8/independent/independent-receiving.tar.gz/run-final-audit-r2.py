import pathlib,json,subprocess,sys,datetime,hashlib,traceback,os
b=pathlib.Path('D:/Hamon/receiving/capture-video-repeat-db371a37f4c8');run=b/'final-audit-run-r2';run.mkdir()
r={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wrapper_pid':os.getpid(),'operation':'read-only complete input/runtime final hash audit','product_run':False}
with (run/'stdout.log').open('xb') as out,(run/'stderr.log').open('xb') as err:
 try:
  p=subprocess.Popen([sys.executable,'-B',str(b/'final-audit-r1.py')],stdout=out,stderr=err)
  r['child_pid']=p.pid
  (run/'launch.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
  try:r['exit_code']=p.wait(timeout=100)
  except subprocess.TimeoutExpired:
   p.terminate();r['exit_code']=p.wait(timeout=5);r['timeout']=True
 except BaseException:r['error']=traceback.format_exc()
r['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat()
r['final_audit_exists']=(b/'FINAL-AUDIT-r1.json').is_file()
r['status']='PASS' if r.get('exit_code')==0 and r['final_audit_exists'] else 'FAIL'
(run/'receipt.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
print(json.dumps(r))
