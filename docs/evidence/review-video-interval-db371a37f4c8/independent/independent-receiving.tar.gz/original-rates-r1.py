# SPDX-License-Identifier: GPL-3.0-only
"""Original Qt backend rate oracle; it does not qualify candidate controls."""
from __future__ import annotations
import argparse,hashlib,json,os,pathlib,shutil,sys,time,traceback
from datetime import datetime,timezone
sys.dont_write_bytecode=True
def pins(root,rows):
 out={}
 for row in rows:
  p=root.joinpath(*pathlib.PurePosixPath(row['path']).parts);b=p.read_bytes();h=hashlib.sha256(b).hexdigest()
  assert h==row['sha256'] and len(b)==row['bytes'],row['path']
  out[row['path']]=h
 return out
ap=argparse.ArgumentParser();ap.add_argument('--admission',required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
d=json.loads(pathlib.Path(a.admission).read_bytes());assert d['kind']=='capturesuite-original-native-admission-v1'
assert sys.version_info[:2]==(3,12)
source=pathlib.Path(d['source_root']);fixture=pathlib.Path(d['fixture_root'])
before=pins(source,d['source_files']);fb=pins(fixture,d['fixture_files'])
out=pathlib.Path(a.output);assert not out.exists();out.mkdir()
package=out/'package';shutil.copytree(fixture,package)
result={'started':datetime.now(timezone.utc).isoformat(),'status':'RUNNING','groups':[],'rates':[],
        'events':[],'frames':[],'scope':'Public QMediaPlayer rate capability on unchanged original widget; no candidate rate UI claim.'}
app=w=v=None
try:
 for rel in ('desktop','libs/python/capture_analysis','libs/python/capture_session','libs/python/capture_protocol','libs/python/capture_worker'):sys.path.insert(0,str(source/rel))
 from PySide6.QtCore import Qt,QEvent,qVersion
 from PySide6.QtWidgets import QApplication,QMainWindow
 from PySide6.QtMultimedia import QMediaPlayer
 from PySide6.QtTest import QTest
 from capture_desktop.widgets_review_video import RecordedVideoReview
 app=QApplication([]);assert app.platformName()=='windows'
 w=QMainWindow();v=RecordedVideoReview();w.setCentralWidget(v);w.resize(900,700);w.show()
 v.load_package(str(package),state='finalized');v._toggle.setChecked(True);v._choice.setCurrentIndex(1)
 def wait(test,label,seconds=10):
  until=time.monotonic()+seconds
  while time.monotonic()<until:
   if test():return
   QTest.qWait(20)
  raise AssertionError(label)
 wait(lambda:v._ready and v._player.isSeekable(),'original ready')
 p=v._player;assert p.duration()==2000
 for signal in ('positionChanged','playbackRateChanged','playbackStateChanged'):
  getattr(p,signal).connect(lambda *values,n=signal:result['events'].append({'at':time.monotonic(),'signal':n,'values':[str(x) for x in values]}))
 v._video.videoSink().videoFrameChanged.connect(lambda f:result['frames'].append({'at':time.monotonic(),'start_us':f.startTime(),'end_us':f.endTime()}) if f.isValid() else None)
 for rate in (0.25,0.5,1.0,2.0):
  assert p.playbackState()!=QMediaPlayer.PlaybackState.PlayingState
  v._seek.setValue(500);wait(lambda:p.position()==100,'paused100ms seek')
  p.setPlaybackRate(rate)
  wait(lambda:p.playbackRate()==rate,'backend actual requested rate')
  QTest.qWait(180);assert p.playbackState()!=QMediaPlayer.PlaybackState.PlayingState and p.position()==100
  QTest.mouseClick(v._play,Qt.MouseButton.LeftButton)
  wait(lambda:p.playbackState()==QMediaPlayer.PlaybackState.PlayingState,'explicit play')
  QTest.qWait(100)
  start=time.monotonic();position=p.position();frame0=len(result['frames']);samples=[]
  while time.monotonic()-start<0.6:
   samples.append({'wall_ms':(time.monotonic()-start)*1000,'position_ms':p.position()});QTest.qWait(20)
  elapsed=(time.monotonic()-start)*1000;advance=p.position()-position
  expected=elapsed*rate;tolerance=max(100,expected*0.25)
  item={'rate':rate,'actual_rate':p.playbackRate(),'wall_ms':elapsed,'start_position_ms':position,
        'end_position_ms':p.position(),'advance_ms':advance,'expected_ms':expected,'tolerance_ms':tolerance,
        'frames_during_sample':len(result['frames'])-frame0,'samples':samples,
        'state':p.playbackState().name,'status':p.mediaStatus().name}
  result['rates'].append(item)
  assert p.playbackState()==QMediaPlayer.PlaybackState.PlayingState and p.position()<p.duration()
  assert advance>0 and abs(advance-expected)<=tolerance and item['frames_during_sample']>0,item
  QTest.mouseClick(v._play,Qt.MouseButton.LeftButton)
  wait(lambda:p.playbackState()!=QMediaPlayer.PlaybackState.PlayingState,'explicit pause')
  QTest.qWait(180);at=p.position();QTest.qWait(250)
  assert abs(p.position()-at)<=60 and p.playbackState()!=QMediaPlayer.PlaybackState.PlayingState
  result['groups'].append('native rate '+str(rate))
 assert all(x['advance_ms']/x['wall_ms']<y['advance_ms']/y['wall_ms'] for x,y in zip(result['rates'],result['rates'][1:]))
 result['status']='PASS'
except BaseException:result['status']='FAIL';result['failure']=traceback.format_exc()
finally:
 try:
  if v is not None:v.reset()
  if w is not None:w.close();w.deleteLater()
  if app is not None:app.sendPostedEvents(None,QEvent.Type.DeferredDelete);app.processEvents()
  assert pins(source,d['source_files'])==before and pins(fixture,d['fixture_files'])==fb and pins(package,d['fixture_files'])==fb
  result['all_source_fixture_package_exact']=True
 except BaseException:result['status']='FAIL';result['closure_error']=traceback.format_exc()
 result['finished']=datetime.now(timezone.utc).isoformat()
 with (out/'receipt.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps({'status':result['status'],'groups':result['groups'],'receipt':str(out/'receipt.json')}))
sys.exit(0 if result['status']=='PASS' else 1)
