import pathlib,json,hashlib,datetime,shutil
b=pathlib.Path('D:/Hamon/receiving/capture-video-repeat-db371a37f4c8')
a=pathlib.Path('D:/Hamon/worktrees/capture-video-repeat-db371a37f4c8-production')
offerpath=a/'RUNTIME-OFFER-r1.json'; offer=json.loads(offerpath.read_bytes())
adm=json.loads((b/'native-admission-r1.json').read_bytes()); original=pathlib.Path(adm['source_root'])
def pin(p):
 x=p.read_bytes();return {'bytes':len(x),'sha256':hashlib.sha256(x).hexdigest(),'git':hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest()}
for r in adm['source_files']:
 got=pin(original/r['path'])
 for k in ('bytes','sha256','git'):
  if k in r: assert got[k]==r[k],(r['path'],k)
for r in [offer['original'],*offer['candidate'],offer['delta']]:
 got=pin(pathlib.Path(r['path']))
 assert all(got[k]==r[k] for k in ('bytes','sha256','git')),r['path']
dest=b/'candidate-r1';dest.mkdir()
for r in adm['source_files']:
 src=original/r['path'];dst=dest/r['path'];dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
for r in offer['candidate']:
 src=pathlib.Path(r['path']);rel=src.relative_to(a/'candidate-r1');dst=dest/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
rows=[dict(path=p.relative_to(dest).as_posix(),**pin(p)) for p in sorted(dest.rglob('*')) if p.is_file()]
before={r['path']:r for r in adm['source_files']};after={r['path']:r for r in rows}
changes=[p for p in before if before[p]['sha256']!=after[p]['sha256']]
added=sorted(set(after)-set(before))
assert changes==['desktop/capture_desktop/widgets_review_video.py'],changes
assert added==['desktop/capture_desktop/review_video_interval.py','docs/operator/RECORDED_VIDEO_REVIEW.md'],added
r={'kind':'capturesuite-candidate-native-admission-v1','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'EXACT R1 runtime admitted; author native qualification pending; independent candidate not yet run','source_root':str(dest),'source_files':rows,'python':adm['python'],'fixture_root':adm['fixture_root'],'fixture_files':adm['fixture_files'],'runtime_manifest_sha256':adm['runtime_manifest_sha256'],'loaded_modules_exact':adm['loaded_modules_exact'],'canonical_commit':offer['canonical_commit'],'changed':changes,'added':added,'unchanged_original_files':len(before)-len(changes),'offer':offer,'author_tests_read':False}
for name,obj in [('candidate-admission-r1.json',r),('candidate-runtime-manifest-r1.json',rows)]:
 (b/name).open('x',encoding='utf-8').write(json.dumps(obj,indent=2)+'\n')
shutil.copyfile(offerpath,b/'author-runtime-offer-r1.json');shutil.copyfile(pathlib.Path(offer['delta']['path']),b/'author-widget-delta-r1.patch')
print(json.dumps({'at':r['at'],'files':len(rows),'bytes':sum(x['bytes'] for x in rows),'changed':changes,'added':added,'unchanged':r['unchanged_original_files'],'admission':pin(b/'candidate-admission-r1.json'),'manifest':pin(b/'candidate-runtime-manifest-r1.json')}))
