"""Seal the independent source/evidence packet without changing source or Git refs."""
import pathlib,json,hashlib,tarfile,io,datetime,shutil,os,base64
b=pathlib.Path('D:/Hamon/receiving/capture-video-repeat-db371a37f4c8')
def pin_bytes(x):
 return {'bytes':len(x),'sha256':hashlib.sha256(x).hexdigest(),'git':hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest()}
def pin(p):return pin_bytes(p.read_bytes())
assert pin(b/'FINAL-AUDIT-r1.json')['sha256']=='18749b31a0ba36482357cb78f3bde261821d2fbf79cddc9b0a1d3800ea11cc30'
assert shutil.disk_usage(b).free>128*1024*1024
pub=b/'publication';pub.mkdir()
paths={p.relative_to(b).as_posix():p for p in b.rglob('*') if p.is_file() and not p.is_relative_to(pub)}
original=json.loads((b/'native-admission-r1.json').read_bytes())
for row in original['source_files']:
 p=pathlib.Path(original['source_root'])/row['path'];got=pin(p)
 assert all(got[k]==row[k] for k in ('bytes','sha256','git') if k in row)
 name='original-source/'+row['path'];assert name not in paths;paths[name]=p
rows=[]
for name,p in sorted(paths.items()):
 rel=pathlib.PurePosixPath(name);assert not rel.is_absolute() and '..' not in rel.parts and not p.is_symlink()
 rows.append(dict(path=name,mode='100644',**pin(p)))
manifest={'schema':'capture-repeat-independent-evidence-manifest-v1','sealed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'source_commit':'3960c0c756cd4e9facbde0d76eaaa3c31ab7c167','candidate_manifest_sha256':'f993c298acef5c67bec48622d2fbe7fc71ac4b3dd2c687e4ad969552d01d7586',
 'payload_files':len(rows),'payload_bytes':sum(x['bytes'] for x in rows),'files':rows,
 'runtime_custody':'Full manifest, dependency lock, actual import/DLL proof and complete before/after byte audits included; external private runtime binaries are not duplicated.',
 'root_authorship':['ROOT-SOURCE-REVIEW-r1.json','root-source-review-r1.py','root-native-visual-review.json'],
 'limits':'Native QWidget grabs show controls, not the GPU video plane; decoded image is an independent native QVideoSink witness.'}
mp=pub/'MANIFEST.json';mp.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
archive=pub/'independent-receiving.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for row in rows:
  data=paths[row['path']].read_bytes();assert pin_bytes(data)=={k:row[k] for k in ('bytes','sha256','git')}
  info=tarfile.TarInfo(row['path']);info.size=len(data);info.mode=0o644;info.mtime=0
  tar.addfile(info,io.BytesIO(data))
 data=mp.read_bytes();info=tarfile.TarInfo('MANIFEST.json');info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(rows)+1
 expected={row['path']:row for row in rows}
 assert len({m.name for m in members})==len(members)
 for member in members:
  assert member.isfile() and member.mode==0o644
  data=tar.extractfile(member).read()
  if member.name=='MANIFEST.json':assert data==mp.read_bytes()
  else:
   row=expected.pop(member.name);assert pin_bytes(data)=={k:row[k] for k in ('bytes','sha256','git')}
 assert not expected
seal={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS','archive':pin(archive),'manifest':pin(mp),
 'report':pin(b/'INDEPENDENT-RECEIVING.md'),'final_audit':pin(b/'FINAL-AUDIT-r1.json'),
 'payload_files':len(rows),'archive_members':len(rows)+1,'all_archive_members_reverified':True,'no_ref_or_actions_operation':True}
(pub/'SEAL.json').write_text(json.dumps(seal,indent=2)+'\n',encoding='utf-8')
for logical,p in [('archive',archive),('manifest',mp),('report',b/'INDEPENDENT-RECEIVING.md'),('audit',b/'FINAL-AUDIT-r1.json'),('seal',pub/'SEAL.json')]:
 encoded=base64.b64encode(p.read_bytes()).decode('ascii')
 (pub/(logical+'.base64')).write_text('\n'.join(encoded[i:i+24000] for i in range(0,len(encoded),24000))+'\n',encoding='ascii')
print(json.dumps(seal))
