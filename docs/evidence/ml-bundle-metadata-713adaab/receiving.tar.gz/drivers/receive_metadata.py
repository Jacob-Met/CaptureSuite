# SPDX-License-Identifier: GPL-3.0-only
"""Pair identical focused controls on original and metadata-only candidate."""
from pathlib import Path
import os,sys,subprocess,json,hashlib,datetime,xml.etree.ElementTree as ET
ROOT=Path("/Users/me/Developer/capturesuite-ml-bundle-metadata-20261008-713adaab")
E=ROOT/"out/ml-bundle-metadata-evidence";phase=sys.argv[1]
assert phase in ("baseline","candidate")
out=E/(phase+"-tests");out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
scope=["tests/analysis/test_ml_bundle_metadata.py"]
if phase=="candidate":scope+=["tests/analysis/test_kinematics_ml_bundle.py"]
inputs=["libs/python/capture_analysis/capture_analysis/ml_bundle/job.py","libs/python/capture_analysis/capture_analysis/jobs.py","libs/python/capture_analysis/capture_analysis/kinematics/job.py","libs/python/capture_analysis/capture_analysis/kinematics/compute.py","libs/python/capture_analysis/capture_analysis/eval/job.py","schemas/ml_bundle/ml_bundle.manifest.schema.json","desktop/capture_desktop/widgets_analysis_jobs.py",*scope]
before={n:sha(ROOT/n) for n in inputs}
env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1",PYTHONPATH=os.pathsep.join([str(ROOT),*[str(ROOT/"libs/python"/n) for n in ("capture_analysis","capture_session","capture_protocol","capture_worker")]]),MPLBACKEND="Agg",MPLCONFIGDIR="/Users/me/Developer/capturesuite-analysis-provenance-20261008/out/analysis-provenance-evidence/matplotlib-cache")
py="/Users/me/Developer/capturesuite-analysis-provenance-20261008/.venv-analysis/bin/python"
check=subprocess.run([py,"-B","-c","import sys,json,capture_analysis.ml_bundle.job,capture_analysis.jobs;print(json.dumps({'python':sys.version,'producer':capture_analysis.ml_bundle.job.__file__,'jobs':capture_analysis.jobs.__file__}))"],cwd=ROOT,env=env,capture_output=True);assert check.returncode==0
resolved=json.loads(check.stdout);assert Path(resolved["producer"]).is_relative_to(ROOT) and Path(resolved["jobs"]).is_relative_to(ROOT)
command=[py,"-B","-m","pytest",*scope,"-q","-p","no:cacheprovider","--basetemp",str(out/"fixtures"),"--junitxml",str(out/"pytest.xml")]
with (out/"pytest.log").open("xb") as f:r=subprocess.run(command,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
cases=list(ET.parse(out/"pytest.xml").getroot().iter("testcase"))
counts={"tests":len(cases),"passed":sum(all(c.find(k) is None for k in ("failure","error","skipped")) for c in cases),"failures":sum(c.find("failure") is not None for c in cases),"errors":sum(c.find("error") is not None for c in cases),"skipped":sum(c.find("skipped") is not None for c in cases)}
after={n:sha(ROOT/n) for n in inputs};assert before==after
d={"schema":"capture.ml_bundle_metadata.paired_receiving/1","phase":phase,"recorded_at":datetime.datetime.now(datetime.UTC).isoformat(),"base_commit":"70f34e3b982523b544a9370d2316a1b69d79bd70","command":command,"exit_code":r.returncode,"counts":counts,"failed_cases":[c.get("name") for c in cases if c.find("failure") is not None or c.find("error") is not None],"runtime":resolved,"source_before":before,"source_after":after,"junit_sha256":sha(out/"pytest.xml"),"log_sha256":sha(out/"pytest.log"),"runner_sha256":sha(Path(__file__))}
p=out/"receipt.json";p.write_text(json.dumps(d,indent=2)+"\n");print(json.dumps({"phase":phase,"counts":counts,"exit_code":r.returncode,"receipt_sha256":sha(p),"test_sha256":before[scope[0]],"producer_sha256":before[inputs[0]],"failed_cases":d["failed_cases"]}))
