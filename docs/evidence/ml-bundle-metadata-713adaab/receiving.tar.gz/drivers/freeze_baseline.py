# SPDX-License-Identifier: GPL-3.0-only
"""Freeze small actual Parquet witnesses before the metadata-only change."""
from pathlib import Path
from types import SimpleNamespace
import datetime,hashlib,json,sys,subprocess
import pandas as pd
import pyarrow
from capture_analysis.ml_bundle import job as producer

ROOT=Path("/Users/me/Developer/capturesuite-ml-bundle-metadata-20261008-713adaab")
E=ROOT/"out/ml-bundle-metadata-evidence";E.mkdir(parents=True,exist_ok=True)
FIX=E/"baseline-witness";FIX.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=Path(producer.__file__)
assert source==ROOT/"libs/python/capture_analysis/capture_analysis/ml_bundle/job.py"
assert sha(source)=="c14c74760e20c818ce5e2428d0b03a8a949899b0bba6c46e37fa8fd797631c75"
source_before=sha(source)
records=[]
for name,short,window,hop,requested_rate in (("regular",False,0.2,0.3,20.0),("quantized",False,0.2000000019,0.3000000009,99.0),("short_fallback",True,0.2,0.3,20.0)):
 r=FIX/name;pkg=r/"package";work=r/"output"
 kin=pkg/"processing/jobs/kin/kinematics/kinematics.parquet"
 feat=pkg/"processing/jobs/feat/features/radar/radar.fixture/energy.parquet"
 kin.parent.mkdir(parents=True);feat.parent.mkdir(parents=True)
 times=[0,25_000_000,50_000_000] if short else [i*100_000_000 for i in range(15)]
 angles=[0.0,100.0,30.0] if short else [0.0,100.0,30.0,20.0,120.0,50.0,40.0,140.0,70.0,60.0,160.0,90.0,80.0,180.0,110.0]
 teacher={"session_time_ns":times,"valid_elbow_L":[True]*len(times),"valid_elbow_R":[True]*len(times)}
 for multiple,col in enumerate(producer.DEFAULT_TARGET_COLUMNS,1):teacher[col]=[multiple*v for v in angles]
 pd.DataFrame(teacher).to_parquet(kin,index=False)
 pd.DataFrame({"t_ns":[0,250_000_000,600_000_000,850_000_000,1_200_000_000,1_500_000_000],"energy":[100.0,200.0,300.0,400.0,500.0,600.0]}).to_parquet(feat,index=False)
 before={str(p.relative_to(r)):sha(p) for p in (kin,feat)}
 outputs=[];warnings=[]
 result=producer.run_ml_bundle_job(pkg,work,SimpleNamespace(session_id="synthetic-metadata-fixture"),kinematics_job_id="kin",features_job_id="feat",window_sec=window,hop_sec=hop,grid_rate_hz=requested_rate,outputs=outputs,warnings=warnings)
 windows_path=work/"ml_bundle/windows.parquet";manifest_path=work/"ml_bundle/manifest.json"
 actual=pd.read_parquet(windows_path);manifest=json.loads(manifest_path.read_bytes())
 assert actual["session_time_ns"].tolist()==([25_000_000] if short else [100_000_000,400_000_000,700_000_000,1_000_000_000,1_300_000_000])
 assert actual["motion_energy"].tolist()==([100.0] if short else [100.0,200.0,300.0,400.0,500.0])
 assert actual["theta_elbow_flex_L"].tolist()==([30.0] if short else [30.0,50.0,70.0,90.0,110.0])
 assert actual["valid_mask"].all()
 assert {str(p.relative_to(r)):sha(p) for p in (kin,feat)}==before
 for row in outputs:
  p=work/row["relativePath"];assert sha(p)==row["sha256"] and p.stat().st_size==row["bytes"]
 records.append({"name":name,"arguments":{"window_sec":window,"hop_sec":hop,"grid_rate_hz":requested_rate},"input_sha256":before,"window_sha256":sha(windows_path),"window_bytes":windows_path.stat().st_size,"manifest_sha256":sha(manifest_path),"manifest_bytes":manifest_path.stat().st_size,"recorded_grid":manifest["analysisGrids"][0],"recorded_window":manifest["window"],"recorded_normalization":manifest["normalization"],"actual_windows":actual.to_dict(orient="records"),"actual_delta_ns":actual["session_time_ns"].diff().dropna().astype("int64").tolist(),"actual_motion_energy_mean":float(actual["motion_energy"].mean()),"schema_warnings":warnings,"return_value":result,"final_output_receipts_match":True,"inner_manifest_self_digest_matches":manifest["sha256"].get("manifest.json")==sha(manifest_path)})
assert records[0]["window_sha256"]==records[1]["window_sha256"]
assert sha(source)==source_before
doc={"schema":"capture.ml_bundle_metadata.baseline_witness/1","recorded_at":datetime.datetime.now(datetime.UTC).isoformat(),"base_commit":subprocess.check_output(["/usr/bin/git","-C",str(ROOT),"rev-parse","HEAD"],text=True).strip(),"source_path":str(source),"source_sha256_before":source_before,"source_sha256_after":sha(source),"runtime":{"python":sys.version,"pandas":pd.__version__,"pyarrow":pyarrow.__version__},"cases":records,"observations":["All regular motion_energy values are unchanged positive source energy values; their mean is300, despite per_session_zscore metadata.","Regular labels30,50,70,90,110 are inclusive-window medians; center-time linear interpolation would give100,120,140,160,180.","All regular and quantized center spacings are300000000ns (3.3333333333333335Hz), despite declared rates20Hz and99Hz.","The quantized request produces byte-identical windows to the regular request because integer hop and half-width are equal.","A short source falls back to one median timestamp, with no observed inter-window cadence."],"scope_limit":"Synthetic offline Parquet producer receiving on actual installed3.12.8. No model, acquisition, scientific or hardware validation. The pre-existing submanifest self-digest discrepancy is preserved outside this repair."}
p=E/"baseline-witness.json";p.write_text(json.dumps(doc,indent=2)+"\n")
print(json.dumps({"receipt_sha256":sha(p),"source_sha256":source_before,"cases":[{k:r[k] for k in ("name","window_sha256","window_bytes","actual_delta_ns","actual_motion_energy_mean","schema_warnings")} for r in records],"total_witness_bytes":sum(f.stat().st_size for f in FIX.rglob("*") if f.is_file())}))
