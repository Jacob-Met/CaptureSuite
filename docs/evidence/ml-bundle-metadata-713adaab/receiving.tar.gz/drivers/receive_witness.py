# SPDX-License-Identifier: GPL-3.0-only
"""Replay the metadata-only producer on the exact preserved baseline Parquet inputs."""
from pathlib import Path
from types import SimpleNamespace
import hashlib,json,datetime
from capture_analysis.ml_bundle import job as producer
ROOT=Path("/Users/me/Developer/capturesuite-ml-bundle-metadata-20261008-713adaab");E=ROOT/"out/ml-bundle-metadata-evidence"
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
baseline_path=E/"baseline-witness.json";assert sha(baseline_path)=="d1dd784d7191f752e44b3c6cc9dc468b603df2d0e4f6be326654a6b2a5dd02d8"
baseline=json.loads(baseline_path.read_bytes());original=E/"baseline-witness";dest=E/"candidate-witness";dest.mkdir(exist_ok=False)
all_original={str(p.relative_to(original)):sha(p) for p in original.rglob("*") if p.is_file()}
source=Path(producer.__file__);assert source==ROOT/"libs/python/capture_analysis/capture_analysis/ml_bundle/job.py"
assert sha(source)=="38b7161f081ef038e6ce464dd3b82ca2b49f775ad8988010243743274d6fc5e6"
records=[]
for case in baseline["cases"]:
 source_root=original/case["name"];work=dest/case["name"];outputs=[];warnings=[]
 result=producer.run_ml_bundle_job(source_root/"package",work,SimpleNamespace(session_id="synthetic-metadata-fixture"),kinematics_job_id="kin",features_job_id="feat",**case["arguments"],outputs=outputs,warnings=warnings)
 windows=work/"ml_bundle/windows.parquet";man=work/"ml_bundle/manifest.json";doc=json.loads(man.read_bytes())
 assert windows.read_bytes()==(source_root/"output/ml_bundle/windows.parquet").read_bytes()
 assert sha(windows)==case["window_sha256"];assert warnings==[]
 for row in outputs:
  p=work/row["relativePath"];assert p.stat().st_size==row["bytes"] and sha(p)==row["sha256"]
 records.append({"name":case["name"],"original_window_sha256":case["window_sha256"],"candidate_window_sha256":sha(windows),"windows_byte_identical":True,"candidate_manifest_sha256":sha(man),"candidate_manifest_bytes":man.stat().st_size,"recorded_grid":doc["analysisGrids"][0],"recorded_window":doc["window"],"recorded_normalization":doc["normalization"],"schema_warnings":warnings,"inner_self_digest_remains_out_of_scope":doc["sha256"].get("manifest.json")!=sha(man)})
assert {str(p.relative_to(original)):sha(p) for p in original.rglob("*") if p.is_file()}==all_original
assert sha(source)=="38b7161f081ef038e6ce464dd3b82ca2b49f775ad8988010243743274d6fc5e6"
d={"schema":"capture.ml_bundle_metadata.paired_witness/1","recorded_at":datetime.datetime.now(datetime.UTC).isoformat(),"baseline_receipt_sha256":sha(baseline_path),"producer_source_sha256":sha(source),"cases":records,"all_original_file_hashes_unchanged":all_original,"source_unchanged":True,"runner_sha256":sha(Path(__file__)),"scope":"All three cases use the exact original Parquet input files, write into a distinct output namespace and retain byte-identical windows. Only metadata changes; neither the producer algorithm nor the unrelated internal self-digest convention changes."}
p=E/"paired-witness.json";p.write_text(json.dumps(d,indent=2)+"\n")
print(json.dumps({"paired_witness_sha256":sha(p),"cases":[{"name":c["name"],"window_sha256":c["candidate_window_sha256"],"byte_identical":c["windows_byte_identical"],"grid":c["recorded_grid"],"window":c["recorded_window"],"normalization":c["recorded_normalization"]} for c in records],"original_files_preserved":len(all_original)}))
