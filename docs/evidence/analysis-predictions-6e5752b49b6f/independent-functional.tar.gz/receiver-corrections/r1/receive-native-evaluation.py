# SPDX-License-Identifier: GPL-3.0-only
"""Independent actual-Qt receiving of native evaluation input and real jobs.

Only a pass-through run observer and one explicitly gated scheduling control are
installed in this private process. No scorer, worker, dialog or result is stubbed.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time
import tomllib
import traceback

parser = argparse.ArgumentParser()
parser.add_argument("--source", required=True)
parser.add_argument("--output", required=True)
args = parser.parse_args()
SOURCE = Path(args.source).resolve()
OUT = Path(args.output).resolve()
OUT.mkdir(parents=True, exist_ok=False)
sys.dont_write_bytecode = True
for name, suffix in {
    "LOCALAPPDATA": "local", "APPDATA": "roaming", "XDG_CONFIG_HOME": "config",
    "XDG_DATA_HOME": "data", "XDG_CACHE_HOME": "cache", "MPLCONFIGDIR": "matplotlib",
    "TMPDIR": "temporary", "CAPTURE_TEST_STATE": "application-state",
}.items():
    folder = OUT / suffix
    folder.mkdir()
    os.environ[name] = str(folder)
os.environ["QT_QPA_PLATFORM"] = "offscreen"
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
os.chdir(OUT)
configuration = tomllib.loads((SOURCE / "pyproject.toml").read_text())
for path in reversed(configuration["tool"]["pytest"]["ini_options"]["pythonpath"]):
    sys.path.insert(0, str(SOURCE / path))

sha = lambda data: hashlib.sha256(data).hexdigest()
def git(*arguments):
    environment = dict(os.environ, GIT_OPTIONAL_LOCKS="0")
    return subprocess.check_output(["git", *arguments], cwd=SOURCE, env=environment, text=True).strip()

EXPECTED = {
    "desktop/capture_desktop/widgets_analysis_predictions.py": "d865031e313b0c1aed23a2cb0beeb20441a96d380f0b3652458107ba4a6e2435",
    "desktop/capture_desktop/widgets_analysis_jobs.py": "a012ac150e1301a630417cd78238c050093206f94f073e6e0ee4c90f22b81b62",
    "desktop/capture_desktop/screen_analysis.py": "b31413db7f0874b4404a5c6dcb047072c439f63def3d2caec75ed2432b31b79f",
    "tests/ui/test_analysis_predictions.py": "59de033caed5f819808db0961fb8c7e68214abd0f8eb46009e8a76d541f0f75c",
}
assert git("rev-parse", "HEAD") == "424298e30d6e0f08fe4124fa282328575c40d203"
assert git("rev-parse", "HEAD^{tree}") == "b69adfdf45711035963094b811760500cb76c966"
assert git("rev-parse", "HEAD^") == "d7459fa62dd7a57d5565214e10638e055ad5877c"
assert set(git("diff-tree", "--no-commit-id", "--name-only", "-r", "HEAD").splitlines()) == set(EXPECTED)
assert not git("status", "--porcelain")
for path, digest in EXPECTED.items():
    assert sha((SOURCE / path).read_bytes()) == digest, path
tree = {}
for line in git("ls-tree", "-r", "HEAD").splitlines():
    metadata, path = line.split("\t", 1)
    mode, kind, digest = metadata.split()
    if kind == "blob":
        tree[path] = {"mode": mode, "git_blob": digest}

import PySide6
from PySide6.QtCore import QCoreApplication, QEvent, QEventLoop, QThread, QTimer, Qt, qVersion
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QComboBox, QDialogButtonBox, QFileDialog, QLineEdit, QMessageBox, QPushButton, QWidget
import pandas as pd
import capture_analysis
from capture_desktop import theme
from capture_desktop.screen_analysis import AnalysisScreen, _AnalysisWorker
from capture_desktop.state import CaptureState
from capture_desktop.widgets_analysis_jobs import AnalysisJobExtras

QCoreApplication.setAttribute(Qt.ApplicationAttribute.AA_DontUseNativeDialogs, True)
app = QApplication([])
app.setApplicationName("CaptureSuite independent evaluation receiving 6e5752b49b6f")
app.setOrganizationName("Independent receiving")
theme.apply_theme(app, setting="dark")
MAIN_THREAD = threading.get_ident()
REPORT = {
    "source_commit": git("rev-parse", "HEAD"), "source_tree": git("rev-parse", "HEAD^{tree}"),
    "parent": git("rev-parse", "HEAD^"), "owned_source_sha256": EXPECTED,
    "receiver_sha256": sha(Path(__file__).read_bytes()), "python": sys.version,
    "pyside": PySide6.__version__, "qt": qVersion(), "qt_platform": app.platformName(),
    "dialog_scope": "Actual Qt QFileDialog with AA_DontUseNativeDialogs; not a Cocoa or Windows OS-dialog claim.",
    "cases": [], "dialogs": [], "messages": [], "jobs": [], "screenshots": [],
}
case_name = "initialization"
callback_errors = []
actual_run = capture_analysis.run
GATE = {"active": False, "entered": threading.Event(), "release": threading.Event()}
protected = {}
all_threads = []

def write_json(path, document):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(document, ensure_ascii=False, indent=2) + "\n", encoding="utf8")

def protect(path):
    protected[str(path)] = sha(path.read_bytes())

def fixture(name):
    package = OUT / (name + ".mmsession")
    package.mkdir()
    write_json(package / "manifest.json", {
        "session_schema_version": "1.0.0", "sessionId": "independent-ui-" + name,
        "state": "finalized", "t0WallUtc": "2026-10-08T00:00:00Z",
        "finalizedUtc": "2026-10-08T00:00:10Z", "sourceIds": [],
    })
    write_json(package / "integrity.json", {"schemaVersion": "1", "files": []})
    for event in ("checkpoints", "annotations", "sync_anchors"):
        write_json(package / "events" / (event + ".json"), [])
    for path in package.rglob("*"):
        if path.is_file():
            protect(path)
    identifiers = ["native-c", "native-a", "native-d", "native-b"]
    times = [10**18 + 37 + i * 250_000_001 for i in range(4)]
    teacher = [-6.0, 1.5, 8.0, 21.0]
    column = "theta_elbow_flex_L"
    paths = {}
    for bundle_id, shift in (("bundle", 0.0), ("alternate", 100.0)):
        folder = package / "processing" / "jobs" / bundle_id / "ml_bundle"
        folder.mkdir(parents=True)
        windows = folder / "windows.parquet"
        pd.DataFrame({
            "window_id": identifiers,
            "session_time_ns": pd.Series(times, dtype="int64"),
            "valid_mask": pd.Series([True] * 4, dtype="bool"),
            column: [value + shift for value in teacher],
        }).to_parquet(windows, index=False)
        manifest = folder / "manifest.json"
        write_json(manifest, {
            "schemaId": "capture.ml_bundle/1",
            "sessionIds": ["independent-ui-" + name],
            "targetColumns": [column],
            "sha256": {"windows.parquet": sha(windows.read_bytes())},
            "provisional": True,
        })
        paths[bundle_id] = (windows, manifest)
        protect(windows); protect(manifest)
    windows, manifest = paths["bundle"]
    def predictions(label, offset):
        return {
            "schemaId": "capture.eval_predictions/1", "modelId": label,
            "windowsSha256": sha(windows.read_bytes()),
            "manifestSha256": sha(manifest.read_bytes()),
            "predictions": [
                {"window_id": identifiers[i], "session_time_ns": times[i],
                 "values": {column: teacher[i] + offset}}
                for i in (3, 1, 0, 2)
            ],
        }
    inputs = OUT / "inputs" / name
    inputs.mkdir(parents=True)
    # The trailing space is intentional and is a native POSIX filename control.
    chosen_a = inputs / " predictions café A.json "
    chosen_b = inputs / "predictions chosen B.json"
    invalid = inputs / "source mismatch.json"
    write_json(chosen_a, predictions("Receiver chosen A / café", 2.25))
    write_json(chosen_b, predictions("Receiver chosen B", 5.75))
    bad = predictions("Receiver wrong source", 2.25)
    bad["manifestSha256"] = "0" * 64
    write_json(invalid, bad)
    return {
        "package": package, "column": column, "ids": identifiers, "times": times,
        "teacher": teacher, "a": chosen_a, "b": chosen_b, "invalid": invalid,
        "windows": windows, "manifest": manifest, "predictions": predictions,
    }

def wait_until(predicate, timeout=35):
    if predicate():
        return
    loop = QEventLoop()
    timer = QTimer()
    deadline = time.monotonic() + timeout
    def check():
        if predicate() or callback_errors or time.monotonic() > deadline:
            loop.quit()
    timer.timeout.connect(check)
    timer.start(20)
    loop.exec()
    timer.stop()
    assert not callback_errors, callback_errors
    assert predicate(), "Timed out in native event loop: " + case_name

def press(widget):
    assert widget.isEnabled(), widget.objectName() or widget.text()
    widget.setFocus()
    QTest.keyClick(widget, Qt.Key.Key_Space)

def mode_control(parent):
    result = parent.findChild(QComboBox, "EvalInputMode")
    assert result is not None
    return result

def mode(parent, target):
    combo = mode_control(parent)
    index = combo.findData(target)
    assert index >= 0
    combo.setFocus()
    for _ in range(combo.count() + 1):
        if combo.currentIndex() == index:
            break
        QTest.keyClick(combo, Qt.Key.Key_Down if combo.currentIndex() < index else Qt.Key.Key_Up)
    assert combo.currentData() == target

def path_control(parent):
    result = parent.findChild(QLineEdit, "EvalPredictionPath")
    assert result is not None and result.isReadOnly()
    return result

def choose(parent, requested=None, *, cancel=False, during=None):
    choose_button = parent.findChild(QPushButton, "EvalPredictionChoose")
    assert choose_button is not None and choose_button.isEnabled()
    observations = []
    timer = QTimer()
    deadline = time.monotonic() + 8
    stage = {"dialog": None, "prepared": False, "ticks": 0}
    def steer():
        try:
            dialog = next((w for w in app.topLevelWidgets() if isinstance(w, QFileDialog) and w.isVisible()), None)
            if dialog is None:
                if time.monotonic() > deadline:
                    raise AssertionError("Actual Qt file dialog did not open")
                return
            if not stage["prepared"]:
                stage["dialog"] = dialog
                stage["prepared"] = True
                if requested is not None:
                    dialog.selectNameFilter("All files (*)")
                    dialog.setDirectory(str(requested.parent))
                    dialog.selectFile(requested.name)
                if during:
                    during()
                return
            stage["ticks"] += 1
            if stage["ticks"] < 3:
                return
            selected = dialog.selectedFiles()
            observations.append({
                "case": case_name, "requested": str(requested) if requested else None,
                "native_selected_files_before_close": selected,
                "cancel": cancel, "visible": dialog.isVisible(),
                "caption": dialog.windowTitle(), "dialog_class": dialog.metaObject().className(),
            })
            timer.stop()
            if cancel:
                QTest.keyClick(dialog, Qt.Key.Key_Escape)
            else:
                assert len(selected) == 1 and Path(selected[0]).samefile(requested), selected
                assert Path(selected[0]).name == requested.name, (selected, requested.name)
                box = dialog.findChild(QDialogButtonBox)
                button = next(b for b in box.buttons() if box.buttonRole(b) == QDialogButtonBox.ButtonRole.AcceptRole)
                assert button.isEnabled()
                QTest.mouseClick(button, Qt.MouseButton.LeftButton)
        except BaseException:
            callback_errors.append(traceback.format_exc())
            timer.stop()
            if stage["dialog"] is not None:
                stage["dialog"].reject()
    timer.timeout.connect(steer)
    timer.start(40)
    press(choose_button)
    timer.stop()
    assert not callback_errors, callback_errors
    assert len(observations) == 1, observations
    REPORT["dialogs"].extend(observations)
    return observations[0]["native_selected_files_before_close"][0] if not cancel else None

def dismiss_messages():
    try:
        for box in app.topLevelWidgets():
            if isinstance(box, QMessageBox) and box.isVisible():
                REPORT["messages"].append({"case": case_name, "title": box.windowTitle(), "text": box.text()})
                box.accept()
    except BaseException:
        callback_errors.append(traceback.format_exc())

message_timer = QTimer()
message_timer.timeout.connect(dismiss_messages)
message_timer.start(25)

def observed_run(package, params=None, **kwargs):
    row = {
        "case": case_name, "package": str(package), "params_at_entry": copy.deepcopy(params.to_dict()),
        "thread_id": threading.get_ident(), "on_main_thread": threading.get_ident() == MAIN_THREAD,
    }
    REPORT["jobs"].append(row)
    if GATE["active"]:
        GATE["entered"].set()
        if not GATE["release"].wait(15):
            raise AssertionError("Receiver-controlled scheduling gate was not released")
    try:
        result = actual_run(package, params, **kwargs)
        row.update({"job_dir": str(result.job_dir), "status": result.status})
        return result
    except BaseException as error:
        row.update({"error": str(error), "notes": list(getattr(error, "__notes__", ()))})
        raise

capture_analysis.run = observed_run

class ObservedScreen(AnalysisScreen):
    def __init__(self):
        self.reservations = []
        super().__init__(CaptureState())
    def _sync_enabled(self):
        super()._sync_enabled()
        control = self.findChild(QWidget, "EvaluationInput")
        self.reservations.append({
            "case": case_name, "reserved": self._thread is not None,
            "running": self._thread.isRunning() if self._thread is not None else False,
            "evaluation_enabled": control.isEnabled(),
        })

def set_eval(screen, fixture_value):
    screen.set_package(str(fixture_value["package"]))
    screen._command.setCurrentIndex(screen._command.findData("eval"))
    screen._extras._bundle_job.setEditText("bundle")
    app.processEvents()
    assert screen._summary is not None
    assert screen._extras.build_extra("eval")["ml_bundle_job_id"] == "bundle"

def run_screen(screen):
    count = len(REPORT["jobs"])
    press(screen._btn_run)
    wait_until(lambda: screen._thread is None and len(REPORT["jobs"]) > count)
    row = REPORT["jobs"][-1]
    assert row["on_main_thread"] is False
    return row

def check_external(row, f, selected, expected_document):
    assert row.get("status") in ("completed", "completed_with_warnings"), row
    folder = Path(row["job_dir"])
    params = json.loads((folder / "params.json").read_text())
    assert params == row["params_at_entry"]
    assert params["extra"] == {"ml_bundle_job_id": "bundle", "prediction_path": selected}
    result = json.loads((folder / "eval/eval_report.json").read_text())
    assert result["evaluationMode"] == "external_predictions" and result["baseline"] is None
    assert result["modelId"] == expected_document["modelId"]
    assert result["sessionId"] == "independent-ui-" + f["package"].stem
    assert result["mlBundleJobId"] == "bundle" and result["windowCount"] == 4
    original = Path(selected).read_bytes()
    assert (folder / "eval/prediction_input.json").read_bytes() == original
    assert (folder / "eval/source_bundle_manifest.json").read_bytes() == f["manifest"].read_bytes()
    provenance = result["inputProvenance"]
    assert provenance["predictionsSha256"] == sha(original)
    assert provenance["windowsSha256"] == sha(f["windows"].read_bytes())
    assert provenance["manifestSha256"] == sha(f["manifest"].read_bytes())
    actual = pd.read_parquet(folder / "eval/predictions.parquet")
    assert actual["window_id"].tolist() == f["ids"]
    assert [int(x) for x in actual["session_time_ns"]] == f["times"]
    supplied = {x["window_id"]: x["values"][f["column"]] for x in expected_document["predictions"]}
    assert actual["y_hat_" + f["column"]].tolist() == [supplied[key] for key in f["ids"]]
    assert actual["y_teacher_" + f["column"]].tolist() == f["teacher"]
    assert result["metrics"][f["column"]]["mae"] > 0, "Selected external predictions must not be identity output."
    job_manifest = json.loads((folder / "job_manifest.json").read_text())
    entries = {item["relativePath"]: item for item in job_manifest["outputs"]}
    for relative in ("eval/prediction_input.json", "eval/source_bundle_manifest.json", "eval/eval_report.json", "params.json"):
        data = (folder / relative).read_bytes()
        assert entries[relative]["bytes"] == len(data) and entries[relative]["sha256"] == sha(data)
    row["verified_provenance"] = provenance
    row["verified_model_label"] = result["modelId"]
    row["retained_input_sha256"] = sha(original)

def failed_job(package, row, expected_extra):
    assert "error" in row and "status" not in row, row
    matches = []
    for folder in (package / "processing/jobs").iterdir():
        path = folder / "job_manifest.json"
        if path.is_file():
            value = json.loads(path.read_text())
            if value.get("status") == "failed":
                params = json.loads((folder / "params.json").read_text())
                if params["extra"] == expected_extra:
                    matches.append((folder, value, params))
    assert len(matches) == 1, matches
    folder, manifest, params = matches[0]
    assert not (folder / "eval").exists(), "Refused external input must not create identity/evaluation outputs."
    assert params == row["params_at_entry"]
    assert manifest["errors"] and row["error"] in manifest["errors"]
    row["retained_failed_job"] = str(folder)

screen = None
extras = None
try:
    ordinary = fixture("ordinary")
    other = fixture("other")
    scheduled = fixture("scheduled")
    empty = fixture("empty")
    extras = AnalysisJobExtras()
    extras.resize(600, 450)
    extras.set_package(str(ordinary["package"]))
    extras.set_command("eval")
    extras._bundle_job.setEditText("bundle")
    extras.show()
    app.processEvents()
    assert mode_control(extras).currentData() == "identity"
    assert extras.build_extra("eval") == {"ml_bundle_job_id": "bundle"}
    case_name = "Actual Qt choices, cancellation, path identity and command/package isolation"
    mode(extras, "external")
    assert extras.validate_for("eval") == "Choose a predictions JSON file for external evaluation."
    assert extras.build_extra("eval")["prediction_path"] == ""
    selected = choose(extras, ordinary["a"])
    assert path_control(extras).text() == selected
    assert selected.endswith(".json "), "Significant native POSIX trailing filename space is retained."
    assert extras.validate_for("eval") is None
    path_control(extras).setFocus()
    QTest.keyClicks(path_control(extras), "not-editable")
    assert path_control(extras).text() == selected
    choose(extras, ordinary["b"], cancel=True)
    assert path_control(extras).text() == selected
    mode(extras, "identity")
    assert "prediction_path" not in extras.build_extra("eval")
    mode(extras, "external")
    assert extras.build_extra("eval")["prediction_path"] == selected
    extras.refresh()
    extras.set_package(str(ordinary["package"] / "."))
    assert extras.build_extra("eval")["prediction_path"] == selected
    extras._pose_job.setEditText("kept-pose")
    extras._kin_job.setEditText("kept-kin")
    extras._feat_job.setEditText("kept-features")
    extras._window_sec.setText("1.25")
    extras._hop_sec.setText("0.125")
    for command in ("qc", "all", "features", "plots", "pose", "kinematics", "ml_bundle"):
        extras.set_command(command)
        assert "prediction_path" not in extras.build_extra(command)
    assert extras.build_extra("kinematics") == {"pose_job_id": "kept-pose"}
    assert extras.build_extra("ml_bundle") == {
        "kinematics_job_id": "kept-kin", "features_job_id": "kept-features",
        "window_sec": 1.25, "hop_sec": 0.125,
    }
    assert extras._window_sec.isVisible()
    extras.set_command("eval")
    assert not extras._window_sec.isVisible()
    assert path_control(extras).text() == selected
    extras.set_package(str(other["package"]))
    assert mode_control(extras).currentData() == "external" and path_control(extras).text() == ""
    assert extras.validate_for("eval") is not None
    extras.set_package(str(ordinary["package"]))
    selected = choose(extras, ordinary["a"])
    for label, action in (
        # Context changes while a modal chooser is open are explicit controller
        # controls; ordinary mode choices above use actual keyboard events.
        ("mode", lambda: (mode_control(extras).setCurrentIndex(0), mode_control(extras).setCurrentIndex(1))),
        ("command", lambda: (extras.set_command("qc"), extras.set_command("eval"))),
        ("busy", lambda: (extras.set_eval_busy(True), extras.set_eval_busy(False))),
    ):
        case_name = "Late actual chooser result retired after " + label
        choose(extras, ordinary["b"], during=action)
        assert path_control(extras).text() == selected
    case_name = "Late actual chooser result retired after package replacement"
    choose(extras, ordinary["b"], during=lambda: extras.set_package(str(other["package"])))
    assert path_control(extras).text() == "" and mode_control(extras).currentData() == "external"
    extras.set_package(str(ordinary["package"]))
    selected = choose(extras, ordinary["a"])
    extras.grab().save(str(OUT / "evaluation-input-native.png"))
    REPORT["screenshots"].append("evaluation-input-native.png")
    press(extras.findChild(QPushButton, "EvalPredictionClear"))
    assert path_control(extras).text() == "" and mode_control(extras).currentData() == "external"
    assert app.focusWidget() is extras.findChild(QPushButton, "EvalPredictionChoose")
    REPORT["cases"].append({"name": "Native dialog/action and state isolation", "passed": True,
                            "native_selected_path": selected, "preserved_non_eval_values": True})
    extras.close()

    screen = ObservedScreen()
    screen.resize(1540, 1100)
    screen.show()
    set_eval(screen, ordinary)
    case_name = "Actual workbench external evaluation"
    mode(screen, "external")
    selected = choose(screen, ordinary["a"])
    row = run_screen(screen)
    check_external(row, ordinary, selected, json.loads(ordinary["a"].read_text()))
    assert any(x["reserved"] and not x["running"] and not x["evaluation_enabled"] for x in screen.reservations)
    assert screen.findChild(QWidget, "EvaluationInput").isEnabled()
    screen.grab().save(str(OUT / "workbench-external-native.png"))
    REPORT["screenshots"].append("workbench-external-native.png")

    case_name = "Actual identity run with a retained previous file path"
    mode(screen, "identity")
    assert path_control(screen).text() == selected
    row = run_screen(screen)
    assert "prediction_path" not in row["params_at_entry"]["extra"]
    folder = Path(row["job_dir"])
    identity = json.loads((folder / "eval/eval_report.json").read_text())
    assert identity["baseline"] == "identity_teacher_sim"
    assert "modelId" not in identity and "inputProvenance" not in identity
    assert not (folder / "eval/prediction_input.json").exists()
    frame = pd.read_parquet(folder / "eval/predictions.parquet")
    assert frame["y_hat_" + ordinary["column"]].tolist() == ordinary["teacher"]

    case_name = "Actual refused external binding and visible recovery"
    mode(screen, "external")
    bad_selected = choose(screen, ordinary["invalid"])
    assert screen._extras.validate_for("eval") is None, "JSON/source admission belongs to the evaluator."
    row = run_screen(screen)
    failed_job(ordinary["package"], row, {"ml_bundle_job_id": "bundle", "prediction_path": bad_selected})
    assert "manifestSha256 does not match" in row["error"]
    assert any(m["case"] == case_name and "manifestSha256 does not match" in m["text"] for m in REPORT["messages"])
    assert mode_control(screen).currentData() == "external"
    assert path_control(screen).text() == bad_selected
    case_name = "Actual workbench retry with the newly chosen valid file"
    replacement = choose(screen, ordinary["b"])
    row = run_screen(screen)
    check_external(row, ordinary, replacement, json.loads(ordinary["b"].read_text()))
    REPORT["cases"].append({"name": "Native workbench real external, identity, refusal and retry", "passed": True})

    case_name = "Queued job snapshot and execution-time file bytes"
    set_eval(screen, scheduled)
    mode(screen, "external")
    queued_path = choose(screen, scheduled["a"])
    queued_extra = copy.deepcopy(screen._extras.build_extra("eval"))
    initial_bytes = scheduled["a"].read_bytes()
    GATE["active"] = True
    GATE["entered"].clear()
    GATE["release"].clear()
    count = len(REPORT["jobs"])
    press(screen._btn_run)
    wait_until(GATE["entered"].is_set, timeout=8)
    assert screen._thread is not None and screen._thread.isRunning()
    assert not screen.findChild(QWidget, "EvaluationInput").isEnabled()
    QTest.mouseClick(screen.findChild(QPushButton, "EvalPredictionClear"), Qt.MouseButton.LeftButton)
    assert path_control(screen).text() == queued_path
    # This old dependency picker remains editable by the established screen.
    assert screen._extras._bundle_job.isEnabled()
    screen._extras._bundle_job.setFocus()
    screen._extras._bundle_job.lineEdit().selectAll()
    QTest.keyClicks(screen._extras._bundle_job.lineEdit(), "alternate")
    assert screen._extras.build_extra("eval")["ml_bundle_job_id"] == "alternate"
    assert REPORT["jobs"][-1]["params_at_entry"]["extra"] == queued_extra
    replacement_document = scheduled["predictions"]("Receiver file bytes changed before execution", 4.5)
    write_json(scheduled["a"], replacement_document)
    REPORT["scheduled_file_control"] = {
        "path": queued_path, "selected_sha256": sha(initial_bytes),
        "execution_sha256": sha(scheduled["a"].read_bytes()),
        "meaning": "Explicit receiver-authored file replacement before the unchanged evaluator runs; the UI promises a path, not a selected-byte snapshot.",
    }
    GATE["release"].set()
    wait_until(lambda: screen._thread is None and len(REPORT["jobs"]) > count)
    GATE["active"] = False
    row = REPORT["jobs"][-1]
    check_external(row, scheduled, queued_path, replacement_document)
    assert row["params_at_entry"]["extra"]["ml_bundle_job_id"] == "bundle"
    REPORT["cases"].append({"name": "Queued worker captures dependency/path while evaluator binds actual execution bytes", "passed": True})

    case_name = "Empty external UI validation and real worker backstop"
    set_eval(screen, empty)
    mode(screen, "external")
    assert path_control(screen).text() == ""
    expected_extra = screen._extras.build_extra("eval")
    assert expected_extra == {"ml_bundle_job_id": "bundle", "prediction_path": ""}
    count = len(REPORT["jobs"])
    messages_before = len(REPORT["messages"])
    press(screen._btn_run)
    assert screen._thread is None and len(REPORT["jobs"]) == count
    assert len(REPORT["messages"]) > messages_before
    assert "Choose a predictions JSON file" in REPORT["messages"][-1]["text"]
    # Deliberately bypass frontend validation, preserving its exact explicit-empty extra.
    thread = QThread()
    worker = _AnalysisWorker(str(empty["package"]), "eval", "mask", expected_extra)
    worker.moveToThread(thread)
    outcome = []
    worker.failed.connect(lambda message: outcome.append({"failed": message}))
    worker.finished.connect(lambda result: outcome.append({"unexpected_success": str(result)}))
    worker.failed.connect(thread.quit)
    worker.finished.connect(thread.quit)
    thread.started.connect(worker.run)
    thread.finished.connect(worker.deleteLater)
    all_threads.append((thread, worker))
    thread.start()
    wait_until(lambda: outcome and not thread.isRunning())
    assert len(outcome) == 1 and "failed" in outcome[0]
    assert "evaluation input is not a file" in outcome[0]["failed"]
    failed_job(empty["package"], REPORT["jobs"][-1], expected_extra)
    REPORT["cases"].append({"name": "Explicit-empty external stays rejected through skipped frontend validation", "passed": True})
    REPORT["reservations"] = screen.reservations
    assert not callback_errors
    assert len(REPORT["jobs"]) == 6
    assert all(not row["on_main_thread"] for row in REPORT["jobs"])
    for path, digest in protected.items():
        assert sha(Path(path).read_bytes()) == digest, path
    REPORT["protected_package_and_bundle_files"] = [{"path": path, "sha256": digest} for path, digest in protected.items()]
    REPORT["passed"] = True
except BaseException:
    REPORT["passed"] = False
    REPORT["failure"] = traceback.format_exc()
    print(REPORT["failure"], flush=True)
finally:
    GATE["release"].set()
    capture_analysis.run = actual_run
    if screen is not None and screen._thread is not None:
        screen._cancel_job()
        try:
            wait_until(lambda: screen._thread is None, timeout=20)
        except BaseException:
            REPORT["cleanup_failure"] = traceback.format_exc()
    for thread, worker in all_threads:
        if thread.isRunning():
            worker.request_cancel()
            thread.quit()
            thread.wait(10000)
    message_timer.stop()
    for widget in app.topLevelWidgets():
        widget.close()
        widget.deleteLater()
    QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
    app.processEvents()
    imported = {}
    for name, module in list(sys.modules.items()):
        filename = getattr(module, "__file__", None)
        if not filename:
            continue
        path = Path(filename).resolve()
        try:
            relative = path.relative_to(SOURCE).as_posix()
        except ValueError:
            continue
        if path.is_file():
            data = path.read_bytes()
            digest = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
            assert relative in tree and digest == tree[relative]["git_blob"], relative
            imported[relative] = {"bytes": len(data), "sha256": sha(data), "git_blob": digest}
    for path, digest in EXPECTED.items():
        assert sha((SOURCE / path).read_bytes()) == digest, path
    assert not git("status", "--porcelain")
    REPORT["imported_project_source"] = imported
    REPORT["source_unchanged"] = True
    REPORT["callback_errors"] = callback_errors
    write_json(OUT / "receiving.json", REPORT)
print(json.dumps({"passed": REPORT["passed"], "cases": len(REPORT["cases"]),
                  "actual_jobs": len(REPORT["jobs"]), "actual_dialogs": len(REPORT["dialogs"]),
                  "imported_source_files": len(REPORT["imported_project_source"]), "output": str(OUT)}), flush=True)
raise SystemExit(0 if REPORT["passed"] else 1)
