# SPDX-License-Identifier: GPL-3.0-only
"""Freeze exact independent native UI/job evidence; no native test replay."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import struct
import subprocess
import tarfile

parser = argparse.ArgumentParser()
parser.add_argument("--source", required=True)
args = parser.parse_args()
base = Path(__file__).resolve().parent
source = Path(args.source).resolve()
packet = base / "functional-packet"
packet.mkdir(exist_ok=False)
def sha(data):
    return hashlib.sha256(data).hexdigest()
def document(path):
    return json.loads(path.read_text(encoding="utf8"))
def save_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf8")
def put(original, relative):
    data = original.read_bytes()
    target = packet / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    assert target.read_bytes() == data
    return {"path": relative, "bytes": len(data), "sha256": sha(data)}
def git(*arguments):
    return subprocess.check_output(["git", *arguments], cwd=source, env=dict(os.environ, GIT_OPTIONAL_LOCKS="0"), text=True).strip()

report = document(base / "r4/receiving.json")
assert report["passed"] and len(report["cases"]) == 4 and len(report["jobs"]) == 6
assert len(report["dialogs"]) == 12 and len(report["imported_project_source"]) == 69
assert report["source_commit"] == git("rev-parse", "HEAD") == "424298e30d6e0f08fe4124fa282328575c40d203"
assert report["source_tree"] == git("rev-parse", "HEAD^{tree}") == "b69adfdf45711035963094b811760500cb76c966"
assert report["parent"] == git("rev-parse", "HEAD^") == "d7459fa62dd7a57d5565214e10638e055ad5877c"
assert not git("status", "--porcelain")
assert set(git("diff-tree", "--no-commit-id", "--name-only", "-r", "HEAD").splitlines()) == set(report["owned_source_sha256"])
tree = {}
for line in git("ls-tree", "-r", "HEAD").splitlines():
    metadata, relative = line.split("\t", 1)
    mode, kind, blob = metadata.split()
    if kind == "blob":
        tree[relative] = {"mode": mode, "git_blob": blob}
save_json(packet / "source-tree.json", {"commit": report["source_commit"], "tree": report["source_tree"], "parent": report["parent"], "leaves": tree})
wanted = set(report["imported_project_source"]) | set(report["owned_source_sha256"])
wanted.update(("AGENTS.md", "pyproject.toml", "schemas/kinematics/kinematics_columns.registry.json"))
for name in ("LICENSE", "LICENSE.md", "COPYING"):
    if name in tree:
        wanted.add(name)
source_files = {}
for relative in sorted(wanted):
    data = (source / relative).read_bytes()
    blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
    assert blob == tree[relative]["git_blob"], relative
    if relative in report["imported_project_source"]:
        assert sha(data) == report["imported_project_source"][relative]["sha256"], relative
    if relative in report["owned_source_sha256"]:
        assert sha(data) == report["owned_source_sha256"][relative], relative
    source_files[relative] = put(source / relative, "source/" + relative) | tree[relative]
registry = source / "schemas/kinematics/kinematics_columns.registry.json"
for row in report["jobs"]:
    if "verified_provenance" in row:
        assert sha(registry.read_bytes()) == row["verified_provenance"]["kinematicsRegistrySha256"]

for attempt in ("r1", "r2", "r3", "r4"):
    attempt_report = document(base / attempt / "receiving.json")
    receiver = base / attempt / "receive-native-evaluation.py"
    assert sha(receiver.read_bytes()) == attempt_report["receiver_sha256"], attempt
    assert attempt_report["source_commit"] == report["source_commit"]
    assert attempt_report["source_unchanged"]
    destination = "actual" if attempt == "r4" else "receiver-corrections/" + attempt
    put(base / attempt / "receiving.json", destination + "/receiving.json")
    put(receiver, ("receiver" if attempt == "r4" else destination) + "/receive-native-evaluation.py")
    if attempt != "r4":
        assert not attempt_report["passed"] and not attempt_report["jobs"]
put(base / "native-execution.json", "native-execution.json")
put(base / "README-functional.md", "README.md")
put(Path(__file__), "freeze-functional.py")

r4 = base / "r4"
for folder in sorted([r4 / "inputs", *r4.glob("*.mmsession")]):
    assert folder.is_dir()
    for path in sorted(folder.rglob("*")):
        if path.is_file():
            assert not path.is_symlink()
            put(path, "actual/" + path.relative_to(r4).as_posix())
for relative in report["screenshots"]:
    data = (r4 / relative).read_bytes()
    assert data[:8] == b"\x89PNG\r\n\x1a\n"
    put(r4 / relative, "actual/" + relative)

job_checks = []
for row in report["jobs"]:
    folder = Path(row.get("job_dir") or row["retained_failed_job"])
    assert folder.is_relative_to(r4)
    manifest = document(folder / "job_manifest.json")
    params = document(folder / "params.json")
    assert params == row["params_at_entry"]
    outputs = []
    for entry in manifest["outputs"]:
        relative = Path(entry["relativePath"])
        assert not relative.is_absolute() and ".." not in relative.parts
        data = (folder / relative).read_bytes()
        assert len(data) == entry["bytes"] and sha(data) == entry["sha256"], (folder, relative)
        outputs.append({"path": relative.as_posix(), "bytes": len(data), "sha256": sha(data)})
    if "error" in row:
        assert manifest["status"] == "failed" and not (folder / "eval").exists()
    else:
        assert manifest["status"] == row["status"] == "completed_with_warnings"
    if "verified_provenance" in row:
        supplied = Path(row["params_at_entry"]["extra"]["prediction_path"]).read_bytes()
        assert (folder / "eval/prediction_input.json").read_bytes() == supplied
        assert sha(supplied) == row["verified_provenance"]["predictionsSha256"]
        actual_report = document(folder / "eval/eval_report.json")
        assert actual_report["inputProvenance"] == row["verified_provenance"]
        assert actual_report["modelId"] == row["verified_model_label"]
    job_checks.append({"case": row["case"], "folder": folder.relative_to(r4).as_posix(), "status": manifest["status"], "outputs": outputs})
for entry in report["protected_package_and_bundle_files"]:
    assert sha(Path(entry["path"]).read_bytes()) == entry["sha256"]

# The unchanged earlier scheduled fixture supplies the exact selected-byte
# control that the r4 scheduling challenge deliberately overwrote in place.
initial = base / "r3/inputs/scheduled/ predictions café A.json "
assert sha(initial.read_bytes()) == report["scheduled_file_control"]["selected_sha256"]
put(initial, "actual/scheduled-input-before-execution.json")
save_json(packet / "file-audit.json", {
    "source_commit": report["source_commit"], "source_tree": report["source_tree"],
    "receiver_sha256": report["receiver_sha256"], "passed": True,
    "source_files": source_files, "actual_jobs": job_checks,
    "protected_file_count": len(report["protected_package_and_bundle_files"]),
    "scheduled_initial_copy": {"source": str(initial), "sha256": sha(initial.read_bytes()),
        "meaning": "Exact same bytes/hash as the r4 recorded selection; retained from the unmodified r3 fixture, not falsely labeled as a new r4 file read."},
    "visual_review": {"reviewer": "github_integration", "images": report["screenshots"],
        "scope": "Original 1540x1100 workbench and 600x450 standalone extras inspected; minimum shell layout is a separate successor gate."},
})
assert not git("status", "--porcelain")
members = []
for path in sorted(packet.rglob("*")):
    if path.is_file():
        data = path.read_bytes()
        members.append({"path": path.relative_to(packet).as_posix(), "bytes": len(data), "sha256": sha(data)})
save_json(packet / "MANIFEST.json", {"files": members})
archive = base / "capturesuite69-functional-receiving.tar.gz"
with tarfile.open(archive, "w:gz", format=tarfile.PAX_FORMAT) as stream:
    for path in sorted(packet.rglob("*")):
        if path.is_file():
            stream.add(path, arcname=path.relative_to(packet).as_posix(), recursive=False)
expected = {row["path"]: row for row in members}
manifest_bytes = (packet / "MANIFEST.json").read_bytes()
expected["MANIFEST.json"] = {"bytes": len(manifest_bytes), "sha256": sha(manifest_bytes)}
with tarfile.open(archive, "r:gz") as stream:
    assert set(stream.getnames()) == set(expected)
    for entry in stream.getmembers():
        assert entry.isfile()
        data = stream.extractfile(entry).read()
        assert len(data) == expected[entry.name]["bytes"] and sha(data) == expected[entry.name]["sha256"]
data = archive.read_bytes()
summary = {
    "archive": str(archive), "bytes": len(data), "sha256": sha(data), "members": len(expected),
    "manifest_sha256": sha(manifest_bytes), "receipt_sha256": sha((r4 / "receiving.json").read_bytes()),
    "file_audit_sha256": sha((packet / "file-audit.json").read_bytes()),
    "source_commit": report["source_commit"], "source_tree": report["source_tree"],
    "receiver_sha256": report["receiver_sha256"], "source_files": len(source_files),
    "actual_jobs": len(job_checks), "source_unchanged": True,
}
save_json(base / "functional-packet.json", summary)
print(json.dumps(summary), flush=True)
