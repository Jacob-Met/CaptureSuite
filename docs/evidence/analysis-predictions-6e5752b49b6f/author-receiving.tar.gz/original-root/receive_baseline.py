from pathlib import Path
import os, sys, json, hashlib, tomllib
root=Path('/tmp/capturesuite-prediction-ui-6e5752b49b6f-production')
source=root/'source'; out=root/'baseline-native';out.mkdir(exist_ok=True)
for key,leaf in [('LOCALAPPDATA','local'),('APPDATA','roaming'),('XDG_CONFIG_HOME','config'),('XDG_DATA_HOME','data'),('XDG_CACHE_HOME','cache')]:
 path=out/leaf;path.mkdir(exist_ok=True);os.environ[key]=str(path)
os.environ['QT_QPA_PLATFORM']='offscreen'
os.environ['MPLCONFIGDIR']=str(out/'matplotlib')
for p in tomllib.loads((source/'pyproject.toml').read_text())['tool']['pytest']['ini_options']['pythonpath']:
 sys.path.insert(0,str(source/p))
from PySide6.QtWidgets import QApplication,QComboBox,QPushButton,QLineEdit
from PySide6.QtCore import QCoreApplication,QEvent,qVersion
from capture_desktop import theme
from capture_desktop.screen_analysis import AnalysisScreen
from capture_desktop.state import CaptureState
app=QApplication([])
theme.apply_theme(app,setting='dark')
screen=AnalysisScreen(CaptureState())
screen.resize(1420,1000)
screen.set_package(str(source/'tests/fixtures/mini_session'))
screen._command.setCurrentIndex(screen._command.findData('eval'))
screen._extras._bundle_job.setEditText('fixture-bundle')
screen.show();app.processEvents()
report={
 'source_commit':'f6ff65d54756fef57ace4e693f52039e8ca59360',
 'python':sys.version,'qt':qVersion(),
 'combos':[[c.itemText(i) for i in range(c.count())] for c in screen._extras.findChildren(QComboBox)],
 'buttons':[b.text() for b in screen._extras.findChildren(QPushButton)],
 'extra':screen._extras.build_extra('eval'),
 'external_mode_available':any(c.findData('external')>=0 for c in screen._extras.findChildren(QComboBox)),
 'mode_control_present':screen.findChild(QComboBox,'EvalInputMode') is not None,
 'prediction_path_present':screen.findChild(QLineEdit,'EvalPredictionPath') is not None,
}
assert report['extra']=={'ml_bundle_job_id':'fixture-bundle'}
assert not report['external_mode_available'] and not report['mode_control_present'] and not report['prediction_path_present']
assert screen.grab().save(str(out/'eval-before.png'),'PNG')
report['screenshot_sha256']=hashlib.sha256((out/'eval-before.png').read_bytes()).hexdigest()
screen.close();screen.deleteLater();QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete);app.processEvents()
(out/'absence.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
