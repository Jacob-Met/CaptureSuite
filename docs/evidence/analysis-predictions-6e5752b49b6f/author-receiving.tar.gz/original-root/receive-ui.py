# SPDX-License-Identifier: GPL-3.0-only
"""Receive actual workbench presentation and one generated external job."""
from pathlib import Path
import os,sys,json,hashlib,tomllib,subprocess
ROOT=Path('/tmp/capturesuite-prediction-ui-6e5752b49b6f-production')
SOURCE=ROOT/'source';OUT=ROOT/'native-ui';OUT.mkdir(exist_ok=True)
for key,leaf in [('LOCALAPPDATA','local'),('APPDATA','roaming'),('XDG_CONFIG_HOME','config'),('XDG_DATA_HOME','data'),('XDG_CACHE_HOME','cache')]:
 path=OUT/leaf;path.mkdir(exist_ok=True);os.environ[key]=str(path)
os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['MPLCONFIGDIR']=str(OUT/'matplotlib')
sys.path.insert(0,str(SOURCE))
for rel in tomllib.loads((SOURCE/'pyproject.toml').read_text())['tool']['pytest']['ini_options']['pythonpath']:
 sys.path.insert(0,str(SOURCE/rel))
from PySide6.QtCore import QCoreApplication,QEvent,QPoint,qVersion
from PySide6.QtWidgets import QApplication,QMessageBox
from capture_desktop import theme
from tests.analysis.test_external_predictions import _fixture
from tests.ui.test_analysis_predictions import _screen,_external,_real_choose,_wait
source_manifest=json.loads((ROOT/'current-source-r2.json').read_text())
for p,wanted in source_manifest['source_sha256'].items():
 assert hashlib.sha256((SOURCE/p).read_bytes()).hexdigest()==wanted
app=QApplication([]);theme.apply_theme(app,setting='dark')
fixture=OUT/'fixture';fixture.mkdir(exist_ok=True)
package,predictions,windows,manifest=_fixture(fixture)
renamed=predictions.with_name(' external predictions café .json')
predictions.rename(renamed);predictions=renamed
before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [*package.rglob('*'),predictions] if p.is_file()}
screen=_screen(app,package);screen.resize(1420,1000);app.processEvents()
assert screen.grab().save(str(OUT/'identity-before.png'),'PNG')
control=_external(screen._extras)
chosen=_real_choose(control,predictions)
screen.resize(1280,960);app.processEvents()
def geometry(widget):
 point=widget.mapTo(screen,QPoint(0,0));return {'x':point.x(),'y':point.y(),'width':widget.width(),'height':widget.height(),'visible':widget.isVisible()}
def within(widget):
 point=widget.mapTo(screen,QPoint(0,0))
 return 0<=point.x() and 0<=point.y() and point.x()+widget.width()<=screen.width() and point.y()+widget.height()<=screen.height()
assert within(control) and within(screen._btn_run)
assert screen.grab().save(str(OUT/'external-dark-before.png'),'PNG')
errors=[];original_warning=QMessageBox.warning
QMessageBox.warning=lambda *_a:errors.append(_a[-1])
try:
 screen._btn_run.click()
 assert screen._thread is not None and not control.isEnabled()
 _wait(screen,app)
 assert not errors and control.isEnabled()
 job=Path(screen._last_job_dir)
 report=json.loads((job/'eval/eval_report.json').read_text())
 params=json.loads((job/'params.json').read_text())
 assert params['extra']=={'ml_bundle_job_id':'bundle','prediction_path':chosen}
 assert report['evaluationMode']=='external_predictions' and report['baseline'] is None
 assert (job/'eval/prediction_input.json').read_bytes()==predictions.read_bytes()
 for filename,wanted in before.items():assert hashlib.sha256(Path(filename).read_bytes()).hexdigest()==wanted
 screen._log.verticalScrollBar().setValue(screen._log.verticalScrollBar().maximum())
 app.processEvents();assert screen.grab().save(str(OUT/'external-dark-complete.png'),'PNG')
 theme.apply_theme(app,setting='light');app.processEvents()
 assert screen.grab().save(str(OUT/'external-light-complete.png'),'PNG')
 receipt={'source_commit':source_manifest['head'],'source_tree':source_manifest['tree'],'source_sha256':source_manifest['source_sha256'],'python':sys.version,'qt':qVersion(),'platform':'Mac offscreen Qt; no Windows hardware/Open job folder execution claim','requested_window':[1280,960],'actual_window':[screen.width(),screen.height()],'evaluation_geometry':geometry(control),'run_geometry':geometry(screen._btn_run),'input_geometry':geometry(control._path),'visible_mode_label':control._mode.currentText(),'path_returned_by_actual_dialog':chosen,'path_received_by_job':params['extra']['prediction_path'],'job_dir':str(job),'report':report,'raw_and_bundle_inputs_unchanged':True,'retained_prediction_bytes_equal':True,'job_outputs':json.loads((job/'job_manifest.json').read_text())['outputs'],'gallery_tabs':[screen._gallery._tabs.tabText(i) for i in range(screen._gallery._tabs.count())],'images':{p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(OUT.glob('*.png'))}}
 for p,wanted in source_manifest['source_sha256'].items():assert hashlib.sha256((SOURCE/p).read_bytes()).hexdigest()==wanted
 receipt['source_unchanged']=True
 (OUT/'receiving.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n')
 print(json.dumps({k:receipt[k] for k in ['source_commit','requested_window','actual_window','evaluation_geometry','job_dir','gallery_tabs','source_unchanged']}))
finally:
 QMessageBox.warning=original_warning
 if screen._thread is not None:
  screen._cancel_job();_wait(screen,app)
 screen.close();screen.deleteLater();QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete);app.processEvents()
