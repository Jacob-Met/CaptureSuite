from pathlib import Path
import os,json,hashlib,subprocess,time
root=Path('/tmp/capturesuite-prediction-ui-6e5752b49b6f-production');source=root/'source-layout';out=root/'native-layout-r2';out.mkdir(exist_ok=True)
python='/Users/Shared/hamon-cs22503/togishi-main-repro-venv-20261006/bin/python'
env=dict(os.environ,QT_QPA_PLATFORM='offscreen',PYTHONDONTWRITEBYTECODE='1',MPLCONFIGDIR=str(out/'matplotlib'),TMPDIR=str(out))
paths=['desktop/capture_desktop/widgets_analysis_predictions.py','desktop/capture_desktop/widgets_analysis_jobs.py','desktop/capture_desktop/screen_analysis.py','tests/ui/test_analysis_predictions.py']
before={p:hashlib.sha256((source/p).read_bytes()).hexdigest() for p in paths}
cmd=[python,'-B','-m','ruff','check',*paths]
p=subprocess.run(cmd,cwd=source,env=env,capture_output=True,text=True,timeout=30)
ruff={'command':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr};(out/'ruff.json').write_text(json.dumps(ruff,indent=2)+'\n')
if p.returncode:
 print(json.dumps(ruff));raise SystemExit(p.returncode)
def git(*args):
 p=subprocess.run(['git',*args],cwd=source,capture_output=True,text=True,timeout=30);assert p.returncode==0,(args,p.stdout,p.stderr);return p.stdout.strip()
git('diff','--check');git('add','--','desktop/capture_desktop/screen_analysis.py','tests/ui/test_analysis_predictions.py','docs/design/research/EXTERNAL_EVALUATION_WORKBENCH.md')
git('-c','user.name=HAMON production_slice','-c','user.email=hamon@local','commit','-m','fix(analysis): keep evaluation controls reachable and jobs cancellable')
head=git('rev-parse','HEAD');tree=git('rev-parse','HEAD^{tree}')
receipt={'source_commit':head,'source_tree':tree,'source_sha256':before,'ruff':ruff}
cmd=[python,'-B','-m','pytest','-v','-p','no:cacheprovider','--basetemp',str(out/'pytest'),'--junitxml',str(out/'junit.xml'),'tests/ui/test_analysis_predictions.py','tests/ui/test_analysis_workbench.py::test_analysis_job_extras_validate','tests/ui/test_analysis_workbench.py::test_analysis_screen_no_plot_startfile']
started=time.monotonic()
with (out/'stdout.txt').open('w') as log:
 try:
  p=subprocess.run(cmd,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
  receipt.update({'command':cmd,'exit_code':p.returncode,'seconds':time.monotonic()-started})
 except subprocess.TimeoutExpired:receipt.update({'command':cmd,'timeout':120,'seconds':time.monotonic()-started})
after={p:hashlib.sha256((source/p).read_bytes()).hexdigest() for p in paths};assert before==after
receipt['source_unchanged']=True
(out/'process.json').write_text(json.dumps(receipt,indent=2)+'\n')
(root/'layout-source-r2.json').write_text(json.dumps({k:receipt[k] for k in ['source_commit','source_tree','source_sha256']},indent=2)+'\n')
print(json.dumps(receipt))
