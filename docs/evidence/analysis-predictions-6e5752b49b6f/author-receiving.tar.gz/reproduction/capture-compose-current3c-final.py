import pathlib,subprocess,json,hashlib,shutil
r=pathlib.Path("/tmp/capturesuite-prediction-ui-6e5752b49b6f-production"); s=r/"source-publication"
old="cc7e54a37f3103b462b5427f6fe57c5e33531e68"
base="3cbb5300bdc79c157370d1b3e599a6c82752d54a"
def git(*a): return subprocess.check_output(["git",*a],cwd=s,text=True).strip()
assert git("rev-parse","HEAD")==old
assert git("status","--porcelain")==""
p=subprocess.run(["git","-c","credential.helper=","fetch","https://github.com/Jacob-Met/CaptureSuite.git",base],cwd=s,text=True,capture_output=True)
(r/"publication-fetch-main-explicit.json").write_text(json.dumps({"base":base,"returncode":p.returncode,"stdout":p.stdout,"stderr":p.stderr},indent=2)+"\n")
assert p.returncode==0, p.stderr
assert git("rev-parse",base+"^{tree}")=="4af105896633559b35823a7aa2710dc30b2f1740"
paths=git("diff","--name-only","9c44354cb101c76beff79265de0040b6839d249f",old).splitlines()
assert len(paths)==7,paths
branch="contribution/external-predictions-ui-current-6e5752b49b6f"
subprocess.run(["git","checkout","-b",branch,base],cwd=s,check=True,capture_output=True)
for path in paths:
 if path in ("docs/design/research/PROGRESS.md","docs/design/ANALYSIS.md"): continue
 target=s/path; target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(subprocess.check_output(["git","show",old+":"+path],cwd=s))
p=s/"docs/design/ANALYSIS.md"
data=p.read_text()
note="\n\n### Native workbench: supplied prediction files\n\nIn the Analysis tab, select **Eval report**, the source **ML bundle job**, and\n**External predictions file** under **Evaluation input**. **Choose…** selects\nthe JSON file; **Run** sends that explicit choice through the existing job\nworker and evaluator. Empty or unavailable external choices block the run and\nnever select the identity simulation. **Identity teacher (simulation)** remains\nthe explicit default for fixture checks.\n\nThe control column scrolls at smaller window sizes. The workbench preserves a\nchoice after dialog cancellation and clears it when a different session is\nopened. A running job captures its request, disables the evaluation-input controls, and offers the\nexisting cancellation action. The evaluator retains the bytes it receives when\nthe job executes; selecting a file does not freeze its contents.\n\nSee [Evaluate a predictions file in Analysis](research/EXTERNAL_EVALUATION_WORKBENCH.md)\nfor the operator flow, file-choice behavior and retained report/figure paths.\n"
assert note not in data
p.write_text(data.rstrip()+"\n\n"+note.strip()+"\n")
p=s/"docs/design/research/PROGRESS.md"
data=p.read_text()
note="\n\n## 2026-10-08 — Native external-prediction evaluation (#69; HAMON 6e5752b49b6f)\n\nThe native Analysis workbench now exposes the existing #57/PR65 evaluator with\nan explicit **Evaluation input** choice. **Identity teacher (simulation)**\nretains the original default. **External predictions file** offers a native\nfile chooser, literal read-only path, Clear and actionable missing-file errors.\nIt sends the ordinary prediction_path job extra without replacing evaluator\nadmission, source binding, scoring, schema or publication. Source and raw files\nremain read-only. See [the operator guide](EXTERNAL_EVALUATION_WORKBENCH.md).\n\nChooser cancellation preserves the current choice. A new session clears the\nfile; command/mode changes preserve it within the same session. Revision checks\nretire file dialogs whose context changed while they were open. The worker\ncaptures scalar request values, while the evaluator admits and retains the\nactual input bytes when it runs. No file-byte snapshot or trained-model\nexecution is implied by a selection.\n\nNative receiving exposed two separate workbench findings. The first candidate\nclipped its new controls under vertical pressure, so the unchanged control\ncolumn now lives in a native scroll area. Keyboard controls, wrapped text and\nRun/Cancel remain reachable without forcing a taller Analysis window. An\nindependent held-worker check also proved the parent's Run/Cancel state used\nisRunning before thread.start and never resynchronized. The shared screen hunk\nnow treats a reserved worker as busy and rejects any duplicate start while it\nis reserved; the existing worker/cancellation/job lifecycle is unchanged.\n\nThe original absence capture, functional source, clipped images, inherited busy\ncounterexample and receiver-only corrections remain distinct in qualification.\nLocal Python 3.12.8 / PySide6 6.11.2 receiving uses actual Qt dialogs and QThreads,\nreal external/identity/refused jobs, retained-file and output-inventory checks,\nand keyboard reachability at 1100×700 and 1280×960. The actual MainWindow imports\nWindows named-pipe APIs before its auto_connect=False guard, so its minimum-size\ncase is a supported Windows CI gate, explicitly skipped on Mac. No Windows\nhardware, OS-native dialog, model authorship or scientific efficacy claim is\nmade from the local fixture evidence. Independent receiving and hosted results\nare recorded separately with their exact source identities.\n"
assert note not in data
p.write_text(data.rstrip()+"\n\n"+note.strip()+"\n")
subprocess.run(["git","add","--",*paths],cwd=s,check=True)
subprocess.run(["git","-c","user.name=HAMON production_slice","-c","user.email=hamon@local","commit","-m","feat(analysis): choose external predictions in native workbench"],cwd=s,check=True,capture_output=True)
out={"previous_source":old,"parent":base,"parent_tree":git("rev-parse",base+"^{tree}"),"head":git("rev-parse","HEAD"),"tree":git("rev-parse","HEAD^{tree}"),"branch":branch,"changed":git("diff","--name-status",base,"HEAD").splitlines(),"source_sha256":{p:hashlib.sha256((s/p).read_bytes()).hexdigest() for p in paths},"status":git("status","--porcelain"),"free_bytes":shutil.disk_usage(r).free}
(r/"publication-current-source.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps(out,indent=2))
