from pathlib import Path
import os,json,hashlib,subprocess,time
root=Path('/tmp/capturesuite-prediction-ui-6e5752b49b6f-production');source=root/'source'
out=root/'native-r2';out.mkdir(exist_ok=True)
paths=['desktop/capture_desktop/widgets_analysis_predictions.py','desktop/capture_desktop/widgets_analysis_jobs.py','desktop/capture_desktop/screen_analysis.py','tests/ui/test_analysis_predictions.py']
before={p:hashlib.sha256((source/p).read_bytes()).hexdigest() for p in paths}
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
python='/Users/Shared/hamon-cs22503/togishi-main-repro-venv-20261006/bin/python'
env=dict(os.environ,QT_QPA_PLATFORM='offscreen',PYTHONDONTWRITEBYTECODE='1',MPLCONFIGDIR=str(out/'matplotlib'),TMPDIR=str(out))
checks=[]
cmd=[python,'-B','-m','ruff','check',*paths]
p=subprocess.run(cmd,cwd=source,env=env,capture_output=True,text=True,timeout=30)
ruff={'command':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
(out/'ruff.json').write_text(json.dumps(ruff,indent=2)+'\n');checks.append(ruff)
if p.returncode==0:
 cmd=[python,'-B','-m','pytest','-v','-p','no:cacheprovider','-o','faulthandler_timeout=30','--basetemp',str(out/'pytest'),'--junitxml',str(out/'junit.xml'),'tests/ui/test_analysis_predictions.py','tests/ui/test_analysis_workbench.py::test_analysis_job_extras_validate','tests/ui/test_analysis_workbench.py::test_analysis_screen_no_plot_startfile']
 started=time.monotonic()
 with (out/'stdout.txt').open('w') as log:
  try:
   p=subprocess.run(cmd,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
   result={'command':cmd,'exit_code':p.returncode,'seconds':time.monotonic()-started}
  except subprocess.TimeoutExpired:
   result={'command':cmd,'timeout':180,'seconds':time.monotonic()-started}
 checks.append(result)
after={p:hashlib.sha256((source/p).read_bytes()).hexdigest() for p in paths}
assert before==after
receipt={'checks':checks,'source_unchanged':True,'source_sha256':after}
(out/'process.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
