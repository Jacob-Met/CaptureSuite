from pathlib import Path
import os,json,hashlib,subprocess,time
root=Path('/tmp/capturesuite-prediction-ui-6e5752b49b6f-production')
source=root/'source'
snapshot=root/'native-r1'/'executed-source'
paths=['desktop/capture_desktop/widgets_analysis_predictions.py','desktop/capture_desktop/widgets_analysis_jobs.py','desktop/capture_desktop/screen_analysis.py','tests/ui/test_analysis_predictions.py']
manifest={}
for p in paths:
 data=(source/p).read_bytes(); target=snapshot/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 manifest[p]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
(root/'native-r1'/'executed-source.json').write_text(json.dumps(manifest,indent=2)+'\n')
out=root/'native-debug-r1';out.mkdir(exist_ok=True)
env=dict(os.environ,QT_QPA_PLATFORM='offscreen',PYTHONDONTWRITEBYTECODE='1',MPLCONFIGDIR=str(out/'matplotlib'),TMPDIR=str(out))
command=['/Users/Shared/hamon-cs22503/togishi-main-repro-venv-20261006/bin/python','-B','-m','pytest','-vv','-s','-p','no:cacheprovider','-o','faulthandler_timeout=20','--basetemp',str(out/'pytest'),'tests/ui/test_analysis_predictions.py::test_clear_keeps_external_and_moves_keyboard_focus_to_choose','tests/ui/test_analysis_predictions.py::test_actual_external_file_runs_through_native_workbench']
started=time.monotonic()
with (out/'stdout.txt').open('w') as log:
 try:
  p=subprocess.run(command,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
  result={'exit_code':p.returncode,'seconds':time.monotonic()-started,'command':command}
 except subprocess.TimeoutExpired:
  result={'timeout':90,'seconds':time.monotonic()-started,'command':command}
(out/'process.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
