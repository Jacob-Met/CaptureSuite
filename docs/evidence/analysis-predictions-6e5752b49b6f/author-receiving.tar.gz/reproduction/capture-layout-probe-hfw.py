from pathlib import Path
import os,sys,json,tomllib
root=Path('/tmp/capturesuite-prediction-ui-6e5752b49b6f-production');source=root/'source-layout';out=root/'layout-probe';out.mkdir(exist_ok=True)
os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['MPLCONFIGDIR']=str(out/'mpl')
for key in ['LOCALAPPDATA','APPDATA','XDG_CONFIG_HOME','XDG_DATA_HOME','XDG_CACHE_HOME']:
 p=out/key;p.mkdir(exist_ok=True);os.environ[key]=str(p)
sys.path.insert(0,str(source))
for rel in tomllib.loads((source/'pyproject.toml').read_text())['tool']['pytest']['ini_options']['pythonpath']:sys.path.insert(0,str(source/rel))
from PySide6.QtWidgets import QApplication,QSizePolicy,QLayout
from PySide6.QtCore import QCoreApplication,QEvent
from capture_desktop import theme
from tests.ui.test_analysis_predictions import _screen,_external
app=QApplication([]);theme.apply_theme(app,setting='dark')
screen=_screen(app,root/'native-ui/fixture/session');screen.resize(1280,960)
control=_external(screen._extras);control._path.setText(str(root/'native-ui/fixture/ external predictions café .json'));control._refresh();app.processEvents()
widgets={'screen':screen,'extras':screen._extras,'control':control,'mode':control._mode,'row':control._file_row,'path':control._path,'choose':control._choose_button,'clear':control._clear_button,'help':control._help}
def measure():
 return {k:{'size':[w.width(),w.height()],'hint':[w.sizeHint().width(),w.sizeHint().height()],'minimumHint':[w.minimumSizeHint().width(),w.minimumSizeHint().height()],'minimum':[w.minimumWidth(),w.minimumHeight()],'policy':[str(w.sizePolicy().horizontalPolicy()),str(w.sizePolicy().verticalPolicy())],'heightForWidth':w.heightForWidth(w.width())} for k,w in widgets.items()}
data={'original':measure()}
control.setMinimumHeight(control.heightForWidth(control.width()))
for _ in range(4):app.processEvents()
screen.resize(1280,960)
for _ in range(4):app.processEvents()
data['height_for_width_minimum']=measure()
from PySide6.QtCore import QPoint
data['position']={name:[widget.mapTo(screen,QPoint()).x(),widget.mapTo(screen,QPoint()).y(),widget.width(),widget.height()] for name,widget in {'control':control,'extras':screen._extras,'run':screen._btn_run}.items()}
assert screen.grab().save(str(out/'minimum-height-probe.png'),'PNG')
(out/'minimum-height.json').write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data))
screen.close();screen.deleteLater();QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete);app.processEvents()
