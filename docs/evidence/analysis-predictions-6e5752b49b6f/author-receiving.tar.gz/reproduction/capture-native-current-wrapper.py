from pathlib import Path
import os,json,hashlib,subprocess,time
root=Path('/tmp/capturesuite-prediction-ui-6e5752b49b6f-production');source=root/'source'
out=root/'native-current';out.mkdir(exist_ok=True)
def git(*args):
 return subprocess.check_output(['git',*args],cwd=source).decode().strip()
assert git('rev-parse','HEAD')=='424298e30d6e0f08fe4124fa282328575c40d203'
def leaves(ref):
 raw=subprocess.check_output(['git','ls-tree','-rz',ref],cwd=source)
 result={}
 for entry in raw.split(b'\0'):
  if not entry:continue
  meta,path=entry.split(b'\t',1);mode,kind,sha=meta.decode().split()
  if kind=='blob':result[path.decode()]={'mode':mode,'sha':sha}
 return result
parent=leaves('HEAD^');candidate=leaves('HEAD')
api={r['path']:{'mode':r['mode'],'sha':r['sha']} for r in json.loads((root/'current-parent-tree.json').read_text())['tree'] if r['type']=='blob'}
assert api==parent
changed={p for p in parent if candidate.get(p)!=parent[p]}
added=set(candidate)-set(parent)
assert changed=={'desktop/capture_desktop/widgets_analysis_jobs.py','desktop/capture_desktop/screen_analysis.py'}
assert added=={'desktop/capture_desktop/widgets_analysis_predictions.py','tests/ui/test_analysis_predictions.py'}
before={p:hashlib.sha256((source/p).read_bytes()).hexdigest() for p in sorted(changed|added)}
(out/'source-admission.json').write_text(json.dumps({'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'parent':git('rev-parse','HEAD^'),'parent_leaves':len(parent),'preserved_leaves':len(parent)-len(changed),'candidate_leaves':len(candidate),'modified':sorted(changed),'added':sorted(added),'api_git_match':True,'owned_sha256':before,'parent_inventory':parent},indent=2)+'\n')
env=dict(os.environ,QT_QPA_PLATFORM='offscreen',PYTHONDONTWRITEBYTECODE='1',MPLCONFIGDIR=str(out/'matplotlib'),TMPDIR=str(out))
python='/Users/Shared/hamon-cs22503/togishi-main-repro-venv-20261006/bin/python'
cmd=[python,'-B','-m','pytest','-v','-p','no:cacheprovider','--basetemp',str(out/'pytest'),'--junitxml',str(out/'junit.xml'),'tests/ui/test_analysis_predictions.py::test_actual_external_file_runs_through_native_workbench','tests/ui/test_analysis_predictions.py::test_invalid_external_file_refuses_without_identity_then_retries','tests/ui/test_analysis_predictions.py::test_explicit_identity_after_external_choice_uses_original_job']
started=time.monotonic()
with (out/'stdout.txt').open('w') as log:
 try:
  p=subprocess.run(cmd,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
  receipt={'command':cmd,'exit_code':p.returncode,'seconds':time.monotonic()-started}
 except subprocess.TimeoutExpired:
  receipt={'command':cmd,'timeout':120,'seconds':time.monotonic()-started}
after={p:hashlib.sha256((source/p).read_bytes()).hexdigest() for p in before};assert after==before
receipt['source_unchanged']=True
inventory=[]
if receipt.get('exit_code')==0:
 for man in sorted((out/'pytest').rglob('job_manifest.json')):
  doc=json.loads(man.read_text())
  rows=doc['outputs'];actual={p.relative_to(man.parent).as_posix() for p in man.parent.rglob('*') if p.is_file() and p!=man}
  assert {r['relativePath'] for r in rows}==actual and len(rows)==len(actual)
  for row in rows:
   data=(man.parent/row['relativePath']).read_bytes()
   assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
  inventory.append({'path':str(man.relative_to(out)),'status':doc['status'],'outputs':len(rows)})
 receipt['all_actual_final_inventories']=inventory
(out/'process.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
