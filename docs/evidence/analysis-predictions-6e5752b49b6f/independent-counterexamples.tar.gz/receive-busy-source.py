from pathlib import Path
import hashlib,json,subprocess
base=Path("/tmp/capturesuite-eval-receiving-6e5752b49b6f-github")
source=Path("/tmp/capturesuite-prediction-ui-6e5752b49b6f-production/source")
relative="desktop/capture_desktop/screen_analysis.py"
candidate=(source/relative).read_bytes()
parent=subprocess.check_output(["git","show","d7459fa62dd7a57d5565214e10638e055ad5877c:"+relative],cwd=source)
addition=b"        self._extras.set_eval_busy(self._thread is not None)\n"
assert candidate.count(addition)==1
assert candidate.replace(addition,b"",1)==parent
assert hashlib.sha256(candidate).hexdigest()=="b31413db7f0874b4404a5c6dcb047072c439f63def3d2caec75ed2432b31b79f"
raw=(base/"viewport-r1/receiving.json").read_bytes()
report=json.loads(raw)
held=report["held_worker"]
assert report["source_commit"]=="424298e30d6e0f08fe4124fa282328575c40d203" and report["source_unchanged"]
assert held["reserved"] and held["running"] and held["run"]["enabled"] and not held["cancel"]["enabled"]
assert not held["evaluation_input_enabled"] and not held["actual_worker_cancel_flag_before_action"]
assert len(report["jobs"])==1 and not report["jobs"][0]["on_main_thread"]
assert report["jobs"][0]["error"]=="analysis cancelled"
assert held["actual_run_consumed_cancel_before_creating_job_outputs"]
sha=lambda data:hashlib.sha256(data).hexdigest()
blob=lambda data:hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
result={
 "accepted_observation":"Actual worker reserved and running; Run enabled, Cancel disabled, new EvaluationInput disabled.",
 "candidate_commit":report["source_commit"],"candidate_tree":report["source_tree"],
 "candidate_screen_sha256":sha(candidate),"candidate_screen_git_blob":blob(candidate),
 "base_commit":"d7459fa62dd7a57d5565214e10638e055ad5877c","base_screen_sha256":sha(parent),"base_screen_git_blob":blob(parent),
 "inverse_delta_reproduces_entire_base_screen":True,
 "only_screen_addition":addition.decode(),"inherited_action_state_issue":True,
 "raw_receipt_sha256":sha(raw),"receiver_sha256":report["receiver_sha256"],
 "actual_job":report["jobs"][0],
 "geometry_coordinates_excluded":"This attempt used an invalid ancestor-to-descendant QWidget.mapTo call. Its geometry is excluded; directly observed enabled flags, actual thread state, real worker call and cancellation are independent of that coordinate helper.",
 "cleanup":"Worker.request_cancel was invoked solely for receiver cleanup because native Cancel was disabled; the actual unchanged run consumed it before creating outputs.",
 "source_unchanged":True,
}
path=base/"busy-counterexample-source.json"
path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")
print(json.dumps({"path":str(path),"sha256":sha(path.read_bytes()),"source_ancestry_pass":True,"real_busy_defect":True}))
