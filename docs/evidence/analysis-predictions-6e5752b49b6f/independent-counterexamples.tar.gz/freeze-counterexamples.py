from pathlib import Path
import hashlib,json,os,subprocess,tarfile
base=Path(__file__).resolve().parent
source=Path("/tmp/capturesuite-prediction-ui-6e5752b49b6f-production/source")
packet=base/"counterexample-packet"
packet.mkdir(exist_ok=False)
sha=lambda data:hashlib.sha256(data).hexdigest()
def doc(path):return json.loads(path.read_text())
def write(path,value):
 path.parent.mkdir(parents=True,exist_ok=True)
 path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n")
def put(original,relative):
 target=packet/relative;target.parent.mkdir(parents=True,exist_ok=True)
 data=original.read_bytes();target.write_bytes(data);assert target.read_bytes()==data
def git(*args):
 return subprocess.check_output(["git",*args],cwd=source,env=dict(os.environ,GIT_OPTIONAL_LOCKS="0"))
assert git("rev-parse","HEAD").decode().strip()=="424298e30d6e0f08fe4124fa282328575c40d203"
assert not git("status","--porcelain").strip()
for run in ("viewport-r1","viewport-baseline-r2"):
 report=doc(base/run/"receiving.json")
 assert report["source_unchanged"] and not report["passed"]
 assert sha((base/run/"receive-analysis-viewport.py").read_bytes())==report["receiver_sha256"]
 put(base/run/"receiving.json",run+"/receiving.json")
 put(base/run/"receive-analysis-viewport.py",run+"/receive-analysis-viewport.py")
 if run=="viewport-r1":
  assert len(report["jobs"])==1
  images=["analysis-viewport-1100x700-held-worker.png"]
 else:
  assert not report["jobs"] and report["receiver_sha256"]=="add4a8df6d01e870b2e35653d2551bfb1b57069d20f6d894875c65faa9f8fad6"
  images=report["screenshots"]
 for image in images:put(base/run/image,run+"/"+image)
for name in ("busy-counterexample-source.json","receive-busy-source.py","native-counter-execution.json"):
 put(base/name,name)
assert sha((base/"busy-counterexample-source.json").read_bytes())=="ab9b56c9f25b39b717f3c97ef1929a596a08179112fcfb21fcfea5c36f2f7880"
put(base/"README-counterexamples.md","README.md")
put(Path(__file__),"freeze-counterexamples.py")
raw=git("cat-file","commit","HEAD")
assert hashlib.sha1(b"commit "+str(len(raw)).encode()+b"\0"+raw).hexdigest()=="424298e30d6e0f08fe4124fa282328575c40d203"
(packet/"original-candidate-commit.txt").write_bytes(raw)
source_paths=(
 "desktop/capture_desktop/widgets_analysis_predictions.py",
 "desktop/capture_desktop/widgets_analysis_jobs.py",
 "desktop/capture_desktop/screen_analysis.py",
 "tests/ui/test_analysis_predictions.py",
 "desktop/capture_desktop/app.py",
 "libs/python/capture_protocol/capture_protocol/control_client.py",
)
source_manifest={}
for path in source_paths:
 data=(source/path).read_bytes()
 blob=hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
 assert blob==git("rev-parse","HEAD:"+path).decode().strip()
 put(source/path,"source/"+path)
 source_manifest[path]={"bytes":len(data),"sha256":sha(data),"git_blob":blob}
write(packet/"source-manifest.json",{"commit":"424298e30d6e0f08fe4124fa282328575c40d203","files":source_manifest})
members=[]
for path in sorted(packet.rglob("*")):
 if path.is_file():
  data=path.read_bytes();members.append({"path":path.relative_to(packet).as_posix(),"bytes":len(data),"sha256":sha(data)})
write(packet/"MANIFEST.json",{"files":members})
archive=base/"capturesuite69-original-counterexamples.tar.gz"
with tarfile.open(archive,"w:gz") as stream:
 for path in sorted(packet.rglob("*")):
  if path.is_file():stream.add(path,arcname=path.relative_to(packet).as_posix(),recursive=False)
expected={row["path"]:row for row in members}
data=(packet/"MANIFEST.json").read_bytes()
expected["MANIFEST.json"]={"bytes":len(data),"sha256":sha(data)}
with tarfile.open(archive,"r:gz") as stream:
 assert set(stream.getnames())==set(expected)
 for entry in stream.getmembers():
  assert entry.isfile()
  data=stream.extractfile(entry).read()
  assert len(data)==expected[entry.name]["bytes"] and sha(data)==expected[entry.name]["sha256"]
assert not git("status","--porcelain").strip()
data=archive.read_bytes()
summary={"archive":str(archive),"bytes":len(data),"sha256":sha(data),"members":len(expected),
 "manifest_sha256":sha((packet/"MANIFEST.json").read_bytes()),"source_unchanged":True}
write(base/"counterexample-packet.json",summary)
print(json.dumps(summary),flush=True)
