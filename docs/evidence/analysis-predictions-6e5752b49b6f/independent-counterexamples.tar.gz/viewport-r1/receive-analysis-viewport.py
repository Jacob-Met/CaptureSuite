# SPDX-License-Identifier: GPL-3.0-only
"""Independent actual-Qt receiving of native evaluation input and real jobs.

Only a pass-through run observer and one explicitly gated scheduling control are
installed in this private process. No scorer, worker, dialog or result is stubbed.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time
import tomllib
import traceback

parser = argparse.ArgumentParser()
parser.add_argument("--source", required=True)
parser.add_argument("--output", required=True)
parser.add_argument("--expected-commit", required=True)
parser.add_argument("--expected-tree", required=True)
args = parser.parse_args()
SOURCE = Path(args.source).resolve()
OUT = Path(args.output).resolve()
OUT.mkdir(parents=True, exist_ok=False)
sys.dont_write_bytecode = True
for name, suffix in {
    "LOCALAPPDATA": "local", "APPDATA": "roaming", "XDG_CONFIG_HOME": "config",
    "XDG_DATA_HOME": "data", "XDG_CACHE_HOME": "cache", "MPLCONFIGDIR": "matplotlib",
    "TMPDIR": "temporary", "CAPTURE_TEST_STATE": "application-state",
}.items():
    folder = OUT / suffix
    folder.mkdir()
    os.environ[name] = str(folder)
os.environ["QT_QPA_PLATFORM"] = "offscreen"
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
os.chdir(OUT)
configuration = tomllib.loads((SOURCE / "pyproject.toml").read_text())
for path in reversed(configuration["tool"]["pytest"]["ini_options"]["pythonpath"]):
    sys.path.insert(0, str(SOURCE / path))

sha = lambda data: hashlib.sha256(data).hexdigest()
def git(*arguments):
    environment = dict(os.environ, GIT_OPTIONAL_LOCKS="0")
    return subprocess.check_output(["git", *arguments], cwd=SOURCE, env=environment, text=True).strip()

assert git("rev-parse", "HEAD") == args.expected_commit
assert git("rev-parse", "HEAD^{tree}") == args.expected_tree
assert not git("status", "--porcelain")
EXPECTED = {}
for relative in (
    "desktop/capture_desktop/widgets_analysis_predictions.py",
    "desktop/capture_desktop/widgets_analysis_jobs.py",
    "desktop/capture_desktop/screen_analysis.py",
    "tests/ui/test_analysis_predictions.py",
):
    data = (SOURCE / relative).read_bytes()
    blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
    assert blob == git("rev-parse", "HEAD:" + relative), relative
    EXPECTED[relative] = sha(data)
tree = {}
for line in git("ls-tree", "-r", "HEAD").splitlines():
    metadata, path = line.split("\t", 1)
    mode, kind, digest = metadata.split()
    if kind == "blob":
        tree[path] = {"mode": mode, "git_blob": digest}

import PySide6
from PySide6.QtCore import QCoreApplication, QEvent, QEventLoop, QThread, QTimer, Qt, qVersion
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QAbstractItemView, QApplication, QComboBox, QDialogButtonBox, QFileDialog, QLineEdit, QMessageBox, QPushButton, QWidget
import pandas as pd
import capture_analysis
from capture_desktop import theme
from capture_desktop.screen_analysis import AnalysisScreen, _AnalysisWorker
from capture_desktop.state import CaptureState
from capture_desktop.widgets_analysis_jobs import AnalysisJobExtras

QCoreApplication.setAttribute(Qt.ApplicationAttribute.AA_DontUseNativeDialogs, True)
app = QApplication([])
app.setApplicationName("CaptureSuite independent evaluation receiving 6e5752b49b6f")
app.setOrganizationName("Independent receiving")
theme.apply_theme(app, setting="dark")
MAIN_THREAD = threading.get_ident()
REPORT = {
    "source_commit": git("rev-parse", "HEAD"), "source_tree": git("rev-parse", "HEAD^{tree}"),
    "parent": git("rev-parse", "HEAD^"), "owned_source_sha256": EXPECTED,
    "receiver_sha256": sha(Path(__file__).read_bytes()), "python": sys.version,
    "pyside": PySide6.__version__, "qt": qVersion(), "qt_platform": app.platformName(),
    "dialog_scope": "Actual Qt QFileDialog with AA_DontUseNativeDialogs. The offscreen receiver explicitly activates Qt windows before keyboard actions; no Cocoa, Windows OS-dialog, or window-manager focus claim.",
    "cases": [], "dialogs": [], "messages": [], "jobs": [], "screenshots": [],
}
case_name = "initialization"
callback_errors = []
actual_run = capture_analysis.run
GATE = {"active": False, "entered": threading.Event(), "release": threading.Event()}
protected = {}
all_threads = []

def write_json(path, document):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(document, ensure_ascii=False, indent=2) + "\n", encoding="utf8")

def protect(path):
    protected[str(path)] = sha(path.read_bytes())

def fixture(name):
    package = OUT / (name + ".mmsession")
    package.mkdir()
    write_json(package / "manifest.json", {
        "session_schema_version": "1.0.0", "sessionId": "independent-ui-" + name,
        "state": "finalized", "t0WallUtc": "2026-10-08T00:00:00Z",
        "finalizedUtc": "2026-10-08T00:00:10Z", "sourceIds": [],
    })
    write_json(package / "integrity.json", {"schemaVersion": "1", "files": []})
    for event in ("checkpoints", "annotations", "sync_anchors"):
        write_json(package / "events" / (event + ".json"), [])
    for path in package.rglob("*"):
        if path.is_file():
            protect(path)
    identifiers = ["native-c", "native-a", "native-d", "native-b"]
    times = [10**18 + 37 + i * 250_000_001 for i in range(4)]
    teacher = [-6.0, 1.5, 8.0, 21.0]
    column = "theta_elbow_flex_L"
    paths = {}
    for bundle_id, shift in (("bundle", 0.0), ("alternate", 100.0)):
        folder = package / "processing" / "jobs" / bundle_id / "ml_bundle"
        folder.mkdir(parents=True)
        windows = folder / "windows.parquet"
        pd.DataFrame({
            "window_id": identifiers,
            "session_time_ns": pd.Series(times, dtype="int64"),
            "valid_mask": pd.Series([True] * 4, dtype="bool"),
            column: [value + shift for value in teacher],
        }).to_parquet(windows, index=False)
        manifest = folder / "manifest.json"
        write_json(manifest, {
            "schemaId": "capture.ml_bundle/1",
            "sessionIds": ["independent-ui-" + name],
            "targetColumns": [column],
            "sha256": {"windows.parquet": sha(windows.read_bytes())},
            "provisional": True,
        })
        paths[bundle_id] = (windows, manifest)
        protect(windows); protect(manifest)
    windows, manifest = paths["bundle"]
    def predictions(label, offset):
        return {
            "schemaId": "capture.eval_predictions/1", "modelId": label,
            "windowsSha256": sha(windows.read_bytes()),
            "manifestSha256": sha(manifest.read_bytes()),
            "predictions": [
                {"window_id": identifiers[i], "session_time_ns": times[i],
                 "values": {column: teacher[i] + offset}}
                for i in (3, 1, 0, 2)
            ],
        }
    inputs = OUT / "inputs" / name
    inputs.mkdir(parents=True)
    # The trailing space is intentional and is a native POSIX filename control.
    chosen_a = inputs / " predictions café A.json "
    chosen_b = inputs / "predictions chosen B.json"
    invalid = inputs / "source mismatch.json"
    write_json(chosen_a, predictions("Receiver chosen A / café", 2.25))
    write_json(chosen_b, predictions("Receiver chosen B", 5.75))
    bad = predictions("Receiver wrong source", 2.25)
    bad["manifestSha256"] = "0" * 64
    write_json(invalid, bad)
    return {
        "package": package, "column": column, "ids": identifiers, "times": times,
        "teacher": teacher, "a": chosen_a, "b": chosen_b, "invalid": invalid,
        "windows": windows, "manifest": manifest, "predictions": predictions,
    }

def wait_until(predicate, timeout=35):
    if predicate():
        return
    loop = QEventLoop()
    timer = QTimer()
    deadline = time.monotonic() + timeout
    def check():
        if predicate() or callback_errors or time.monotonic() > deadline:
            loop.quit()
    timer.timeout.connect(check)
    timer.start(20)
    loop.exec()
    timer.stop()
    assert not callback_errors, callback_errors
    assert predicate(), "Timed out in native event loop: " + case_name

def press(widget):
    assert widget.isEnabled(), widget.objectName() or widget.text()
    # QTest delivers keys even to an inactive offscreen window. Establish the
    # native focus precondition explicitly after nested file dialogs close.
    app.setActiveWindow(widget.window())
    wait_until(lambda: app.activeWindow() is widget.window(), timeout=3)
    widget.setFocus()
    assert app.focusWidget() is widget, widget.objectName() or widget.text()
    QTest.keyClick(widget, Qt.Key.Key_Space)

def mode_control(parent):
    result = parent.findChild(QComboBox, "EvalInputMode")
    assert result is not None
    return result

def mode(parent, target):
    combo = mode_control(parent)
    index = combo.findData(target)
    assert index >= 0
    app.setActiveWindow(combo.window())
    wait_until(lambda: app.activeWindow() is combo.window(), timeout=3)
    combo.setFocus()
    for _ in range(combo.count() + 1):
        if combo.currentIndex() == index:
            break
        QTest.keyClick(combo, Qt.Key.Key_Down if combo.currentIndex() < index else Qt.Key.Key_Up)
    assert combo.currentData() == target

def path_control(parent):
    result = parent.findChild(QLineEdit, "EvalPredictionPath")
    assert result is not None and result.isReadOnly()
    return result

def choose(parent, requested=None, *, cancel=False, during=None):
    choose_button = parent.findChild(QPushButton, "EvalPredictionChoose")
    assert choose_button is not None and choose_button.isEnabled()
    observations = []
    timer = QTimer()
    deadline = time.monotonic() + 8
    stage = {"dialog": None, "prepared": False, "selected": False, "ticks": 0}
    def steer():
        try:
            if time.monotonic() > deadline:
                raise AssertionError("Actual Qt file dialog selection timed out")
            dialog = next((w for w in app.topLevelWidgets() if isinstance(w, QFileDialog) and w.isVisible()), None)
            if dialog is None:
                if time.monotonic() > deadline:
                    raise AssertionError("Actual Qt file dialog did not open")
                return
            if not stage["prepared"]:
                stage["dialog"] = dialog
                stage["prepared"] = True
                if requested is not None:
                    dialog.selectNameFilter("All files (*)")
                    dialog.setDirectory(str(requested.parent))
                return
            if not stage["selected"]:
                if requested is not None:
                    matched = False
                    for view in dialog.findChildren(QAbstractItemView):
                        if not view.isVisible() or view.objectName() not in ("listView", "treeView"):
                            continue
                        model = view.model()
                        for row in range(model.rowCount(view.rootIndex())):
                            index = model.index(row, 0, view.rootIndex())
                            if index.data() != requested.name:
                                continue
                            view.scrollTo(index)
                            rectangle = view.visualRect(index)
                            if not rectangle.isValid():
                                continue
                            QTest.mouseClick(view.viewport(), Qt.MouseButton.LeftButton, pos=rectangle.center())
                            stage["selection_view"] = view.objectName()
                            matched = True
                            break
                        if matched:
                            break
                    if not matched:
                        return
                stage["selected"] = True
                if during:
                    during()
                return
            stage["ticks"] += 1
            if stage["ticks"] < 3:
                return
            selected = dialog.selectedFiles()
            observations.append({
                "case": case_name, "requested": str(requested) if requested else None,
                "native_selected_files_before_close": selected,
                "cancel": cancel, "visible": dialog.isVisible(),
                "caption": dialog.windowTitle(), "dialog_class": dialog.metaObject().className(),
                "actual_file_view_clicked": stage.get("selection_view"),
            })
            timer.stop()
            if cancel:
                QTest.keyClick(dialog, Qt.Key.Key_Escape)
            else:
                assert len(selected) == 1 and Path(selected[0]).samefile(requested), selected
                assert Path(selected[0]).name == requested.name, (selected, requested.name)
                box = dialog.findChild(QDialogButtonBox)
                button = next(b for b in box.buttons() if box.buttonRole(b) == QDialogButtonBox.ButtonRole.AcceptRole)
                assert button.isEnabled()
                QTest.mouseClick(button, Qt.MouseButton.LeftButton)
        except BaseException:
            callback_errors.append(traceback.format_exc())
            timer.stop()
            if stage["dialog"] is not None:
                stage["dialog"].reject()
    timer.timeout.connect(steer)
    timer.start(40)
    press(choose_button)
    timer.stop()
    assert not callback_errors, callback_errors
    assert len(observations) == 1, observations
    REPORT["dialogs"].extend(observations)
    return observations[0]["native_selected_files_before_close"][0] if not cancel else None

def dismiss_messages():
    try:
        for box in app.topLevelWidgets():
            if isinstance(box, QMessageBox) and box.isVisible():
                REPORT["messages"].append({"case": case_name, "title": box.windowTitle(), "text": box.text()})
                box.accept()
    except BaseException:
        callback_errors.append(traceback.format_exc())

message_timer = QTimer()
message_timer.timeout.connect(dismiss_messages)
message_timer.start(25)

def observed_run(package, params=None, **kwargs):
    row = {
        "case": case_name, "package": str(package), "params_at_entry": copy.deepcopy(params.to_dict()),
        "thread_id": threading.get_ident(), "on_main_thread": threading.get_ident() == MAIN_THREAD,
    }
    REPORT["jobs"].append(row)
    GATE["cancel_event"] = kwargs.get("cancel")
    if GATE["active"]:
        GATE["entered"].set()
        if not GATE["release"].wait(15):
            raise AssertionError("Receiver-controlled scheduling gate was not released")
    try:
        result = actual_run(package, params, **kwargs)
        row.update({"job_dir": str(result.job_dir), "status": result.status})
        return result
    except BaseException as error:
        row.update({"error": str(error), "notes": list(getattr(error, "__notes__", ()))})
        raise

capture_analysis.run = observed_run


# The fixture/Qt helpers above are retained from the accepted R4 receiver.
# This geometry oracle and full-shell control-state challenge are independent
# of the author's layout implementation and unit tests.
from PySide6.QtCore import QPoint, QRect
from PySide6.QtWidgets import QLabel

REPORT["receiving_scope"] = "Actual standalone AnalysisScreen at requested viewport sizes, ancestor clipping, keyboard reachability, and one real held worker. The Windows-only MainWindow is not imported or substituted on this Mac."
REPORT["geometry_cases"] = []
REPORT["fixture_preparation"] = "A known path is seeded for geometry comparison on the unusable original UI. A geometrically accepted candidate must then Clear and choose through the actual dialog before the job action."
main = None
screen = None
def settle(milliseconds=50):
    loop = QEventLoop()
    QTimer.singleShot(milliseconds, loop.quit)
    loop.exec()
    assert not callback_errors, callback_errors
def rect_list(rectangle):
    return [rectangle.x(), rectangle.y(), rectangle.width(), rectangle.height()]
def geometry(widget):
    own = QRect(widget.rect())
    effective = QRect(own)
    chain = []
    ancestor = widget.parentWidget()
    while ancestor is not None:
        bounds = QRect(ancestor.mapTo(widget, QPoint(0, 0)), ancestor.size())
        effective = effective.intersected(bounds)
        chain.append({"class": ancestor.metaObject().className(), "name": ancestor.objectName(), "bounds_in_control": rect_list(bounds)})
        ancestor = ancestor.parentWidget()
    hint_height = widget.minimumSizeHint().height()
    return {
        "class": widget.metaObject().className(), "name": widget.objectName(),
        "rect": rect_list(own), "effective": rect_list(effective),
        "in_main": rect_list(QRect(widget.mapTo(main, QPoint(0, 0)), widget.size())),
        "enabled": widget.isEnabled(), "visible": widget.isVisibleTo(main),
        "minimum_hint_height": hint_height,
        "fully_visible": widget.isVisibleTo(main) and effective == own and widget.height() >= max(0, hint_height),
        "ancestors": chain,
    }
def is_focus(target):
    focused = app.focusWidget()
    return focused is target or (focused is not None and target.isAncestorOf(focused))
def keyboard_to(target, maximum=180):
    app.setActiveWindow(main)
    for _ in range(maximum):
        if is_focus(target):
            app.processEvents()
            return True
        QTest.keyClick(app.focusWidget() or main, Qt.Key.Key_Tab)
        app.processEvents()
    return False

try:
    f = fixture("viewport")
    main = AnalysisScreen(CaptureState())
    screen = main
    assert "capture_protocol.control_client" not in sys.modules
    screen.set_package(str(f["package"]))
    screen._command.setCurrentIndex(screen._command.findData("eval"))
    screen._extras._bundle_job.setEditText("bundle")
    mode_control(screen).setCurrentIndex(mode_control(screen).findData("external"))
    path_control(screen).setText(str(f["a"]))
    screen.findChild(QWidget, "EvaluationInput")._refresh()
    main.show()
    app.setActiveWindow(main)
    settle()
    controls = {
        "mode": mode_control(screen), "path": path_control(screen),
        "choose": screen.findChild(QPushButton, "EvalPredictionChoose"),
        "clear": screen.findChild(QPushButton, "EvalPredictionClear"),
        "run": screen._btn_run,
    }
    for width, height in ((1280, 960), (1100, 700)):
        case_name = f"Analysis viewport {width}x{height}"
        main.resize(width, height)
        settle()
        row = {"requested": [width, height], "actual": [main.width(), main.height()],
               "analysis_size": [screen.width(), screen.height()], "controls_on_keyboard_focus": {}, "screenshots": []}
        app.setActiveWindow(main)
        screen._command.setFocus()
        for _ in range(180):
            for name, control in controls.items():
                if name not in row["controls_on_keyboard_focus"] and is_focus(control):
                    app.processEvents()
                    row["controls_on_keyboard_focus"][name] = geometry(control)
                    if name in ("mode", "run"):
                        filename = f"analysis-viewport-{width}x{height}-{name}.png"
                        assert main.grab().save(str(OUT / filename))
                        row["screenshots"].append(filename)
                        REPORT["screenshots"].append(filename)
                    if name == "run":
                        row["cancel_beside_run"] = geometry(screen._btn_cancel)
            if len(row["controls_on_keyboard_focus"]) == len(controls):
                break
            QTest.keyClick(app.focusWidget() or main, Qt.Key.Key_Tab)
            app.processEvents()
        group = screen.findChild(QWidget, "EvaluationInput")
        row["group_height"] = group.height()
        row["help_labels"] = [
            {"text": label.text(), "actual_height": label.height(),
             "required_height_for_width": label.heightForWidth(label.width())}
            for label in group.findChildren(QLabel)
        ]
        row["passed"] = (
            row["actual"] == row["requested"]
            and set(row["controls_on_keyboard_focus"]) == set(controls)
            and all(x["fully_visible"] for x in row["controls_on_keyboard_focus"].values())
            and row.get("cancel_beside_run", {}).get("fully_visible") is True
            and all(x["actual_height"] >= max(0, x["required_height_for_width"]) for x in row["help_labels"])
        )
        REPORT["geometry_cases"].append(row)
    geometry_ok = all(x["passed"] for x in REPORT["geometry_cases"])
    REPORT["cases"].append({"name": "Keyboard reachable controls and actual ancestor clipping at both supported sizes", "passed": geometry_ok})
    assert "capture_protocol.control_client" not in sys.modules

    case_name = "Analysis viewport actual Choose, Run and Cancel"
    if geometry_ok:
        assert keyboard_to(controls["clear"]) and geometry(controls["clear"])["fully_visible"]
        press(controls["clear"])
        assert path_control(screen).text() == "" and is_focus(controls["choose"])
        assert geometry(controls["choose"])["fully_visible"]
        selected = choose(screen, f["a"])
        assert path_control(screen).text() == selected and screen._extras.validate_for("eval") is None
        assert keyboard_to(controls["run"]) and geometry(controls["run"])["fully_visible"]
    else:
        REPORT["job_dispatch_scope"] = "Direct invocation of the existing _start_job slot only to isolate inherited busy-state behavior; no claim that the clipped original UI Run control was reachable."
    before_jobs = sorted(x.name for x in (f["package"] / "processing/jobs").iterdir())
    GATE["active"] = True
    GATE["entered"].clear()
    GATE["release"].clear()
    if geometry_ok:
        press(controls["run"])
    else:
        screen._start_job()
    wait_until(GATE["entered"].is_set, timeout=8)
    assert screen._thread is not None and screen._thread.isRunning()
    assert GATE["cancel_event"] is not None
    REPORT["held_worker"] = {
        "reserved": True, "running": True,
        "run": geometry(screen._btn_run), "cancel": geometry(screen._btn_cancel),
        "evaluation_input_enabled": screen.findChild(QWidget, "EvaluationInput").isEnabled(),
        "actual_worker_cancel_flag_before_action": GATE["cancel_event"].is_set(),
    }
    filename = "analysis-viewport-1100x700-held-worker.png"
    assert main.grab().save(str(OUT / filename))
    REPORT["screenshots"].append(filename)
    cancel_enabled = screen._btn_cancel.isEnabled()
    if cancel_enabled and geometry_ok:
        assert keyboard_to(screen._btn_cancel) and geometry(screen._btn_cancel)["fully_visible"]
        press(screen._btn_cancel)
        REPORT["held_worker"]["cancel_action"] = "Actual keyboard Space on reachable enabled Cancel"
    else:
        # Cleanup only; never mislabel this controller call as a user action.
        screen._worker.request_cancel()
        REPORT["held_worker"]["cancel_action"] = "Receiver cleanup request_cancel; native Cancel was not accepted as usable"
    assert GATE["cancel_event"].is_set()
    GATE["release"].set()
    wait_until(lambda: screen._thread is None)
    GATE["active"] = False
    assert len(REPORT["jobs"]) == 1 and REPORT["jobs"][0]["error"] == "analysis cancelled"
    assert sorted(x.name for x in (f["package"] / "processing/jobs").iterdir()) == before_jobs
    REPORT["held_worker"]["actual_worker_cancel_flag_after_action"] = True
    REPORT["held_worker"]["actual_run_consumed_cancel_before_creating_job_outputs"] = True
    REPORT["held_worker"]["after_completion_run_enabled"] = screen._btn_run.isEnabled()
    REPORT["held_worker"]["after_completion_cancel_enabled"] = screen._btn_cancel.isEnabled()
    busy_ok = cancel_enabled and not REPORT["held_worker"]["run"]["enabled"] and not REPORT["held_worker"]["evaluation_input_enabled"]
    REPORT["cases"].append({"name": "Actual held-worker Run/Cancel busy state", "passed": busy_ok})
    for path, digest in protected.items():
        assert sha(Path(path).read_bytes()) == digest, path
    assert "capture_protocol.control_client" not in sys.modules
    REPORT["daemon_not_started"] = True
    REPORT["protected_package_and_bundle_files"] = [{"path": path, "sha256": digest} for path, digest in protected.items()]
    REPORT["passed"] = geometry_ok and busy_ok
except BaseException:
    REPORT["passed"] = False
    REPORT["failure"] = traceback.format_exc()
    print(REPORT["failure"], flush=True)
finally:
    GATE["release"].set()
    if screen is not None and screen._thread is not None:
        screen._cancel_job()
        try:
            wait_until(lambda: screen._thread is None, timeout=20)
        except BaseException:
            REPORT["cleanup_failure"] = traceback.format_exc()
    capture_analysis.run = actual_run
    message_timer.stop()
    if main is not None:
        main.close()
    for widget in app.topLevelWidgets():
        widget.close()
        widget.deleteLater()
    QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
    app.processEvents()
    imported = {}
    for module in list(sys.modules.values()):
        filename = getattr(module, "__file__", None)
        if not filename:
            continue
        path = Path(filename).resolve()
        if not path.is_relative_to(SOURCE) or not path.is_file():
            continue
        relative = path.relative_to(SOURCE).as_posix()
        data = path.read_bytes()
        blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        assert relative in tree and blob == tree[relative]["git_blob"], relative
        imported[relative] = {"sha256": sha(data), "bytes": len(data), "git_blob": blob}
    assert not git("status", "--porcelain")
    REPORT["imported_project_source"] = imported
    REPORT["source_unchanged"] = True
    REPORT["callback_errors"] = callback_errors
    write_json(OUT / "receiving.json", REPORT)
print(json.dumps({"passed": REPORT["passed"], "geometry": [x["passed"] for x in REPORT["geometry_cases"]],
                  "held_worker": REPORT.get("held_worker"), "output": str(OUT)}), flush=True)
raise SystemExit(0 if REPORT["passed"] else 1)
