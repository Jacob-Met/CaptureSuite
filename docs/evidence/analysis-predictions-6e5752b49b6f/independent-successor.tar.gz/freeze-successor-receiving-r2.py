# SPDX-License-Identifier: GPL-3.0-only
from pathlib import Path
import hashlib, json, os, subprocess, tarfile

base = Path(__file__).resolve().parent
source = Path("/tmp/capturesuite-prediction-ui-6e5752b49b6f-production/source-layout")
packet = base / "successor-packet-r2"
packet.mkdir(exist_ok=False)
sha = lambda data: hashlib.sha256(data).hexdigest()
def doc(path):
    return json.loads(path.read_text())
def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
def put(original, relative):
    target = packet / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    data = original.read_bytes()
    target.write_bytes(data)
    assert target.read_bytes() == data
def git(*args):
    return subprocess.check_output(["git", *args], cwd=source,
                                   env=dict(os.environ, GIT_OPTIONAL_LOCKS="0"))
def git_text(*args):
    return git(*args).decode().strip()

head = "983641cc270db34be0711d554cd2c82608cb0b8c"
tree = "4cceca0d9ce05a354584c7a2e3092e5e59e6c7c9"
assert git_text("rev-parse", "HEAD") == head
assert git_text("rev-parse", "HEAD^{tree}") == tree
assert not git("status", "--porcelain").strip()
own_paths = (
    "desktop/capture_desktop/widgets_analysis_predictions.py",
    "desktop/capture_desktop/widgets_analysis_jobs.py",
    "desktop/capture_desktop/screen_analysis.py",
    "tests/ui/test_analysis_predictions.py",
)
guide = "docs/design/research/EXTERNAL_EVALUATION_WORKBENCH.md"
assert set(git_text("diff", "--name-only", "d7459fa62dd7a57d5565214e10638e055ad5877c", head).splitlines()) == set(own_paths) | {guide}
runs = (
    ("viewport-candidate-r3", "r3", "receive-analysis-viewport.py"),
    ("viewport-focus-diagnostic-r4", "diagnostic", "diagnose-viewport-focus.py"),
    ("viewport-candidate-r5", "r5", "receive-analysis-viewport-r5.py"),
    ("viewport-candidate-r6", "r6", "receive-analysis-viewport-r6.py"),
)
reports = {}
for native_dir, archived_dir, receiver in runs:
    report = doc(base / native_dir / "receiving.json")
    reports[archived_dir] = report
    assert report["source_commit"] == head and report["source_tree"] == tree
    assert report["source_unchanged"]
    assert sha((base / receiver).read_bytes()) == report["receiver_sha256"]
    put(base / native_dir / "receiving.json", archived_dir + "/receiving.json")
    put(base / receiver, archived_dir + "/" + receiver)
    for image in report["screenshots"]:
        put(base / native_dir / image, archived_dir + "/" + image)
    for relative, pin in report.get("imported_project_source", {}).items():
        data = (source / relative).read_bytes()
        assert sha(data) == pin["sha256"]
        assert hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest() == pin["git_blob"]
assert not reports["r3"]["passed"] and not reports["r3"]["jobs"]
assert all(row["passed"] for row in reports["r3"]["geometry_cases"])
assert not reports["r5"]["passed"] and len(reports["r5"]["jobs"]) == 1
assert not reports["diagnostic"]["jobs"]
final = reports["r6"]
assert final["passed"] and len(final["jobs"]) == 1 and not final["callback_errors"]
assert final["receiver_sha256"] == "8c2a8f172f7089440b10f17f386cae30f5966e65004129e1f830dc367fd3b2f9"
assert all(row["passed"] and row["actual"] == row["requested"] for row in final["geometry_cases"])
assert all(row["reached"] for row in final["workflow_keyboard_navigation"])
held = final["held_worker"]
assert not held["run"]["enabled"] and held["cancel"]["enabled"]
assert held["cancel_action"] == "Actual keyboard Space on reachable enabled Cancel"
assert held["actual_worker_cancel_flag_after_action"]
assert held["actual_run_consumed_cancel_before_creating_job_outputs"]
assert held["after_completion_run_enabled"] and not held["after_completion_cancel_enabled"]
assert held["after_completion_evaluation_input_enabled"]
assert final["jobs"][0]["error"] == "analysis cancelled" and not final["jobs"][0]["on_main_thread"]
assert final["jobs"][0]["params_at_entry"]["checkpointSection"] is None
assert len(final["imported_project_source"]) == 62
for row in final["protected_package_and_bundle_files"]:
    assert sha(Path(row["path"]).read_bytes()) == row["sha256"]
for run in ("r5", "r6"):
    native_dir = "viewport-candidate-" + run
    root = base / native_dir
    assert sorted(path.name for path in (root / "viewport.mmsession/processing/jobs").iterdir()) == ["alternate", "bundle"]
    for folder in ("inputs", "viewport.mmsession"):
        for path in sorted((root / folder).rglob("*")):
            if path.is_file():
                put(path, run + "/" + path.relative_to(root).as_posix())

source_manifest = {}
for relative in own_paths + (
    guide,
    "desktop/capture_desktop/app.py",
    "libs/python/capture_protocol/capture_protocol/control_client.py",
):
    data = (source / relative).read_bytes()
    blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
    assert blob == git_text("rev-parse", "HEAD:" + relative)
    put(source / relative, "source/" + relative)
    source_manifest[relative] = {"bytes": len(data), "sha256": sha(data), "git_blob": blob}
for relative, digest in final["owned_source_sha256"].items():
    assert source_manifest[relative]["sha256"] == digest
write(packet / "source-manifest.json", {"commit": head, "tree": tree, "files": source_manifest})
inventory = {}
for line in git_text("ls-tree", "-r", "HEAD").splitlines():
    metadata, path = line.split("\t", 1)
    mode, kind, digest = metadata.split()
    if kind == "blob":
        inventory[path] = {"mode": mode, "git_blob": digest}
write(packet / "source-tree.json", {"commit": head, "tree": tree, "files": inventory})
for commit in (
    "424298e30d6e0f08fe4124fa282328575c40d203",
    "4e8075a38cd31529534fe6199a7fa6a0b616d035",
    head,
):
    raw = git("cat-file", "commit", commit)
    assert hashlib.sha1(b"commit " + str(len(raw)).encode() + b"\0" + raw).hexdigest() == commit
    target = packet / "git-commits" / (commit + ".txt")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
(packet / "source-delta-from-424.patch").write_bytes(git("diff", "--binary", "424298e30d6e0f08fe4124fa282328575c40d203", head))
put(Path("/tmp/capturesuite-prediction-ui-6e5752b49b6f-production/layout-source-r3.json"), "author-layout-source-r3.json")
for name in ("native-successor-execution.json", "current-main-dependency-admission.json", "current-main-windows-source.json"):
    put(base / name, name)
put(base / "README-successor-receiving.md", "README.md")
put(Path(__file__), "freeze-successor-receiving-r2.py")
put(base / "freeze-successor-receiving.py", "receiver-tool-corrections/freeze-successor-receiving-r1.py")
put(base / "successor-packaging-correction.json", "receiver-tool-corrections/packaging-correction.json")
companions = [
    {"archive": "capturesuite69-functional-receiving.tar.gz", "bytes": 743543, "sha256": "8efa28046febd1fbadadefaf0cb35229e9cc4cefa6b621bd9c2d35f979c7737f"},
    {"archive": "capturesuite69-original-counterexamples.tar.gz", "bytes": 552335, "sha256": "c3050c15d7552d63ce5281e483e22b72d37bbdabd41a955135dbab4dd15b8a31"},
]
for row in companions:
    data = (base / row["archive"]).read_bytes()
    assert len(data) == row["bytes"] and sha(data) == row["sha256"]
write(packet / "companion-archives.json", {"unchanged": True, "files": companions})
members = []
for path in sorted(packet.rglob("*")):
    if path.is_file():
        data = path.read_bytes()
        members.append({"path": path.relative_to(packet).as_posix(), "bytes": len(data), "sha256": sha(data)})
write(packet / "MANIFEST.json", {"files": members})
archive = base / "capturesuite69-successor-receiving.tar.gz"
with tarfile.open(archive, "w:gz") as stream:
    for path in sorted(packet.rglob("*")):
        if path.is_file():
            stream.add(path, arcname=path.relative_to(packet).as_posix(), recursive=False)
expected = {row["path"]: row for row in members}
data = (packet / "MANIFEST.json").read_bytes()
expected["MANIFEST.json"] = {"bytes": len(data), "sha256": sha(data)}
with tarfile.open(archive, "r:gz") as stream:
    assert set(stream.getnames()) == set(expected)
    for entry in stream.getmembers():
        assert entry.isfile()
        data = stream.extractfile(entry).read()
        assert len(data) == expected[entry.name]["bytes"] and sha(data) == expected[entry.name]["sha256"]
assert not git("status", "--porcelain").strip()
data = archive.read_bytes()
summary = {
    "archive": str(archive), "bytes": len(data), "sha256": sha(data),
    "members": len(expected), "manifest_sha256": sha((packet / "MANIFEST.json").read_bytes()),
    "receipt_sha256": sha((packet / "r6/receiving.json").read_bytes()),
    "source_commit": head, "source_tree": tree, "receiver_sha256": final["receiver_sha256"],
    "geometry_cases": 2, "actual_cancelled_worker": 1, "imported_project_files": 62,
    "source_unchanged": True, "companion_archives_unchanged": True,
}
write(base / "successor-packet.json", summary)
print(json.dumps(summary), flush=True)
