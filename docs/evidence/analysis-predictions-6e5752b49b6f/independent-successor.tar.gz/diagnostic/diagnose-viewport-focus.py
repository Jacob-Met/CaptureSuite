# SPDX-License-Identifier: GPL-3.0-only
"""Independent actual-Qt receiving of native evaluation input and real jobs.

Only a pass-through run observer and one explicitly gated scheduling control are
installed in this private process. No scorer, worker, dialog or result is stubbed.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time
import tomllib
import traceback

parser = argparse.ArgumentParser()
parser.add_argument("--source", required=True)
parser.add_argument("--output", required=True)
parser.add_argument("--expected-commit", required=True)
parser.add_argument("--expected-tree", required=True)
parser.add_argument("--geometry-only", action="store_true")
args = parser.parse_args()
SOURCE = Path(args.source).resolve()
OUT = Path(args.output).resolve()
OUT.mkdir(parents=True, exist_ok=False)
sys.dont_write_bytecode = True
for name, suffix in {
    "LOCALAPPDATA": "local", "APPDATA": "roaming", "XDG_CONFIG_HOME": "config",
    "XDG_DATA_HOME": "data", "XDG_CACHE_HOME": "cache", "MPLCONFIGDIR": "matplotlib",
    "TMPDIR": "temporary", "CAPTURE_TEST_STATE": "application-state",
}.items():
    folder = OUT / suffix
    folder.mkdir()
    os.environ[name] = str(folder)
os.environ["QT_QPA_PLATFORM"] = "offscreen"
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
os.chdir(OUT)
configuration = tomllib.loads((SOURCE / "pyproject.toml").read_text())
for path in reversed(configuration["tool"]["pytest"]["ini_options"]["pythonpath"]):
    sys.path.insert(0, str(SOURCE / path))

sha = lambda data: hashlib.sha256(data).hexdigest()
def git(*arguments):
    environment = dict(os.environ, GIT_OPTIONAL_LOCKS="0")
    return subprocess.check_output(["git", *arguments], cwd=SOURCE, env=environment, text=True).strip()

assert git("rev-parse", "HEAD") == args.expected_commit
assert git("rev-parse", "HEAD^{tree}") == args.expected_tree
assert not git("status", "--porcelain")
EXPECTED = {}
for relative in (
    "desktop/capture_desktop/widgets_analysis_predictions.py",
    "desktop/capture_desktop/widgets_analysis_jobs.py",
    "desktop/capture_desktop/screen_analysis.py",
    "tests/ui/test_analysis_predictions.py",
):
    data = (SOURCE / relative).read_bytes()
    blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
    assert blob == git("rev-parse", "HEAD:" + relative), relative
    EXPECTED[relative] = sha(data)
tree = {}
for line in git("ls-tree", "-r", "HEAD").splitlines():
    metadata, path = line.split("\t", 1)
    mode, kind, digest = metadata.split()
    if kind == "blob":
        tree[path] = {"mode": mode, "git_blob": digest}

import PySide6
from PySide6.QtCore import QCoreApplication, QEvent, QEventLoop, QThread, QTimer, Qt, qVersion
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QAbstractItemView, QApplication, QComboBox, QDialogButtonBox, QFileDialog, QLineEdit, QMessageBox, QPushButton, QWidget
import pandas as pd
import capture_analysis
from capture_desktop import theme
from capture_desktop.screen_analysis import AnalysisScreen, _AnalysisWorker
from capture_desktop.state import CaptureState
from capture_desktop.widgets_analysis_jobs import AnalysisJobExtras

QCoreApplication.setAttribute(Qt.ApplicationAttribute.AA_DontUseNativeDialogs, True)
app = QApplication([])
app.setApplicationName("CaptureSuite independent evaluation receiving 6e5752b49b6f")
app.setOrganizationName("Independent receiving")
theme.apply_theme(app, setting="dark")
MAIN_THREAD = threading.get_ident()
REPORT = {
    "source_commit": git("rev-parse", "HEAD"), "source_tree": git("rev-parse", "HEAD^{tree}"),
    "parent": git("rev-parse", "HEAD^"), "owned_source_sha256": EXPECTED,
    "receiver_sha256": sha(Path(__file__).read_bytes()), "python": sys.version,
    "pyside": PySide6.__version__, "qt": qVersion(), "qt_platform": app.platformName(),
    "dialog_scope": "Actual Qt QFileDialog with AA_DontUseNativeDialogs. The offscreen receiver explicitly activates Qt windows before keyboard actions; no Cocoa, Windows OS-dialog, or window-manager focus claim.",
    "cases": [], "dialogs": [], "messages": [], "jobs": [], "screenshots": [],
}
case_name = "initialization"
callback_errors = []
actual_run = capture_analysis.run
GATE = {"active": False, "entered": threading.Event(), "release": threading.Event()}
protected = {}
all_threads = []

def write_json(path, document):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(document, ensure_ascii=False, indent=2) + "\n", encoding="utf8")

def protect(path):
    protected[str(path)] = sha(path.read_bytes())

def fixture(name):
    package = OUT / (name + ".mmsession")
    package.mkdir()
    write_json(package / "manifest.json", {
        "session_schema_version": "1.0.0", "sessionId": "independent-ui-" + name,
        "state": "finalized", "t0WallUtc": "2026-10-08T00:00:00Z",
        "finalizedUtc": "2026-10-08T00:00:10Z", "sourceIds": [],
    })
    write_json(package / "integrity.json", {"schemaVersion": "1", "files": []})
    for event in ("checkpoints", "annotations", "sync_anchors"):
        write_json(package / "events" / (event + ".json"), [])
    for path in package.rglob("*"):
        if path.is_file():
            protect(path)
    identifiers = ["native-c", "native-a", "native-d", "native-b"]
    times = [10**18 + 37 + i * 250_000_001 for i in range(4)]
    teacher = [-6.0, 1.5, 8.0, 21.0]
    column = "theta_elbow_flex_L"
    paths = {}
    for bundle_id, shift in (("bundle", 0.0), ("alternate", 100.0)):
        folder = package / "processing" / "jobs" / bundle_id / "ml_bundle"
        folder.mkdir(parents=True)
        windows = folder / "windows.parquet"
        pd.DataFrame({
            "window_id": identifiers,
            "session_time_ns": pd.Series(times, dtype="int64"),
            "valid_mask": pd.Series([True] * 4, dtype="bool"),
            column: [value + shift for value in teacher],
        }).to_parquet(windows, index=False)
        manifest = folder / "manifest.json"
        write_json(manifest, {
            "schemaId": "capture.ml_bundle/1",
            "sessionIds": ["independent-ui-" + name],
            "targetColumns": [column],
            "sha256": {"windows.parquet": sha(windows.read_bytes())},
            "provisional": True,
        })
        paths[bundle_id] = (windows, manifest)
        protect(windows); protect(manifest)
    windows, manifest = paths["bundle"]
    def predictions(label, offset):
        return {
            "schemaId": "capture.eval_predictions/1", "modelId": label,
            "windowsSha256": sha(windows.read_bytes()),
            "manifestSha256": sha(manifest.read_bytes()),
            "predictions": [
                {"window_id": identifiers[i], "session_time_ns": times[i],
                 "values": {column: teacher[i] + offset}}
                for i in (3, 1, 0, 2)
            ],
        }
    inputs = OUT / "inputs" / name
    inputs.mkdir(parents=True)
    # The trailing space is intentional and is a native POSIX filename control.
    chosen_a = inputs / " predictions café A.json "
    chosen_b = inputs / "predictions chosen B.json"
    invalid = inputs / "source mismatch.json"
    write_json(chosen_a, predictions("Receiver chosen A / café", 2.25))
    write_json(chosen_b, predictions("Receiver chosen B", 5.75))
    bad = predictions("Receiver wrong source", 2.25)
    bad["manifestSha256"] = "0" * 64
    write_json(invalid, bad)
    return {
        "package": package, "column": column, "ids": identifiers, "times": times,
        "teacher": teacher, "a": chosen_a, "b": chosen_b, "invalid": invalid,
        "windows": windows, "manifest": manifest, "predictions": predictions,
    }

def wait_until(predicate, timeout=35):
    if predicate():
        return
    loop = QEventLoop()
    timer = QTimer()
    deadline = time.monotonic() + timeout
    def check():
        if predicate() or callback_errors or time.monotonic() > deadline:
            loop.quit()
    timer.timeout.connect(check)
    timer.start(20)
    loop.exec()
    timer.stop()
    assert not callback_errors, callback_errors
    assert predicate(), "Timed out in native event loop: " + case_name

def press(widget):
    assert widget.isEnabled(), widget.objectName() or widget.text()
    # QTest delivers keys even to an inactive offscreen window. Establish the
    # native focus precondition explicitly after nested file dialogs close.
    app.setActiveWindow(widget.window())
    wait_until(lambda: app.activeWindow() is widget.window(), timeout=3)
    widget.setFocus()
    assert app.focusWidget() is widget, widget.objectName() or widget.text()
    QTest.keyClick(widget, Qt.Key.Key_Space)

def mode_control(parent):
    result = parent.findChild(QComboBox, "EvalInputMode")
    assert result is not None
    return result

def mode(parent, target):
    combo = mode_control(parent)
    index = combo.findData(target)
    assert index >= 0
    app.setActiveWindow(combo.window())
    wait_until(lambda: app.activeWindow() is combo.window(), timeout=3)
    combo.setFocus()
    for _ in range(combo.count() + 1):
        if combo.currentIndex() == index:
            break
        QTest.keyClick(combo, Qt.Key.Key_Down if combo.currentIndex() < index else Qt.Key.Key_Up)
    assert combo.currentData() == target

def path_control(parent):
    result = parent.findChild(QLineEdit, "EvalPredictionPath")
    assert result is not None and result.isReadOnly()
    return result

def choose(parent, requested=None, *, cancel=False, during=None):
    choose_button = parent.findChild(QPushButton, "EvalPredictionChoose")
    assert choose_button is not None and choose_button.isEnabled()
    observations = []
    timer = QTimer()
    deadline = time.monotonic() + 8
    stage = {"dialog": None, "prepared": False, "selected": False, "ticks": 0}
    def steer():
        try:
            if time.monotonic() > deadline:
                raise AssertionError("Actual Qt file dialog selection timed out")
            dialog = next((w for w in app.topLevelWidgets() if isinstance(w, QFileDialog) and w.isVisible()), None)
            if dialog is None:
                if time.monotonic() > deadline:
                    raise AssertionError("Actual Qt file dialog did not open")
                return
            if not stage["prepared"]:
                stage["dialog"] = dialog
                stage["prepared"] = True
                if requested is not None:
                    dialog.selectNameFilter("All files (*)")
                    dialog.setDirectory(str(requested.parent))
                return
            if not stage["selected"]:
                if requested is not None:
                    matched = False
                    for view in dialog.findChildren(QAbstractItemView):
                        if not view.isVisible() or view.objectName() not in ("listView", "treeView"):
                            continue
                        model = view.model()
                        for row in range(model.rowCount(view.rootIndex())):
                            index = model.index(row, 0, view.rootIndex())
                            if index.data() != requested.name:
                                continue
                            view.scrollTo(index)
                            rectangle = view.visualRect(index)
                            if not rectangle.isValid():
                                continue
                            QTest.mouseClick(view.viewport(), Qt.MouseButton.LeftButton, pos=rectangle.center())
                            stage["selection_view"] = view.objectName()
                            matched = True
                            break
                        if matched:
                            break
                    if not matched:
                        return
                stage["selected"] = True
                if during:
                    during()
                return
            stage["ticks"] += 1
            if stage["ticks"] < 3:
                return
            selected = dialog.selectedFiles()
            observations.append({
                "case": case_name, "requested": str(requested) if requested else None,
                "native_selected_files_before_close": selected,
                "cancel": cancel, "visible": dialog.isVisible(),
                "caption": dialog.windowTitle(), "dialog_class": dialog.metaObject().className(),
                "actual_file_view_clicked": stage.get("selection_view"),
            })
            timer.stop()
            if cancel:
                QTest.keyClick(dialog, Qt.Key.Key_Escape)
            else:
                assert len(selected) == 1 and Path(selected[0]).samefile(requested), selected
                assert Path(selected[0]).name == requested.name, (selected, requested.name)
                box = dialog.findChild(QDialogButtonBox)
                button = next(b for b in box.buttons() if box.buttonRole(b) == QDialogButtonBox.ButtonRole.AcceptRole)
                assert button.isEnabled()
                QTest.mouseClick(button, Qt.MouseButton.LeftButton)
        except BaseException:
            callback_errors.append(traceback.format_exc())
            timer.stop()
            if stage["dialog"] is not None:
                stage["dialog"].reject()
    timer.timeout.connect(steer)
    timer.start(40)
    press(choose_button)
    timer.stop()
    assert not callback_errors, callback_errors
    assert len(observations) == 1, observations
    REPORT["dialogs"].extend(observations)
    return observations[0]["native_selected_files_before_close"][0] if not cancel else None

def dismiss_messages():
    try:
        for box in app.topLevelWidgets():
            if isinstance(box, QMessageBox) and box.isVisible():
                REPORT["messages"].append({"case": case_name, "title": box.windowTitle(), "text": box.text()})
                box.accept()
    except BaseException:
        callback_errors.append(traceback.format_exc())

message_timer = QTimer()
message_timer.timeout.connect(dismiss_messages)
message_timer.start(25)

def observed_run(package, params=None, **kwargs):
    row = {
        "case": case_name, "package": str(package), "params_at_entry": copy.deepcopy(params.to_dict()),
        "thread_id": threading.get_ident(), "on_main_thread": threading.get_ident() == MAIN_THREAD,
    }
    REPORT["jobs"].append(row)
    GATE["cancel_event"] = kwargs.get("cancel")
    if GATE["active"]:
        GATE["entered"].set()
        if not GATE["release"].wait(15):
            raise AssertionError("Receiver-controlled scheduling gate was not released")
    try:
        result = actual_run(package, params, **kwargs)
        row.update({"job_dir": str(result.job_dir), "status": result.status})
        return result
    except BaseException as error:
        row.update({"error": str(error), "notes": list(getattr(error, "__notes__", ()))})
        raise

capture_analysis.run = observed_run


# The fixture/Qt helpers above are retained from the accepted R4 receiver.
# This geometry oracle and full-shell control-state challenge are independent
# of the author's layout implementation and unit tests.
from PySide6.QtCore import QPoint, QRect
from PySide6.QtWidgets import QLabel

REPORT["receiving_scope"] = "Actual standalone AnalysisScreen at requested viewport sizes, ancestor clipping, keyboard reachability, and one real held worker. The Windows-only MainWindow is not imported or substituted on this Mac."
REPORT["geometry_cases"] = []
REPORT["fixture_preparation"] = "A known path is seeded for geometry comparison on the unusable original UI. A geometrically accepted candidate must then Clear and choose through the actual dialog before the job action."
main = None
screen = None
def settle(milliseconds=50):
    loop = QEventLoop()
    QTimer.singleShot(milliseconds, loop.quit)
    loop.exec()
    assert not callback_errors, callback_errors
def rect_list(rectangle):
    return [rectangle.x(), rectangle.y(), rectangle.width(), rectangle.height()]
def geometry(widget):
    own = QRect(widget.rect())
    effective = QRect(own)
    chain = []
    ancestor = widget.parentWidget()
    while ancestor is not None:
        bounds = QRect(ancestor.mapToGlobal(QPoint(0, 0)) - widget.mapToGlobal(QPoint(0, 0)), ancestor.size())
        effective = effective.intersected(bounds)
        chain.append({"class": ancestor.metaObject().className(), "name": ancestor.objectName(), "bounds_in_control": rect_list(bounds)})
        ancestor = ancestor.parentWidget()
    hint_height = widget.minimumSizeHint().height()
    return {
        "class": widget.metaObject().className(), "name": widget.objectName(),
        "rect": rect_list(own), "effective": rect_list(effective),
        "in_main": rect_list(QRect(widget.mapTo(main, QPoint(0, 0)), widget.size())),
        "enabled": widget.isEnabled(), "visible": widget.isVisibleTo(main),
        "minimum_hint_height": hint_height,
        "fully_visible": widget.isVisibleTo(main) and effective == own and widget.height() >= max(0, hint_height),
        "ancestors": chain,
    }
def is_focus(target):
    focused = app.focusWidget()
    return focused is target or (focused is not None and target.isAncestorOf(focused))
def keyboard_to(target, maximum=180):
    app.setActiveWindow(main)
    for _ in range(maximum):
        if is_focus(target):
            app.processEvents()
            return True
        QTest.keyClick(app.focusWidget() or main, Qt.Key.Key_Tab)
        app.processEvents()
    return False

def focus_description():
    focus = app.focusWidget()
    if focus is None:
        return None
    description = {"class": focus.metaObject().className(), "name": focus.objectName(),
                   "is_run": focus is screen._btn_run, "is_clear": focus is controls["clear"],
                   "visible": geometry(focus)["fully_visible"]}
    for name in ("isReadOnly", "tabChangesFocus"):
        if hasattr(focus, name):
            description[name] = getattr(focus, name)()
    if isinstance(focus, QPushButton):
        description["text"] = focus.text()
    return description

try:
    f = fixture("focus-diagnostic")
    main = AnalysisScreen(CaptureState())
    screen = main
    screen.set_package(str(f["package"]))
    screen._command.setCurrentIndex(screen._command.findData("eval"))
    screen._extras._bundle_job.setEditText("bundle")
    mode_control(screen).setCurrentIndex(mode_control(screen).findData("external"))
    path_control(screen).setText(str(f["a"]))
    screen.findChild(QWidget, "EvaluationInput")._refresh()
    controls = {"clear": screen.findChild(QPushButton, "EvalPredictionClear")}
    main.resize(1100, 700)
    main.show()
    app.setActiveWindow(main)
    settle()
    REPORT["diagnostic_scope"] = "No chooser or worker. Direct Run focus establishes a diagnostic starting state; both traces then use actual keyboard navigation."
    REPORT["traces"] = {}
    for name, modifier in (("forward", Qt.KeyboardModifier.NoModifier),
                            ("backward", Qt.KeyboardModifier.ShiftModifier)):
        screen._btn_run.setFocus()
        app.processEvents()
        trace = []
        for step in range(12):
            trace.append(focus_description())
            QTest.keyClick(app.focusWidget() or main, Qt.Key.Key_Tab, modifier)
            app.processEvents()
        REPORT["traces"][name] = trace
    assert not REPORT["jobs"]
    REPORT["source_unchanged"] = all(sha((SOURCE / path).read_bytes()) == digest for path, digest in EXPECTED.items()) and not git("status", "--porcelain")
    assert REPORT["source_unchanged"]
finally:
    capture_analysis.run = actual_run
    message_timer.stop()
    if main is not None:
        main.close()
    for widget in app.topLevelWidgets():
        widget.close()
        widget.deleteLater()
    QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
    app.processEvents()
    write_json(OUT / "receiving.json", REPORT)
print(json.dumps({"source_commit": REPORT["source_commit"], "source_unchanged": REPORT.get("source_unchanged"), "traces": REPORT.get("traces")}), flush=True)
