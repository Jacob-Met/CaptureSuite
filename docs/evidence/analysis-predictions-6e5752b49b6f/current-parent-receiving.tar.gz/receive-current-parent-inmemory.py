# SPDX-License-Identifier: GPL-3.0-only
from pathlib import Path
import hashlib,json,os,subprocess,sys
base=Path("/tmp/capturesuite-eval-receiving-6e5752b49b6f-github")
source=Path("/tmp/capturesuite-prediction-ui-6e5752b49b6f-production/source-publication")
commit="4987c99c49751461a6b53a90ce9c43e39062ad59"
expected_tree="2d418e2094fae2caa59b17be66e1e7524ace66f0"
parent="3cbb5300bdc79c157370d1b3e599a6c82752d54a"
sha=lambda data:hashlib.sha256(data).hexdigest()
def git(*args):
    return subprocess.check_output(["git",*args],cwd=source,env=dict(os.environ,GIT_OPTIONAL_LOCKS="0"))
def text(*args):
    return git(*args).decode().strip()
def document(path):
    return json.loads(path.read_text())
def inventory(ref):
    rows={}
    for line in text("ls-tree","-r",ref).splitlines():
        metadata,path=line.split("\t",1)
        mode,kind,digest=metadata.split()
        if kind=="blob":rows[path]={"mode":mode,"git_blob":digest}
    return rows
parent_api=document(base/"current-parent-3c-tree.json")
assert parent_api["commit"]==parent and not parent_api["truncated"]
parent_files={row["path"]:{"mode":row["mode"],"git_blob":row["git_blob"]}for row in parent_api["files"]}
assert inventory(parent)==parent_files
assert text("rev-parse",parent+"^{tree}")==parent_api["tree"]
assert text("rev-parse",commit+"^{tree}")==expected_tree
raw=git("cat-file","commit",commit)
assert hashlib.sha1(b"commit "+str(len(raw)).encode()+b"\0"+raw).hexdigest()==commit
parents=[line.split()[1]for line in raw.decode().splitlines()if line.startswith("parent ")]
assert parents==[parent]
files=inventory(commit)
runtime=(
    "desktop/capture_desktop/widgets_analysis_predictions.py",
    "desktop/capture_desktop/widgets_analysis_jobs.py",
    "desktop/capture_desktop/screen_analysis.py",
    "tests/ui/test_analysis_predictions.py",
)
guide="docs/design/research/EXTERNAL_EVALUATION_WORKBENCH.md"
docs=("docs/design/ANALYSIS.md","docs/design/research/PROGRESS.md")
planned=set(runtime)|{guide}|set(docs)
changed={path for path in set(parent_files)|set(files)if parent_files.get(path)!=files.get(path)}
assert changed==planned,(changed,planned)
shared={path for path in planned if path in parent_files}
for path,row in parent_files.items():
    if path not in shared:assert files[path]==row,path
for path in shared:assert files[path]["mode"]==parent_files[path]["mode"]
accepted=document(base/"successor-packet-r2/source-manifest.json")
verified={}
for path in runtime+(guide,):
    data=git("show",commit+":"+path)
    assert sha(data)==accepted["files"][path]["sha256"],path
    assert files[path]["git_blob"]==accepted["files"][path]["git_blob"],path
    verified[path]={"bytes":len(data),"sha256":sha(data),"git_blob":files[path]["git_blob"]}
additions={}
for path in docs:
    original=git("show",parent+":"+path)
    current=git("show",commit+":"+path)
    assert current.startswith(original),path
    additions[path]=current[len(original):].decode()
assert "disables the evaluation-input controls" in additions["docs/design/ANALYSIS.md"]
assert "disables its inputs" not in additions["docs/design/ANALYSIS.md"]
deps=document(base/"current-main-3c-dependency-admission.json")
assert deps["parent"]==parent and deps["tree"]==parent_api["tree"]
for row in deps["unowned_imports"]:
    assert files[row["path"]]["git_blob"]==row["current_git_blob"],row["path"]
archives=document(base/"publication-artifact-identities.json")["archives"]
for row in archives:
    data=(base/row["path"]).read_bytes()
    assert sha(data)==row["sha256"] and len(data)==row["bytes"]
    assert hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()==row["git_blob"]
report={
    "scope":"Read-only current-parent source admission; no execution replay",
    "source_commit":commit,"source_tree":expected_tree,"parent":parent,"parent_tree":parent_api["tree"],
    "parent_git_api_inventory_exact":True,"parent_leaves":len(parent_files),
    "source_leaves":len(files),"unchanged_parent_leaves":len(parent_files)-len(shared),
    "changed_existing_paths":sorted(shared),"added_paths":sorted(set(files)-set(parent_files)),
    "planned_paths_exact":sorted(planned),"accepted_983_runtime_test_guide_exact":verified,
    "current_parent_document_prefixes_preserved":True,"document_additions":additions,
    "unowned_imports_admitted":len(deps["unowned_imports"]),"changed_dependencies":deps["changed"],
    "actual_false_anchor_full_session_jobs":len(deps["actual_original_jobs"]),
    "dependency_admission_sha256":sha((base/"current-main-3c-dependency-admission.json").read_bytes()),
    "unchanged_archives":archives,
    "script_sha256":sha(sys.orig_argv[sys.orig_argv.index("-c")+1].encode()),
    "actual_accepted_source_execution":"983641cc270db34be0711d554cd2c82608cb0b8c",
    "actual_windows_full_shell_execution":"pending hosted CI",
    "passed":True,
}
encoded=(json.dumps(report,ensure_ascii=False,indent=2)+"\n").encode()
print(json.dumps({"execution_mode":"in-memory, no filesystem writes", "receipt_sha256":sha(encoded),
                  "receipt":report}),flush=True)
