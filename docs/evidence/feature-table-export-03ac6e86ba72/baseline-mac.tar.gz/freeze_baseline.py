# SPDX-License-Identifier: GPL-3.0-only
"""Freeze actual current-source behavior before the selected-column export exists."""
from __future__ import annotations
import hashlib
import importlib.util
import json
import platform
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path("/Users/me/Developer/capturesuite-feature-export-03ac6e86ba72")
SOURCE = ROOT / "source"
EVIDENCE = ROOT / "evidence"
EVIDENCE.mkdir(exist_ok=True)
sys.path[:0] = [str(SOURCE / "libs/python" / name) for name in
               ("capture_analysis", "capture_protocol", "capture_session")]
spec = importlib.util.spec_from_file_location(
    "numeric_fixture", SOURCE / "tests/analysis/test_numeric_cli_receiving.py")
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)

def digest(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}

def inventory(root):
    return {p.relative_to(root).as_posix(): digest(p)
            for p in sorted(root.rglob("*")) if p.is_file()}

def write(name, doc):
    (EVIDENCE / name).write_text(json.dumps(doc, indent=2, sort_keys=True) + "\n")

tracked = subprocess.check_output(["git", "-C", str(SOURCE), "ls-files", "-z"]).split(b"\0")
source_hashes = {name.decode(): digest(SOURCE / name.decode()) for name in tracked
                 if name and (SOURCE / name.decode()).is_file()}
write("baseline-source.json", {
    "commit": subprocess.check_output(["git", "-C", str(SOURCE), "rev-parse", "HEAD"],
                                     text=True).strip(),
    "files": source_hashes,
})
package = fixture.make_package(ROOT / "fixtures/current-feature.mmsession")
raw_before = inventory(package)
command = [sys.executable, "-B", str(SOURCE / "tools/run_analysis.py"),
           "features", str(package), "--strict-warnings"]
run = subprocess.run(command, capture_output=True, text=True, timeout=120)
(EVIDENCE / "baseline-analysis.stdout.txt").write_text(run.stdout)
(EVIDENCE / "baseline-analysis.stderr.txt").write_text(run.stderr)
assert run.returncode == 0, (run.returncode, run.stdout, run.stderr)
job = next(line.removeprefix("dir=") for line in run.stdout.splitlines() if line.startswith("dir="))
job_path = Path(job)
manifest = json.loads((job_path / "job_manifest.json").read_text())
tables = [row["relativePath"] for row in manifest["outputs"] if row["kind"] == "feature_parquet"]
assert len(tables) == 3
missing_command = [sys.executable, "-B", str(SOURCE / "tools/export_feature_table.py"),
                   job, "--table", tables[0], "--column", "t_start_ns",
                   "--format", "both", "--output", str(ROOT / "baseline-export")]
missing = subprocess.run(missing_command, capture_output=True, text=True, timeout=20)
(EVIDENCE / "baseline-missing-entrypoint.stdout.txt").write_text(missing.stdout)
(EVIDENCE / "baseline-missing-entrypoint.stderr.txt").write_text(missing.stderr)
assert missing.returncode == 2 and "No such file or directory" in missing.stderr
raw_after = {name: digest(package / name) for name in raw_before}
assert raw_after == raw_before
write("baseline-receipt.json", {
    "createdUtc": datetime.now(UTC).isoformat(),
    "python": sys.version, "platform": platform.platform(),
    "analysis": {"command": command, "exitCode": run.returncode, "status": manifest["status"],
                 "jobDir": job, "featureTables": tables},
    "missingCapability": {"command": missing_command, "exitCode": missing.returncode,
                          "destinationCreated": (ROOT / "baseline-export").exists(),
                          "interpretation": "No supported selected-column export entrypoint at pinned source."},
    "rawInputsUnchanged": raw_before == raw_after,
    "sessionAndJobFiles": inventory(package),
})
print(json.dumps({"status": "baseline-frozen", "jobDir": job, "tables": tables,
                  "rawInputsUnchanged": True, "missingEntryPointExit": missing.returncode}))
