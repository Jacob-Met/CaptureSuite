# SPDX-License-Identifier: GPL-3.0-only
"""Seal author receipts, actual fixtures, and exact source snapshots without live links."""
from __future__ import annotations
import hashlib
import io
import json
import os
import subprocess
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "source"
SNAPSHOTS = ROOT / "source-snapshots"
SNAPSHOTS.mkdir(exist_ok=True)
LIB = "libs/python/capture_analysis/capture_analysis/feature_table_export.py"
CLI = "tools/export_feature_table.py"
TEST = "tests/analysis/test_feature_table_export.py"
GUIDE = "docs/FEATURE_TABLE_EXPORT.md"

def git_blob(sha):
    return subprocess.check_output(["git", "-C", str(SOURCE), "cat-file", "blob", sha])

def identity(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}

old_test = git_blob("624cda664cb8c5482296f94b604eb43b74b12cad")
old_test = old_test.replace(b"import pytest\n\nfrom capture_analysis", b"import pytest\nfrom capture_analysis")
versions = {
    "v1": {LIB: git_blob("d01db7bb7e4f5c588ec55912cb4ed45333853570"),
           CLI: git_blob("6bf5b506b73d2c537ff00595fe16e72a97b6ea5f"),
           TEST: old_test, GUIDE: git_blob("c5b12c2b67bbc3fd2c0bf72513d406a36d50a198")},
    "v2": {LIB: git_blob("d01db7bb7e4f5c588ec55912cb4ed45333853570"),
           CLI: git_blob("a40b495c339cb4ef90b5cef997a1bcf8727ce908"),
           TEST: old_test, GUIDE: git_blob("c5b12c2b67bbc3fd2c0bf72513d406a36d50a198")},
    "v3": {name: (SOURCE / name).read_bytes() for name in (LIB, CLI, TEST, GUIDE)},
}
proof = {}
for version, files in versions.items():
    frozen = json.loads((ROOT / f"qualification-{version}/source-files.json").read_bytes())["files"]
    proof[version] = {}
    for name, data in files.items():
        actual = identity(data)
        assert actual == frozen[name], (version, name, actual, frozen[name])
        target = SNAPSHOTS / version / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        proof[version][name] = actual
(SNAPSHOTS / "correspondence.json").write_text(
    json.dumps(proof, indent=2, sort_keys=True) + "\n", encoding="utf-8")
links = []
files = []
for relative in ("qualification-v1", "qualification-v2", "qualification-v3", "source-snapshots"):
    base = ROOT / relative
    for directory, dirs, names in os.walk(base, followlinks=False):
        directory = Path(directory)
        kept = []
        for name in dirs:
            child = directory / name
            if name == "matplotlib-cache":
                continue
            if child.is_symlink() or child.is_junction():
                links.append({"path": child.relative_to(ROOT).as_posix(), "kind": "directory-link",
                              "target": str(child.resolve())})
            else:
                kept.append(name)
        dirs[:] = kept
        for name in names:
            child = directory / name
            if child.is_symlink() or child.is_junction():
                links.append({"path": child.relative_to(ROOT).as_posix(), "kind": "file-link",
                              "target": str(child.resolve())})
                continue
            if child.is_file():
                if child.stat().st_nlink > 1:
                    links.append({"path": child.relative_to(ROOT).as_posix(), "kind": "hardlink",
                                  "nativeLinkCount": child.stat().st_nlink})
                files.append(child)
for name in ("qualify_author.py", "qualify_author_v1_v2.py", "seal_author.py"):
    files.append(ROOT / name)
link_doc = json.dumps({"links": links, "archivePolicy": (
    "Regular file bytes only; no live symlink/junction/hardlink entries in tar. "
    "Native alias observations are recorded here; maintained tests recreate their semantics."
)}, indent=2, sort_keys=True).encode() + b"\n"
archive_path = ROOT / "author-qualification-03ac6e86ba72.tar.gz"
inventory = {}
with tarfile.open(archive_path, "w:gz", format=tarfile.PAX_FORMAT) as archive:
    for path in sorted(files):
        relative = path.relative_to(ROOT).as_posix()
        data = path.read_bytes()
        info = tarfile.TarInfo(relative)
        info.size = len(data)
        info.mode = 0o644
        archive.addfile(info, io.BytesIO(data))
        inventory[relative] = identity(data)
    for relative, data in (
        ("fixture-links.json", link_doc),
        ("file-inventory.json", json.dumps(inventory, indent=2, sort_keys=True).encode() + b"\n"),
    ):
        info = tarfile.TarInfo(relative)
        info.size = len(data)
        info.mode = 0o644
        archive.addfile(info, io.BytesIO(data))
with tarfile.open(archive_path, "r:gz") as archive:
    for relative, expected in inventory.items():
        assert identity(archive.extractfile(relative).read()) == expected
result = {**identity(archive_path.read_bytes()), "files": len(inventory) + 2,
          "linksRecorded": len(links), "exactSnapshotsChecked": proof,
          "archive": str(archive_path)}
(ROOT / "author-archive.json").write_text(
    json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps({key: value for key, value in result.items() if key != "exactSnapshotsChecked"}))
