# SPDX-License-Identifier: GPL-3.0-only
"""Author qualification; saved receipts distinguish each actual native command."""
from __future__ import annotations

import argparse
import base64
import hashlib
import importlib.metadata
import json
import os
import platform
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path

import pyarrow as pa
import pyarrow.csv as csv
import pyarrow.parquet as pq

parser = argparse.ArgumentParser()
parser.add_argument("--source", type=Path, required=True)
parser.add_argument("--baseline", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
source = args.source.resolve()
baseline = args.baseline.resolve()
output = args.output.resolve()
output.mkdir()
records = []


def identity(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def inventory(root):
    return {path.relative_to(root).as_posix(): identity(path)
            for path in sorted(root.rglob("*")) if path.is_file()}


def write(name, doc):
    (output / name).write_text(json.dumps(doc, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def command(name, arguments, timeout=180):
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    env["MPLCONFIGDIR"] = str(output / "matplotlib-cache")
    result = subprocess.run(arguments, cwd=source, env=env, capture_output=True,
                            text=True, encoding="utf-8", errors="replace", timeout=timeout)
    (output / f"{name}.stdout.txt").write_text(result.stdout, encoding="utf-8")
    (output / f"{name}.stderr.txt").write_text(result.stderr, encoding="utf-8")
    records.append({"name": name, "command": arguments, "exitCode": result.returncode})
    return result


source_names = subprocess.check_output(
    ["git", "-C", str(source), "ls-files", "--cached", "--others", "--exclude-standard", "-z"]
).split(b"\0")
source_files = {
    name.decode("utf-8"): identity(source / name.decode("utf-8"))
    for name in source_names if name and (source / name.decode("utf-8")).is_file()
}
write("source-files.json", {
    "gitHead": subprocess.check_output(
        ["git", "-C", str(source), "rev-parse", "HEAD"], text=True).strip(),
    "workingTreeStatus": subprocess.check_output(
        ["git", "-C", str(source), "status", "--short"], text=True),
    "files": source_files,
})
frozen = json.loads((baseline / "evidence/baseline-receipt.json").read_bytes())
package = baseline / "fixtures/current-feature.mmsession"
before = inventory(package)
assert before == frozen["sessionAndJobFiles"], "Mac baseline changed during transfer"
job = package / "processing/jobs" / Path(frozen["analysis"]["jobDir"]).name
job_manifest = json.loads((job / "job_manifest.json").read_bytes())
tables = [item["relativePath"] for item in job_manifest["outputs"]
          if item["kind"] == "feature_parquet"]
cross_platform = []
for index, relative in enumerate(tables):
    original = pq.read_table(job / relative)
    columns = [original.column_names[-1], original.column_names[0]]
    destination = output / f"mac-job-export-{index}"
    run = command(f"mac-job-export-{index}", [
        sys.executable, "-B", str(source / "tools/export_feature_table.py"), str(job),
        "--table", relative, "--column", columns[0], "--column", columns[1],
        "--format", "both", "--output", str(destination),
    ])
    assert run.returncode == 0, run.stderr
    schema_doc = json.loads((destination / "_schema.json").read_bytes())
    schema = pa.ipc.read_schema(pa.BufferReader(base64.b64decode(schema_doc["arrowSchemaBase64"])))
    csv_table = csv.read_csv(
        destination / "table.csv", parse_options=csv.ParseOptions(
            newlines_in_values=True, ignore_empty_lines=False),
        convert_options=csv.ConvertOptions(column_types=schema, null_values=[""],
                                          strings_can_be_null=True,
                                          quoted_strings_can_be_null=False),
    )
    expected = original.select(columns)
    parquet_table = pq.read_table(destination / "table.parquet")
    assert csv_table.equals(expected, check_metadata=False)
    assert parquet_table.equals(expected, check_metadata=False)
    export_manifest = json.loads((destination / "manifest.json").read_bytes())
    for entry in export_manifest["outputs"]:
        assert identity(destination / entry["relativePath"]) == {
            "bytes": entry["bytes"], "sha256": entry["sha256"],
        }
    cross_platform.append({
        "relativePath": relative, "columns": columns, "rows": original.num_rows,
        "csvValuesEqual": True, "parquetValuesEqual": True,
        "manifestSha256": identity(destination / "manifest.json")["sha256"],
    })
assert inventory(package) == before
pytest_result = command("focused-pytest", [
    sys.executable, "-B", "-m", "pytest", "tests/analysis/test_feature_table_export.py", "-q",
    "--basetemp", str(output / "pytest-tmp"), "--junitxml", str(output / "focused-junit.xml"),
])
ruff_result = command("focused-ruff", [
    sys.executable, "-B", "-m", "ruff", "check",
    "libs/python/capture_analysis/capture_analysis/feature_table_export.py",
    "tools/export_feature_table.py", "tests/analysis/test_feature_table_export.py",
])
license_result = command("licenses", [
    sys.executable, "-B", "tools/check_licenses.py", "--enforce-spdx",
])
after_source = {name: identity(source / name) for name in source_files}
assert after_source == source_files, "qualification modified source"
receipt = {
    "createdUtc": datetime.now(UTC).isoformat(),
    "python": sys.version, "executable": sys.executable, "platform": platform.platform(),
    "versions": {name: importlib.metadata.version(name) for name in
                 ["pyarrow", "pandas", "numpy", "pytest", "ruff", "mcap", "jsonschema"]},
    "commands": records,
    "crossPlatformSavedMacJob": cross_platform,
    "allMacSessionAndJobInputHashesUnchanged": inventory(package) == before,
    "sourceHashesUnchanged": after_source == source_files,
    "testFaultInjection": [
        "A maintained failure test injects an output-writer OSError after a real partial file.",
        "A maintained concurrency test changes synthetic params during a real CSV batch write.",
    ],
    "status": "passed" if all(item["exitCode"] == 0 for item in records) else "failed",
}
write("receipt.json", receipt)
print(json.dumps({"status": receipt["status"], "commands": records,
                  "crossPlatformTables": len(cross_platform),
                  "receipt": str(output / "receipt.json")}))
raise SystemExit(0 if receipt["status"] == "passed" else 1)
