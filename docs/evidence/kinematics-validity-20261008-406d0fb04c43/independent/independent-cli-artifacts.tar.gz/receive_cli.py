# SPDX-License-Identifier: GPL-3.0-only
"""Independent real-Parquet receiving for CaptureSuite's existing kinematics CLI.

The expected joint geometry and dropout dependencies are fixed from the
published baseline contract. No candidate implementation is imported by this
oracle. Each variant gets fresh, private copies of the shipped session fixture.
"""

from __future__ import annotations

import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import traceback


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def clean(value):
    if isinstance(value, dict):
        return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean(v) for v in value]
    if hasattr(value, "item"):
        return clean(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def write_json(path, value):
    Path(path).write_text(json.dumps(clean(value), indent=2, allow_nan=False) + "\n")


def source_pin(root, paths):
    return {name: digest(root / name) for name in paths}


def fixtures(kind):
    # Ordered MediaPipe body indices. Coordinates produce exactly 90-degree
    # elbows/elevation, left shoulder flexion 90 degrees and right flexion zero.
    body = {
        11: (0.0, 1.0, 0.0), 13: (1.0, 1.0, 0.0),
        15: (1.0, 0.0, 0.0), 23: (0.0, 0.0, 0.0),
        12: (4.0, 1.0, 0.0), 14: (4.0, 0.0, 0.0),
        16: (5.0, 0.0, 0.0), 24: (5.0, 1.0, 0.0),
    }
    expected = [[True, True, True, True] for _ in range(10)]
    if kind == "sparse":
        expected = [[False, False, False, False] for _ in range(10)]
    if kind == "partial":
        expected[2] = [False, True, True, True]   # Left wrist absent.
        expected[4] = [True, True, False, True]   # Left hip absent.
        expected[5] = [True, False, True, False]  # Right shoulder absent.
        expected[6] = [True, True, True, False]   # Right hip below confidence.
        expected[7] = [False, True, True, True]   # Left wrist nonfinite.
        expected[8] = [False, True, False, True]  # Undefined left arm geometry.
    rows = []
    model = "sim_receiver_fixture" if kind == "sim" else "receiver_non_sim_fixture"
    for frame in range(10):
        points = dict(body)
        confidence = {i: 1.0 for i in points}
        if kind in {"sparse", "sim"}:
            points = {0: (0.0, 0.0, 0.0)}
            confidence = {0: 1.0}
        elif kind == "partial":
            if frame == 2:
                points.pop(15)
            elif frame == 4:
                points.pop(23)
            elif frame == 5:
                points.pop(12)
            elif frame == 6:
                confidence[24] = 0.1
            elif frame == 7:
                points[15] = (float("nan"), 0.0, 0.0)
            elif frame == 8:
                points[13] = points[11]
            elif frame == 9:
                # All 33 declared indices exist, but unrelated face/body
                # confidence must not erase eight usable limb landmarks.
                for index in set(range(33)) - set(body):
                    points[index] = (0.0, 0.0, 0.0)
                    confidence[index] = 0.0
        for index in sorted(points):
            x, y, z = points[index]
            rows.append({
                "session_time_ns": int(frame * 1e9 / 30.0),
                "frame_index": frame, "joint_index": index,
                "x": x, "y": y, "z": z,
                "confidence": confidence[index], "source_model": model,
            })
    return model, rows, expected


def main():
    config = json.loads(Path(sys.argv[1]).read_text())
    source = Path(config["sourceRoot"]).resolve()
    output = Path(config["outputRoot"]).resolve()
    output.mkdir(parents=True, exist_ok=False)
    source_paths = [
        source / "libs/python/capture_analysis",
        source / "libs/python/capture_session",
        source / "libs/python/capture_protocol",
        source / "libs/python/capture_protocol/capture_protocol/generated",
        source,
    ]
    sys.path[:0] = [str(p) for p in source_paths]
    import pandas as pd
    import numpy as np
    import pyarrow as pa

    spec = importlib.util.spec_from_file_location(
        "receiver_shipped_pose_fixture", source / "tests/analysis/test_pose_job.py"
    )
    fixture_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(fixture_module)
    before = source_pin(source, config["expectedSourcePins"])
    assert before == config["expectedSourcePins"], "supplied source pin mismatch"
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONPATH"] = os.pathsep.join(str(p) for p in source_paths)
    state = output / "private-state"
    for key, suffix in [
        ("LOCALAPPDATA", "local"), ("APPDATA", "roaming"),
        ("XDG_CONFIG_HOME", "config"), ("XDG_DATA_HOME", "data"),
        ("XDG_CACHE_HOME", "cache"),
    ]:
        path = state / suffix
        path.mkdir(parents=True)
        env[key] = str(path)
    env["CAPTURE_TEST_STATE"] = str(state)
    receipt = {
        "schema": "capturesuite.kinematics.independent-cli.v1",
        "variant": config["variant"], "sourceRoot": str(source),
        "sourcePinsBefore": before, "configSha256": digest(sys.argv[1]),
        "harnessSha256": digest(__file__), "cases": [],
        "runtime": {"python": sys.version, "numpy": np.__version__,
                    "pandas": pd.__version__, "pyarrow": pa.__version__},
        "scope": "Deterministic geometry fixture through real Parquet and CLI; no learned pose backend or real recording executed",
    }
    validity = ["elbow_L", "elbow_R", "shoulder_L", "shoulder_R"]
    groups = {
        "elbow_L": ["theta_elbow_flex_L"],
        "elbow_R": ["theta_elbow_flex_R"],
        "shoulder_L": ["theta_shoulder_elev_L", "theta_shoulder_flex_L"],
        "shoulder_R": ["theta_shoulder_elev_R", "theta_shoulder_flex_R"],
    }
    for kind in ["sparse", "partial", "full", "sim"]:
        case = {"name": kind, "assertions": []}
        receipt["cases"].append(case)

        def check(condition, name, detail=None):
            case["assertions"].append({"name": name, "pass": bool(condition), "detail": clean(detail)})

        try:
            package = fixture_module._write_pose_package(output / (kind + ".mmsession"))
            model, rows, expected = fixtures(kind)
            pose = package / "processing/jobs/receiver-pose"
            landmark_dir = pose / "pose/sim.camera.main"
            landmark_dir.mkdir(parents=True)
            landmarks = landmark_dir / "landmarks.parquet"
            pd.DataFrame(rows).to_parquet(landmarks, index=False)
            write_json(landmark_dir / "model_card.json", {
                "model_id": model, "role": "body", "provisional": kind == "sim",
                "fixturePurpose": "Independent geometry and dropout oracle; no learned model executed",
            })
            write_json(pose / "job_manifest.json", {
                "schemaId": "capture.analysis_job/1", "jobId": "receiver-pose",
                "command": "pose", "status": "completed", "poseModelId": model,
            })
            inputs = {str(p.relative_to(package)): digest(p)
                      for p in package.rglob("*") if p.is_file()}
            command = [sys.executable, str(source / "tools/run_analysis.py"),
                       "kinematics", str(package), "--pose-job", "receiver-pose",
                       "--overwrite-job-id", "receiver-kinematics"]
            run = subprocess.run(command, cwd=source, env=env, capture_output=True, text=True, timeout=90)
            case.update({"command": command, "exit": run.returncode,
                         "stdout": run.stdout, "stderr": run.stderr,
                         "inputHashes": inputs, "expectedValidity": expected})
            (output / (kind + ".stdout")).write_text(run.stdout)
            (output / (kind + ".stderr")).write_text(run.stderr)
            check(run.returncode == 0, "actual public CLI completes", run.returncode)
            if run.returncode != 0:
                continue
            kin = package / "processing/jobs/receiver-kinematics/kinematics"
            parquet = kin / "kinematics.parquet"
            qc = json.loads((kin / "kinematics_qc.json").read_text())
            df = pd.read_parquet(parquet)
            case.update({"parquetSha256": digest(parquet), "qc": qc,
                         "rows": clean(df.to_dict(orient="records"))})
            check(len(df) == 10 and qc["frameCount"] == 10, "all ten input frames retained")
            check(qc["provisional"] == (kind == "sim"), "explicit simulation provenance retained")
            check(df["pose_model_id"].eq(model).all(), "pose model provenance retained")
            check(all((package / p).is_file() and digest(package / p) == sha for p, sha in inputs.items()),
                  "all existing sealed-session and pose input bytes unchanged")
            actual_validity = [[bool(row["valid_" + group]) for group in validity]
                               for row in df.to_dict(orient="records")]
            check(actual_validity == expected, "per-frame per-joint validity matches required geometry",
                  {"actual": actual_validity, "expected": expected})
            expected_rates = {group: sum(row[i] for row in expected) / 10 for i, group in enumerate(validity)}
            check(qc["detectionRates"] == expected_rates, "QC detection rates follow actual joint validity",
                  {"actual": qc["detectionRates"], "expected": expected_rates})
            if kind != "sim":
                theta_failures = []
                for frame, row in enumerate(expected):
                    for index, group in enumerate(validity):
                        for col in groups[group]:
                            value = float(df.iloc[frame][col])
                            target = 0.0 if col == "theta_shoulder_flex_R" else 90.0
                            okay = abs(value - target) < 1e-10 if row[index] else math.isnan(value)
                            if not okay:
                                theta_failures.append({"frame": frame, "column": col, "actual": clean(value), "validExpected": row[index]})
                check(not theta_failures, "defined angles and missing-target masks match independent geometry", theta_failures)
                derived_failures = []
                for frame, row in enumerate(expected):
                    for index, group in enumerate(validity):
                        if row[index]:
                            continue
                        cols = [c.replace("theta_", "omega_", 1) for c in groups[group]]
                        if group.startswith("elbow_"):
                            cols.append("afr_" + group + "_deg")
                        for col in cols:
                            if col in df.columns and not pd.isna(df.iloc[frame][col]):
                                derived_failures.append({"frame": frame, "column": col, "actual": clean(df.iloc[frame][col])})
                check(not derived_failures, "invalid frames contain no invented angular-rate or AFR targets", derived_failures)
            if kind in config.get("expectedParity", {}):
                check(digest(parquet) == config["expectedParity"][kind], "entire control Parquet is byte-identical to baseline")
        except Exception:
            case["environmentOrExecutionError"] = traceback.format_exc()
            check(False, "receiving case reached its assertions", case["environmentOrExecutionError"])
        finally:
            case["pass"] = bool(case["assertions"]) and all(a["pass"] for a in case["assertions"])
            write_json(output / "receipt.in-progress.json", receipt)
    receipt["sourcePinsAfter"] = source_pin(source, config["expectedSourcePins"])
    receipt["sourcePreserved"] = receipt["sourcePinsAfter"] == before
    receipt["passedCases"] = sum(c["pass"] for c in receipt["cases"])
    receipt["failedCases"] = len(receipt["cases"]) - receipt["passedCases"]
    receipt["pass"] = receipt["sourcePreserved"] and receipt["failedCases"] == 0
    write_json(output / "receipt.json", receipt)
    leaves = [{"path": str(p.relative_to(output)), "bytes": p.stat().st_size, "sha256": digest(p)}
              for p in sorted(output.rglob("*")) if p.is_file()]
    write_json(output / "manifest.json", {"files": leaves, "unhashedSelf": "manifest.json"})
    print(json.dumps({"output": str(output), "passedCases": receipt["passedCases"],
                      "failedCases": receipt["failedCases"], "sourcePreserved": receipt["sourcePreserved"],
                      "cases": [{"name": c["name"], "pass": c["pass"],
                                 "failedAssertions": [a for a in c["assertions"] if not a["pass"]]}
                                for c in receipt["cases"]]}, allow_nan=False))
    return 0 if receipt["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
